package src.drivers;

import src.main.persistence.controllers.CtrlPersistencia;

import java.util.*;

public class DriverCtrlPersistencia {
    private CtrlPersistencia ctrlPersistencia;
    private Scanner in;

    public DriverCtrlPersistencia() {
        ctrlPersistencia = new CtrlPersistencia();
        in = new Scanner(System.in);
    }

    public void Usage() {
        System.out.println("Usage: ");
        System.out.println("Opcion 1: cargar Diccionario");
        System.out.println("Opcion 2: guardarUsuario:");
        System.out.println("Opcion 3: cargarUsuario");
        System.out.println("Opcion 4: eliminarUsuario:");
        System.out.println("Opcion 5: guardarSupermercado:");
        System.out.println("Opcion 6: cargarSupermercado:");
        System.out.println("Opcion 7: eliminarSupermercado:");
        System.out.println("Opcion 8: guardarProducto:");
        System.out.println("Opcion 9: cargarProducto:");
        System.out.println("Opcion 10: eliminarProducto:");
        System.out.println("Opcion fin: cerrar el programa");

    }

    public void ponerDatosUsuario(ArrayList<String> datos) {
        System.out.println("Datos del usuario: ");
        System.out.println("Inserte Nombre: ");
        datos.add("Nombre: ");
        String nombre = in.nextLine();
        datos.add(nombre);
        System.out.println("Inserte Contraseña: ");
        datos.add("Password: ");
        String password = in.nextLine();
        datos.add(password);
        System.out.println("Inserte Correo: ");
        datos.add("Email: ");
        String correo = in.nextLine();
        datos.add(correo);
        System.out.println("Inserte Idioma: ");
        datos.add("Idioma: ");
        String idioma = in.nextLine();
        datos.add(idioma);
        System.out.println("Inserte nombre de Supermercados asociados, diga fin para acabar: ");
        datos.add("Supermercados: ");
        String nombreSupermercados = null;
        while (!Objects.equals(nombreSupermercados, "fin")) {
            nombreSupermercados = in.nextLine();
            if (!Objects.equals(nombreSupermercados, "fin")) datos.add(nombreSupermercados);
        }
    }

    public Map<String, Object> ObtenerDatosSupermercado() {
        Map<String, Object> datosSupermercado = new LinkedHashMap<>();
        System.out.println("Seleccione nombre Supermercado: ");
        String nombreSupermercado = in.nextLine();
        System.out.println("Seleccione fecha: ");
        String fecha = in.nextLine();
        System.out.println("Seleccione numero estanterias: ");
        Integer numeroEstanterias = Integer.parseInt(in.nextLine());
        System.out.println("Seleccione Distribucion (ponga int que son identificadores, ponga -1 para acabar con esa estanteria): ");
        ArrayList<ArrayList<Integer>> distribucion = new ArrayList<>();
        ArrayList<Integer> Stock = new ArrayList<>();
        for (int i = 0; i < numeroEstanterias; i++) {
            ArrayList<Integer> dist = new ArrayList<>();
            Integer id = -2;
            while (!Objects.equals(id, -1)) {
                if (id != -1 && id != -2)  {
                    dist.add(id);
                    Stock.add(id);
                }
                System.out.println("Seleccione el producto: ");
                id = Integer.parseInt(in.nextLine());
            }
            distribucion.add(dist);
        }
        System.out.println("Seleccione el nombre del Usuario: ");
        String nombreUsuario = in.nextLine();

        datosSupermercado.put("Nombre", nombreSupermercado);
        datosSupermercado.put("Fecha", fecha);
        datosSupermercado.put("Numero Estanterias", numeroEstanterias);
        datosSupermercado.put("2", distribucion);
        datosSupermercado.put("Stock", Stock);
        datosSupermercado.put("Pertenece al Usuario", nombreUsuario);

        return datosSupermercado;
    }

    public Map<String, Object> obtenerDatosProducto() {
        System.out.println("Seleccione id Producto: ");
        String idProducto = in.nextLine();
        System.out.println("Seleccione el nombre del Producto: ");
        String nombreProducto = in.nextLine();
        System.out.println("Seleccione el precio del Producto: ");
        Double precioProducto = Double.parseDouble(in.nextLine());
        System.out.println("Seleccione el <Similitudes, id otroProducto> del Producto para acabar seleccione <-1, -1>: ");
        ArrayList<ArrayList<Integer>> similitud = new ArrayList<>();
        Integer sim = -2;
        Integer id2 = -2;
        while (sim != -1 && id2 != -1) {
            if (sim != -1 && sim != -2 && id2 != -1 && id2 != -1) {
                ArrayList<Integer> pair = new ArrayList<>();
                pair.add(sim);
                pair.add(id2);
                similitud.add(pair);
            }
            System.out.println("Seleccione la similitud con el producto: ");
            sim = Integer.parseInt(in.nextLine());
            System.out.println("Seleccione el id del producto: ");
            id2 = Integer.parseInt(in.nextLine());
        }
        System.out.println("Seleccione el nombre del Supermercado: ");
        String nombreSupermercado = in.nextLine();

        Map<String, Object> datosProducto= new LinkedHashMap<>();
        datosProducto.put("IdProducto", idProducto);
        datosProducto.put("Nombre", nombreProducto);
        datosProducto.put("Precio", precioProducto);
        datosProducto.put("Similitudes", similitud);
        datosProducto.put("Supermercado", nombreSupermercado);
        return datosProducto;
    }

    public static void main(String[] args) {
        DriverCtrlPersistencia driverCtrlPersistencia = new DriverCtrlPersistencia();
        System.out.println("Driver de CtrlPersistencia");
        System.out.println("");
        driverCtrlPersistencia.Usage();
        System.out.println("Seleccione opcion: ");
        String cmd = driverCtrlPersistencia.in.nextLine();

        while (!cmd.equals("-1") && !cmd.equals("end")) {
            switch (cmd) {
                case "1": {
                    System.out.println("Seleccione Idioma: ");
                    String idioma = driverCtrlPersistencia.in.nextLine();
                    try {
                        Map<Integer, String> aux = driverCtrlPersistencia.ctrlPersistencia.cargarDiccionario(idioma);
                        for (Map.Entry<Integer, String> entry : aux.entrySet()) {
                            System.out.println(entry.getKey() + ": " + entry.getValue());
                        }
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                }
                case "2": {
                    ArrayList<String> datos = new ArrayList<>();
                    driverCtrlPersistencia.ponerDatosUsuario(datos);
                    try {
                        driverCtrlPersistencia.ctrlPersistencia.guardarUsuario(datos);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                }
                case "3": {
                    System.out.println("Seleccione Usuario: ");
                    String usuario = driverCtrlPersistencia.in.nextLine();
                    try {
                        ArrayList<String> datos = driverCtrlPersistencia.ctrlPersistencia.cargarUsuario(usuario);
                        System.out.println(datos);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                }
                case "4": {
                    System.out.println("Seleccione Usuario: ");
                    String usuario = driverCtrlPersistencia.in.nextLine();
                    try {
                        driverCtrlPersistencia.ctrlPersistencia.eliminarUsuario(usuario);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                }
                case "5": {
                    Map<String, Object> supermercado = driverCtrlPersistencia.ObtenerDatosSupermercado();

                    try {
                        driverCtrlPersistencia.ctrlPersistencia.guardarSupermercado(supermercado);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }

                    break;
                }
                case "6": {

                    System.out.println("Seleccione Usuario: ");
                    String usuario = driverCtrlPersistencia.in.nextLine();
                    System.out.println("Seleccione Supermercado: ");
                    String supermercad = driverCtrlPersistencia.in.nextLine();
                    try {
                        Map<String, Object> supermercado = driverCtrlPersistencia.ctrlPersistencia.cargarSupermercado(supermercad,usuario);
                        for (Map.Entry<String, Object> entry : supermercado.entrySet()) {
                            System.out.println(entry.getKey() + ": " + entry.getValue());
                        }
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                }
                case "7": {
                    System.out.println("Seleccione Usuario: ");
                    String usuario = driverCtrlPersistencia.in.nextLine();
                    System.out.println("Seleccione Supermercado: ");
                    String supermercad = driverCtrlPersistencia.in.nextLine();
                    try{
                        driverCtrlPersistencia.ctrlPersistencia.eliminarSupermercado(supermercad,usuario);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                }
                case "8": {
                    Map<String, Object> producto = driverCtrlPersistencia.obtenerDatosProducto();

                    try {
                        driverCtrlPersistencia.ctrlPersistencia.guardarProducto(producto);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }

                    break;
                }/*
                case "9": {
                    System.out.println("Seleccione Supermercado: ");
                    String supermercad = driverCtrlPersistencia.in.nextLine();
                    System.out.println("Seleccione Producto: ");
                    int producto = Integer.valueOf(driverCtrlPersistencia.in.nextLine());
                    try {
                        Map<String, Object> product = driverCtrlPersistencia.ctrlPersistencia.cargarProducto(supermercad, producto);
                        for (Map.Entry<String, Object> entry : product.entrySet()) {
                            System.out.println(entry.getKey() + ": " + entry.getValue());
                        }
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                }
                case "10": {
                    System.out.println("Seleccione Supermercado: ");
                    String supermercad = driverCtrlPersistencia.in.nextLine();
                    System.out.println("Seleccione Producto: ");
                    String producto = driverCtrlPersistencia.in.nextLine();

                    try {
                        driverCtrlPersistencia.ctrlPersistencia.eliminarProd(supermercad, producto);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                }*/
                default:
                    driverCtrlPersistencia.Usage();
                    break;
            }
            System.out.println("Inserte Comando: ");
            cmd = driverCtrlPersistencia.in.nextLine();
        }
    }
}
