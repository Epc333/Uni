package src.drivers;

import src.main.domain.controllers.CtrlDiccionario;

import java.util.ArrayList;
import java.util.Map;
import java.util.Scanner;

/**
 * Este Driver sirve para provar los metodos puramente de Diccionario. Permite al Usuario provar
 * diferentes metodos atraves de una interfice por terminal. Permite ejecutar metodos proporcionados por CtrlDiccionario
 * @author Andres Lucian Laptes Costan (andres.lucian.laptes@estudiantat.upc.edu)
 * */
public class DriverDiccionario {
    private CtrlDiccionario ctrlDiccionario;
    private Scanner in;

    public DriverDiccionario() {
        ctrlDiccionario = new CtrlDiccionario();
        in = new Scanner(System.in);
    }

    private void Usage() {
        System.out.println("Usage: seleccione una de las opciones");
        System.out.println("    Finaliza al obtener un -1 o un end");
        System.out.println("Opcion 0: getFrase");
        System.out.println("Entrada: ");
        System.out.println("    -Idioma de uno de los disponibles");
        System.out.println("    -ID de una frase con identificador [0..n]"); //Por acabar Diccionario
        System.out.println("Finaliza cuando se pase -2 de ID");
        System.out.println("");
        System.out.println("Opcion 1: consultarIdiomasDisponibles");
        System.out.println("");
        System.out.println("Opcion 2: getFrases");
        System.out.println("Entrada: ");
        System.out.println("    -Idioma de uno de los disponibles");
        System.out.println("");
    }

    public void opcion0() {
        System.out.println("Listado de Idiomas: ");
        ArrayList<String> a = ctrlDiccionario.getIdiomasDisponibles();
        for (int i = 0; i < a.size(); i++) {
            System.out.println("    " + a.get(i));
        }
        System.out.println("Seleccione un idioma de uno de los disponibles: ");
        String idioma = in.nextLine();
        System.out.println("");
        System.out.println("Seleccione un frase con identificador [0..n]");
        int id = Integer.parseInt(in.nextLine());
        try {
            String frase = ctrlDiccionario.getFrase(idioma, id);
            System.out.println("");
            System.out.println("Su frase es : " + frase);
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }

    public void opcion1() {
        try {
            System.out.println("Listado de Idiomas: ");
            ArrayList<String> a = ctrlDiccionario.getIdiomasDisponibles();
            for (int i = 0; i < a.size(); i++) {
                System.out.println("    " + a.get(i));
            }
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
       System.out.println("");
    }

    public void opcion2() {
        System.out.println("Listado de Idiomas: ");
        ArrayList<String> a = ctrlDiccionario.getIdiomasDisponibles();
        for (int i = 0; i < a.size(); i++) {
            System.out.println("    " + a.get(i));
        }

        System.out.println("Seleccione un idioma de uno de los disponibles: ");
        String idioma = in.nextLine();
        System.out.println("");
        Map<Integer, String> frase;
        try {
            frase = ctrlDiccionario.getFrases(idioma);
            for (Integer key : frase.keySet()) {
                System.out.println("    ID : " + key + " frase : " + frase.get(key));
            }
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
        System.out.println("");
    }

    public static void main(String[] args)  throws Exception {
        DriverDiccionario dc = new DriverDiccionario();
        System.out.println("Driver de Diccionario (PROP Grupo 32.5)");
        System.out.println("");
        dc.Usage();
        System.out.println("Seleccione opcion: ");
        String cmd = dc.in.nextLine();
        while (!cmd.equals("-1") && !cmd.equals("end")) {
            switch (cmd) {
                case "0":
                    System.out.println("Opcion 0: getFrase");
                    dc.opcion0();
                    System.out.println("Opcion 0 finalizada");
                    break;
                case "1":
                    System.out.println("Opcion 1: consultarIdiomasDisponibles");
                    dc.opcion1();
                    System.out.println("Opcion 1 finalizada");
                    break;
                case "2":
                    System.out.println("Opcion 2: getFrases");
                    dc.opcion2();
                    System.out.println("Opcion 2 finalizada");
                    break;

                default:
                    System.out.println("Opcion no valida");
                    break;
            }
            System.out.println("Dale enter para mostrar las opciones disponibles");
            dc.in.nextLine();
            System.out.println("");
            dc.Usage();
            System.out.println("Seleccione opcion: ");
            cmd = dc.in.nextLine();
        }
        dc.in.close();
    }

}
