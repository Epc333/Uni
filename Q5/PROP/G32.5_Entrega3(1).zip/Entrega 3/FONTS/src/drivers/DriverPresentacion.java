package src.drivers;

import src.main.presentation.controllers.CtrlPresentacion;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Este Driver sirve para provar los metodos puros de CtrlPersistencia. Permite al Usuario iniciar
 * las vistas de todo el programa.
 * @author Vinyet Granda Planas (vinyet.granda@estudiantat.upc.edu)
 * */

public class DriverPresentacion {
    public static void main(String[] args) {
        CtrlPresentacion ctrlPresentacion = new CtrlPresentacion();
        ctrlPresentacion.iniciar();
    }
}