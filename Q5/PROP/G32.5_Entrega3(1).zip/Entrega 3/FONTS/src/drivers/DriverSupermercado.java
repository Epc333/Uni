package src.drivers;

import src.main.domain.classes.exceptions.ExcepcionNoAlgoritmo;
import src.main.domain.controllers.CtrlSupermercado;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.*;

/**
 * Este Driver sirve para provar los metodos puramente de CtrlSupermercado. Permite al Usuario provar
 * diferentes metodos a traves de una interfice por terminal. Permite ejecutar metodos proporcionados por CtrlDiccionario
 * @author Asier García Elvira (asier.garcia@estudiantat.upc.edu)
 * */
public class DriverSupermercado {
    private ArrayList<Integer> identificadores = new ArrayList<>();
    private Scanner in;
    private CtrlSupermercado ctrlSupermercado;

    public DriverSupermercado() {
        try {
            in = new Scanner(System.in);
            ctrlSupermercado = new CtrlSupermercado("Super", 5);
        }
        catch (ExcepcionNoAlgoritmo e){
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void Usage() {
        System.out.println("Usage: seleccione una de las opciones");
        System.out.println("    Finaliza al obtener un -1 o un 'end'");
        System.out.println("Opcion 0: modificarNombre");
        System.out.println("Opcion 1: agregarProducto");
        System.out.println("Opcion 2: eliminarProducto");
        System.out.println("Opcion 3: cambiarAlgoritmo");
        System.out.println("Opcion 4: intercambiarProductos");
        System.out.println("Opcion 5: crearSimilitud");
        System.out.println("Opcion 6: modificarSimilitud");
        System.out.println("Opcion 7: eliminarSimilitud");
        System.out.println("Opcion 8: modificarProducto");
        System.out.println("Opcion 9: limpiarDatos");
        System.out.println("Opcion 10: consultarSupermercado");
        System.out.println("Opcion 11: consultarProducto");
        System.out.println("Opcion 12: consultarProductos");
        System.out.println("Opcion 13: existsAlgoritmo");
        System.out.println("Opcion 14: consultaSimilitud");
        System.out.println("Opcion 15: consultaSimilitudes");
        System.out.println("Opcion 16: consultaStock");
        System.out.println("Opcion 17: getNombre");
        System.out.println("Opcion 18: getIdentificadores");
        System.out.println("Opcion 19: getSimilitudes");
        System.out.println("Opcion 20: reordenarEstanteria");
        System.out.println("Opcion 21: conusltarDustribucion");
        System.out.println("Opcion 22: getDatosSupermercado");
        System.out.println("Opcion 23: getSupers");
    }

    //Opcion 0: Modificar el Nombre del supermercado
    public void modificarNombre() {
        System.out.println("Seleccione Nombre del supermercado: ");
        String name = in.nextLine();

        System.out.println("Seleccione nuevo Nombre del supermercado: ");
        String newname = in.nextLine();

        try {
            ctrlSupermercado.modificarNombre(name, newname);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        System.out.println("El nombre del supermercado se ha modificado con exito");
    }

    public void agregarProducto() {
        System.out.println("Seleccione Nombre del supermercado: ");
        String nameSuper = in.nextLine();
        System.out.println("Seleccione Nombre del producto: ");
        String name = in.nextLine();
        System.out.println("Selecione Precio: ");
        boolean entradaValida = false;
        int precio = 0;
        while (!entradaValida) {
            String input = in.nextLine();
            try {
                precio = Integer.parseInt(input);
                entradaValida = true;
            } catch (NumberFormatException e) {
                System.out.println("Entrada no válida. Debes ingresar un número entero.");
            }
        }

        try {
            ctrlSupermercado.agregarProducto(nameSuper, name, precio);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        System.out.println("El producto se ha agragado con exito");
    }

    public void eliminarProducto() {
        System.out.println("Seleccione Nombre del supermercado: ");
        String nameSuper = in.nextLine();
        System.out.println("Seleccione Nombre: ");
        String name = in.nextLine();
        try {
            ctrlSupermercado.eliminarProducto(nameSuper, name);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        System.out.println("El producto se ha eliminado con exito");
    }

    public void cambiarAlgoritmo() {
        System.out.println("Nombre del supermercado: ");
        String nameSuper = in.nextLine();

        System.out.println("Nombre del algoritmo: ");
        String algoritmo = in.nextLine();
        try {
            ctrlSupermercado.cambiarAlgoritmo(nameSuper, algoritmo);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        System.out.println("El algoritmo se ha cambiado con exito");
    }

    public void intercambiarProductos() {
        System.out.println("Nombre del supermercado: ");
        String nameSuper = in.nextLine();
        System.out.println("Ingrese el nombre del producto 1: ");
        String name1 = in.nextLine();
        System.out.println("Ingrese el nombre del producto 2: ");
        String name2 = in.nextLine();
        try {
            ctrlSupermercado.intercambiarProductos(nameSuper,name1,name2);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void crearSimilitud() {
        System.out.println("Nombre del supermercado: ");
        String nameSuper = in.nextLine();
        System.out.println("Ingrese el nombre del producto 1: ");
        String name1 = in.nextLine();
        System.out.println("Ingrese el nombre del producto 2: ");
        String name2 = in.nextLine();
        System.out.println("Ingrese la similitud: ");
        boolean entradaValida = false;
        int similitud = 0;
        while (!entradaValida) {
            String input = in.nextLine();
            try {
                similitud = Integer.parseInt(input);
                entradaValida = true;
            } catch (NumberFormatException e) {
                System.out.println("Entrada no válida. Debes ingresar un número entero.");
            }
        }
        try {
            ctrlSupermercado.crearSimilitud(nameSuper, name1,name2, similitud);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        System.out.println("La similitud se ha creado con exito");
    }

    public void modificarSimilitud() {
        System.out.println("Nombre del supermercado: ");
        String nameSuper = in.nextLine();
        System.out.println("Ingrese el nombre del producto 1: ");
        String name1 = in.nextLine();
        System.out.println("Ingrese el nombre del producto 2: ");
        String name2 = in.nextLine();
        System.out.println("Ingrese la similitud: ");
        boolean entradaValida = false;
        int similitud = 0;
        while (!entradaValida) {
            String input = in.nextLine();
            try {
                similitud = Integer.parseInt(input);
                entradaValida = true;
            } catch (NumberFormatException e) {
                System.out.println("Entrada no válida. Debes ingresar un número entero.");
            }
        }
        try {
            ctrlSupermercado.modificarSimilitud(nameSuper, name1,name2,similitud);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        System.out.println("La similitud se ha modificado con exito");
    }

    public void eliminarSimilitud() {
        System.out.println("Nombre del supermercado: ");
        String nameSuper = in.nextLine();
        System.out.println("Ingrese el nombre del producto 1: ");
        String name1 = in.nextLine();
        System.out.println("Ingrese el nombre del producto 2: ");
        String name2 = in.nextLine();
        try {
            ctrlSupermercado.eliminarSimilitud(nameSuper,name1,name2);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        System.out.println("La similitud se ha elimiando con exito");
    }

    public void modificarProducto() {
        System.out.println("Nombre del supermercado: ");
        String nameSuper = in.nextLine();
        System.out.println("Ingrese el identificador del producto: ");
        String id = in.nextLine();
        System.out.println("Ingrese el nombre del producto: ");
        String name = in.nextLine();
        System.out.println("Ingrese el precio del producto: ");
        boolean entradaValida = false;
        int precio = 0;
        while (!entradaValida) {
            String input = in.nextLine();
            try {
                precio = Integer.parseInt(input);
                entradaValida = true;
            } catch (NumberFormatException e) {
                System.out.println("Entrada no válida. Debes ingresar un número entero.");
            }
        }
        try {
            ctrlSupermercado.modificarProducto(nameSuper, id, name, precio);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        System.out.println("El producto se ha modificado con exito");
    }

    public void limpiarDatos() {
        try {
            ctrlSupermercado.limpiarDatos();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        System.out.println("Se han limpiado los datos con exito");
    }

    public void consultarSupermercado() {
        System.out.println("Nombre del supermercado: ");
        String nameSuper = in.nextLine();
        try {
            ArrayList<String> lista = ctrlSupermercado.consultarSupermercado(nameSuper);
            System.out.println(lista);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void consultarProducto() {
        System.out.println("Nombre del supermercado: ");
        String nameSuper = in.nextLine();
        System.out.println("Ingrese el nombre del producto: ");
        String name = in.nextLine();
        try {
            ArrayList<String> lista = ctrlSupermercado.consultarProducto(nameSuper, name);
            System.out.println(lista);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void consultarProductos() {
        System.out.println("Nombre del supermercado: ");
        String nameSuper = in.nextLine();
        try {
            ArrayList<String> lista = ctrlSupermercado.consultarProductos(nameSuper);   System.out.println("Stock del producto:");
            System.out.println(lista);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void existsProducto() {
        System.out.println("Nombre del supermercado: ");
        String nameSuper = in.nextLine();
        System.out.println("Ingrese el nombre del producto: ");
        String name = in.nextLine();
        try {
            boolean existe = ctrlSupermercado.existsProducto(nameSuper, name);
            System.out.println(existe);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void existsAlgoritmo() {
        System.out.println("Ingrese el nombre del algoritmo: ");
        String algoritmo = in.nextLine();
        try {
            boolean existe = ctrlSupermercado.existsAlgoritmo(algoritmo);
            System.out.println(existe);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void consultaSimilitud() {
        System.out.println("Nombre del supermercado: ");
        String nameSuper = in.nextLine();
        System.out.println("Ingrese el nombre del producto 1: ");
        String name1 = in.nextLine();
        System.out.println("Ingrese el nombre del producto 2: ");
        String name2 = in.nextLine();
        try {
            int similitud = ctrlSupermercado.consultaSimilitudes(nameSuper, name1, name2);
            System.out.println(similitud);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void consultaSimilitudes() {
        System.out.println("Nombre del supermercado: ");
        String nameSuper = in.nextLine();
        System.out.println("Ingrese el nombre del producto: ");
        String name = in.nextLine();
        try {
            ArrayList<String> similitudes = ctrlSupermercado.consultaSimilitudes(nameSuper, name);
            System.out.println(similitudes);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void consultaStock(){
        System.out.println("Nombre del supermercado: ");
        String nameSuper = in.nextLine();
        try {
            ArrayList<String> lista  = ctrlSupermercado.consultaStock(nameSuper);
            System.out.println(lista);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void getNombres(){
        try{
            ArrayList<String> name = ctrlSupermercado.getNombres();
            System.out.println(name);
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void getIdentificadores(){
        System.out.println("Nombre del supermercado: ");
        String nameSuper = in.nextLine();
        try{
            ArrayList<Integer> lista = ctrlSupermercado.getIdentificadores(nameSuper);
            System.out.println(lista);
            identificadores = lista;
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void getSimilitudes(){
        System.out.println("Nombre del supermercado: ");
        String nameSuper = in.nextLine();
        try{
            ArrayList< ArrayList <Integer>> lista = ctrlSupermercado.getSimilitudes(nameSuper, identificadores);
            System.out.println(lista);
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void reordenarEstanteria(){
        System.out.println("Nombre del supermercado: ");
        String nameSuper = in.nextLine();
        try{
            ctrlSupermercado.reordenarEstanteria(nameSuper);
            System.out.println("Se ha reordenado con exito");
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void consultarDistribucion(){
        System.out.println("Nombre del supermercado: ");
        String nameSuper = in.nextLine();
        try{
            ArrayList<String> lista = ctrlSupermercado.consultarDistribucion(nameSuper);
            System.out.println(lista);
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void getDatosSupermercado(){
        System.out.println("Nombre del usuario: ");
        String nameUser = in.nextLine();
        try{
            ArrayList<Map<String, Object>> lista = ctrlSupermercado.getDatosSuper(nameUser);
            System.out.println(lista);
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public void getSupers(){
        try{
            ArrayList<String> lista = ctrlSupermercado.getSupers();
            System.out.println(lista);
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
    }


    public static void main(String[] args) {
        DriverSupermercado d = new DriverSupermercado();
        System.out.println("Driver de Supermercado");
        System.out.println("");
        d.Usage();
        System.out.println("Seleccione opcion: ");
        String cmd = d.in.nextLine();
        while (!cmd.equals("-1") && !cmd.equals("end")) {
            switch (cmd) {
                case "0":
                    System.out.println("Opcion 0: modificarNombre");
                    d.modificarNombre();
                    System.out.println("Opcion 0 finalizada");
                    break;

                case "1":
                    System.out.println("Opcion 1: agregarProducto");
                    d.agregarProducto();
                    System.out.println("Opcion 1 finalizada");
                    break;

                case "2":
                    System.out.println("Opcion 2: eliminarProducto");
                    d.eliminarProducto();
                    System.out.println("Opcion 2 finalizada");
                    break;

                case "3":
                    System.out.println("Opcion 3: cambiarAlgoritmo");
                    d.cambiarAlgoritmo();
                    System.out.println("Opcion 3 finalizada");
                    break;

                case "4":
                    System.out.println("Opcion 4: intercambiarProductos");
                    d.intercambiarProductos();
                    System.out.println("Opcion 4 finalizada");
                    break;

                case "5":
                    System.out.println("Opcion 5: crearSimilitud");
                    d.crearSimilitud();
                    System.out.println("Opcion 5 finalizada");
                    break;

                case "6":
                    System.out.println("Opcion 6: modificarSimilitud");
                    d.modificarSimilitud();
                    System.out.println("Opcion 6 finalizada");
                    break;

                case "7":
                    System.out.println("Opcion 7: eliminarSimilitud");
                    d.eliminarSimilitud();
                    System.out.println("Opcion 7 finalizada");
                    break;

                case "8":
                    System.out.println("Opcion 8: modificarProducto");
                    d.modificarProducto();
                    System.out.println("Opcion 8 finalizada");
                    break;

                case "9":
                    System.out.println("Opcion 9: limpiarDatos");
                    d.limpiarDatos();
                    System.out.println("Opcion 9 finalizada");
                    break;

                case "10":
                    System.out.println("Opcion 10: consultarSupermercado");
                    d.consultarSupermercado();
                    System.out.println("Opcion 10 finalizada");
                    break;

                case "11":
                    System.out.println("Opcion 11: consultarProducto");
                    d.consultarProducto();
                    System.out.println("Opcion 11 finalizada");
                    break;

                case "12":
                    System.out.println("Opcion 12: consultarProductos");
                    d.consultarProductos();
                    System.out.println("Opcion 12 finalizada");
                    break;

                case "13":
                    System.out.println("Opcion 13: existsAlgoritmo");
                    d.existsAlgoritmo();
                    System.out.println("Opcion 13 finalizada");
                    break;

                case "14":
                    System.out.println("Opcion 15: consultaSimilitud");
                    d.consultaSimilitud();
                    System.out.println("Opcion 15 finalizada");
                    break;

                case "15":
                    System.out.println("Opcion 16: consultaSimilitudes");
                    d.consultaSimilitudes(); //queda estas
                    System.out.println("Opcion 16 finalizada");
                    break;

                case "16":
                    System.out.println("Opcion 17: consultaStock");
                    d.consultaStock(); //queda esta
                    System.out.println("Opcion 17 finalizada");
                    break;

                case "17":
                    System.out.println("Opcion 18: getNombre");
                    d.getNombres();
                    System.out.println("Opcion 18 finalizada");
                    break;

                case "18":
                    System.out.println("Opcion 19: getIdentificadores");
                    d.getIdentificadores();
                    System.out.println("Opcion 19 finalizada");
                    break;

                case "19":
                    System.out.println("Opcion 20: getSimilitudes");
                    d.getSimilitudes();
                    System.out.println("Opcion 20 finalizada");
                    break;

                case "21":
                    System.out.println("Opcion 20: reordenarEstanteria");
                    d.reordenarEstanteria();
                    System.out.println("Opcion 20 finalizada");
                    break;

                case "22":
                    System.out.println("Opcion 21: consultarDistribucion");
                    d.reordenarEstanteria();
                    System.out.println("Opcion 21 finalizada");
                    break;

                case "23":
                    System.out.println("Opcion 23: reordenarEstanteria");
                    d.getDatosSupermercado();
                    System.out.println("Opcion 23 finalizada");
                    break;

                case "24":
                    System.out.println("Opcion 24: reordenarEstanteria");
                    d.getSupers();
                    System.out.println("Opcion 24 finalizada");
                    break;

                case "-1":
                case "end":
                    System.out.println("Fin del programa.");
                    break;

                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
            System.out.println("Dale enter para mostrar las opciones disponibles");
            d.in.nextLine();
            System.out.println("");
            d.Usage();
            System.out.println("Seleccione opcion: ");
            cmd = d.in.nextLine();
        }
        d.in.close();
    }
}
