package src.drivers;

import src.main.domain.controllers.CtrlUsuario;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Este Driver sirve para provar los metodos puramente de Usuario. Permite al Usuario provar
 * diferentes metodos atraves de una interfice por terminal. Permite ejecutar metodos proporcionados por CtrlDiccionario
 * @author Andres Lucian Laptes Costan (andres.lucian.laptes@estudiantat.upc.edu)
 * */
public class DriverUsuario {
    private Scanner in;
    private CtrlUsuario cntrUsuario;

    public DriverUsuario() {
        in = new Scanner(System.in);
        cntrUsuario = new CtrlUsuario();
    }

    public void Usage() {
        System.out.println("Usage: seleccione una de las opciones");
        System.out.println("    Finaliza al obtener un -1 o un 'end'");

        System.out.println("Opcion 0: crearPerfil");
        System.out.println("Entrada: ");
        System.out.println("    - Nombre del usuario");
        System.out.println("    - Contraseña (mínimo 12 caracteres)");
        System.out.println("    - Idioma (de los disponibles)");
        System.out.println("    - Email válido");
        System.out.println("Finaliza creando el perfil del usuario.");
        System.out.println("");

        System.out.println("Opcion 1: modificarPerfil");
        System.out.println("Entrada: ");
        System.out.println("    - Nuevo nombre del usuario (o null para no modificar)");
        System.out.println("    - Nueva contraseña (o null para no modificar)");
        System.out.println("    - Nuevo idioma (o null para no modificar)");
        System.out.println("    - Nuevo email (o null para no modificar)");
        System.out.println("");

        System.out.println("Opcion 2: eliminarPerfil");
        System.out.println("Finaliza eliminando el perfil del usuario actual.");
        System.out.println("");

        System.out.println("Opcion 3: generarSupermercado");
        System.out.println("Entrada: ");
        System.out.println("    - Nombre del supermercado");
        System.out.println("    - Número de estantes");
        System.out.println("Finaliza creando un supermercado con los datos especificados.");
        System.out.println("");

        System.out.println("Opcion 4: consultarSupermercado");
        System.out.println("Entrada: ");
        System.out.println("    - Nombre del supermercado");
        System.out.println("Salida: Lista de información del supermercado.");
        System.out.println("");

        System.out.println("Opcion 5: modificarNombreSupermercado");
        System.out.println("Entrada: ");
        System.out.println("    - Nombre actual del supermercado");
        System.out.println("    - Nuevo nombre para el supermercado");
        System.out.println("");

        System.out.println("Opcion 6: eliminarSupermercado");
        System.out.println("Entrada: ");
        System.out.println("    - Nombre del supermercado a eliminar");
        System.out.println("");

        System.out.println("Opcion 7: duplicarSupermercado");
        System.out.println("Entrada: ");
        System.out.println("    - Nombre del supermercado existente");
        System.out.println("    - Nuevo nombre para el supermercado duplicado");
        System.out.println("");

        System.out.println("Opcion 8: anadirProducto");
        System.out.println("Entrada: ");
        System.out.println("    - Nombre del supermercado");
        System.out.println("    - Nombre del producto");
        System.out.println("    - Precio del producto");
        System.out.println("");

        System.out.println("Opcion 9: modificarProducto");
        System.out.println("Entrada: ");
        System.out.println("    - Nombre del supermercado");
        System.out.println("    - Nombre del producto");
        System.out.println("    - Nuevo precio del producto");
        System.out.println("");

        System.out.println("Opcion 10: eliminarProducto");
        System.out.println("Entrada: ");
        System.out.println("    - Nombre del supermercado");
        System.out.println("    - Nombre del producto");
        System.out.println("");

        System.out.println("Opcion 11: intercambiarProductos");
        System.out.println("Entrada: ");
        System.out.println("    - Nombre del supermercado");
        System.out.println("    - Nombre del producto 1");
        System.out.println("    - Nombre del producto 2");
        System.out.println("");

        System.out.println("Opcion 12: consultaStock");
        System.out.println("Entrada: ");
        System.out.println("    - Nombre del supermercado");
        System.out.println("    - Nombre del producto");
        System.out.println("Salida: Lista de stock del producto.");
        System.out.println("");

        System.out.println("Opcion 13: consultaProducto");
        System.out.println("Entrada: ");
        System.out.println("    - Nombre del supermercado");
        System.out.println("    - Nombre del producto");
        System.out.println("Salida: Información detallada del producto.");
        System.out.println("");

        System.out.println("Opcion 14: crearSimilitud");
        System.out.println("Entrada: ");
        System.out.println("    - Nombre del supermercado");
        System.out.println("    - Nombre del producto 1");
        System.out.println("    - Nombre del producto 2");
        System.out.println("    - Valor de similitud");
        System.out.println("");

        System.out.println("Opcion 15: modificarSimilitud");
        System.out.println("Entrada: ");
        System.out.println("    - Nombre del supermercado");
        System.out.println("    - Nombre del producto 1");
        System.out.println("    - Nombre del producto 2");
        System.out.println("    - Nuevo valor de similitud");
        System.out.println("");

        System.out.println("Opcion 16: eliminarSimilitud");
        System.out.println("Entrada: ");
        System.out.println("    - Nombre del supermercado");
        System.out.println("    - Nombre del producto 1");
        System.out.println("    - Nombre del producto 2");
        System.out.println("");

        System.out.println("Opcion 17: consultaSimilitud");
        System.out.println("Entrada: ");
        System.out.println("    - Nombre del supermercado");
        System.out.println("    - Nombre del producto 1");
        System.out.println("    - Nombre del producto 2");
        System.out.println("Salida: Valor de similitud entre los productos.");
        System.out.println("");

        System.out.println("Opcion 18: cambiarAlgoritmo");
        System.out.println("Entrada: ");
        System.out.println("    - Nombre del supermercado");
        System.out.println("    - Nombre del nuevo algoritmo");
        System.out.println("");
    }

    public void crearPerfil() {
        System.out.println("Seleccione Nombre: ");
        String name = in.nextLine();
        System.out.println("Selecione Contraseña: ");
        String password = in.nextLine();
        System.out.println("Seleccione Idioma: ");
        String idioma = in.nextLine();
        System.out.println("Seleccione mail: ");
        String mail = in.nextLine();

        ArrayList<String> disponibles = new ArrayList<>(List.of("Castellano", "Catalan", "Ingles", "Rumano"));

        try {
            cntrUsuario.crearPerfil(name, password, idioma, mail, disponibles);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

    public void modificarPerfil() {
        System.out.println("Seleccione Nombre: ");
        String name = in.nextLine();
        System.out.println("Selecione Contraseña: ");
        String password = in.nextLine();
        System.out.println("Seleccione Idioma: ");
        String idioma = in.nextLine();
        System.out.println("Seleccione mail: ");
        String mail = in.nextLine();

        try {
            cntrUsuario.modificarPerfil(name, password, idioma, mail);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void eliminarPerfil() {
        System.out.println("Iniciando Limpieza del perfil");
        cntrUsuario.eliminarPerfil();
        System.out.println("Limpiada con exito");
    }

    public void generarSupermercado() {
        System.out.println("Nombre del supermercado: ");
        String nombreSupermercado = in.nextLine();
        System.out.println("Numero de estanterias: ");
        int estanterias = Integer.parseInt(in.nextLine());
        try {
            cntrUsuario.generarSupermercado(nombreSupermercado, estanterias);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void consultarSupermercado() {
        System.out.println("Ingrese el nombre del supermercado: ");
        String name = in.nextLine();
        try {
            ArrayList<String> detalles = cntrUsuario.consultarSupermercado(name);
            System.out.println("Detalles del supermercado: ");
            detalles.forEach(System.out::println);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void modificarNombreSupermercado() {
        System.out.println("Ingrese el nombre actual del supermercado: ");
        String viejoNombre = in.nextLine();
        System.out.println("Ingrese el nuevo nombre del supermercado: ");
        String nuevoNombre = in.nextLine();
        try {
            cntrUsuario.modificarNombreSupermercado(viejoNombre, nuevoNombre);
            System.out.println("Nombre del supermercado modificado exitosamente.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void eliminarSupermercado() {
        System.out.println("Ingrese el nombre del supermercado a eliminar: ");
        String name = in.nextLine();
        try {
            cntrUsuario.eliminarSupermercado(name);
            System.out.println("Supermercado eliminado exitosamente.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void duplicarSupermercado() {
        System.out.println("Ingrese el nombre del supermercado a duplicar: ");
        String nombreOriginal = in.nextLine();
        System.out.println("Ingrese el nuevo nombre para el supermercado duplicado: ");
        String nombreDuplicado = in.nextLine();
        try {
            cntrUsuario.duplicarSupermercado(nombreOriginal, nombreDuplicado);
            System.out.println("Supermercado duplicado exitosamente.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void anadirProducto() {
        System.out.println("Ingrese el nombre del supermercado: ");
        String supermercado = in.nextLine();
        System.out.println("Ingrese el nombre del producto: ");
        String producto = in.nextLine();
        System.out.println("Ingrese el precio del producto: ");
        double precio = Double.parseDouble(in.nextLine());
        try {
            cntrUsuario.anadirProducto(supermercado, producto, precio);
            System.out.println("Producto añadido exitosamente.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void modificarProducto() {
        System.out.println("Ingrese el nombre del supermercado: ");
        String supermercado = in.nextLine();
        System.out.println("Ingrese el nombre actual del producto: ");
        String producto = in.nextLine();
        System.out.println("Ingrese el nuevo nombre del producto: ");
        String productoNuevo = in.nextLine();
        System.out.println("Ingrese el nuevo precio del producto: ");
        double precio = Double.parseDouble(in.nextLine());
        try {
            cntrUsuario.modificarProducto(supermercado, producto, productoNuevo, precio);
            System.out.println("Producto modificado exitosamente.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void eliminarProducto() {
        System.out.println("Ingrese el nombre del supermercado: ");
        String supermercado = in.nextLine();
        System.out.println("Ingrese el nombre del producto: ");
        String producto = in.nextLine();
        try {
            cntrUsuario.eliminarProducto(supermercado, producto);
            System.out.println("Producto eliminado exitosamente.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void intercambiarProductos() {
        System.out.println("Ingrese el nombre del supermercado: ");
        String supermercado = in.nextLine();
        System.out.println("Ingrese el nombre del primer producto: ");
        String producto1 = in.nextLine();
        System.out.println("Ingrese el nombre del segundo producto: ");
        String producto2 = in.nextLine();
        try {
            cntrUsuario.intercambiarProductos(supermercado, producto1, producto2);
            System.out.println("Productos intercambiados exitosamente.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void consultaStock() {
        System.out.println("Ingrese el nombre del supermercado: ");
        String supermercado = in.nextLine();
        try {
            ArrayList<String> stock = cntrUsuario.consultaStock(supermercado);
            System.out.println("Stock del producto:");
            stock.forEach(System.out::println);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void consultaProducto() {
        System.out.println("Ingrese el nombre del supermercado: ");
        String supermercado = in.nextLine();
        System.out.println("Ingrese el nombre del producto: ");
        String producto = in.nextLine();
        try {
            ArrayList<String> detalles = cntrUsuario.consultaProducto(supermercado, producto);
            System.out.println("Detalles del producto:");
            detalles.forEach(System.out::println);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void crearSimilitud() {
        System.out.println("Ingrese el nombre del supermercado: ");
        String supermercado = in.nextLine();
        System.out.println("Ingrese el nombre del primer producto: ");
        String producto1 = in.nextLine();
        System.out.println("Ingrese el nombre del segundo producto: ");
        String producto2 = in.nextLine();
        System.out.println("Ingrese la similitud: ");
        int similitud = Integer.parseInt(in.nextLine());
        try {
            cntrUsuario.crearSimilitud(supermercado, producto1, producto2, similitud);
            System.out.println("Similitud creada exitosamente.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void modificarSimilitud() {
        System.out.println("Ingrese el nombre del supermercado: ");
        String supermercado = in.nextLine();
        System.out.println("Ingrese el nombre del primer producto: ");
        String producto1 = in.nextLine();
        System.out.println("Ingrese el nombre del segundo producto: ");
        String producto2 = in.nextLine();
        System.out.println("Ingrese la nueva similitud: ");
        int similitud = Integer.parseInt(in.nextLine());
        try {
            cntrUsuario.modificarSimilitud(supermercado, producto1, producto2, similitud);
            System.out.println("Similitud modificada exitosamente.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void eliminarSimilitud() {
        System.out.println("Ingrese el nombre del supermercado: ");
        String supermercado = in.nextLine();
        System.out.println("Ingrese el nombre del primer producto: ");
        String producto1 = in.nextLine();
        System.out.println("Ingrese el nombre del segundo producto: ");
        String producto2 = in.nextLine();
        try {
            cntrUsuario.eliminarSimilitud(supermercado, producto1, producto2);
            System.out.println("Similitud eliminada exitosamente.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void consultaSimilitud(){
        System.out.println("Ingrese el nombre del supermercado: ");
        String supermercado = in.nextLine();
        System.out.println("Ingrese el nombre del primer producto: ");
        String producto1 = in.nextLine();
        System.out.println("Ingrese el nombre del segundo producto: ");
        String producto2 = in.nextLine();
        try {
            Integer sim  = cntrUsuario.consultaSimilitud(supermercado, producto1, producto2);
            System.out.println("El Procentaje de Similitud es ");
            System.out.println(sim);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void cambiarAlgoritmo(){
        System.out.println("Ingrese el nombre del supermercado: ");
        String supermercado = in.nextLine();
        System.out.println("Ingrese el nombre del algoritmo: ");
        String algoritmo = in.nextLine();
        try{
            cntrUsuario.cambiarAlgoritmo(supermercado, algoritmo);
            System.out.println("Algoritmo cambiado exitosamente.");
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] args) {
        DriverUsuario d = new DriverUsuario();
        System.out.println("Driver de Usuario (PROP Grupo 32.5)");
        System.out.println("");
        d.Usage();
        System.out.println("Seleccione opcion: ");
        String cmd = d.in.nextLine();
        while (!cmd.equals("-1") && !cmd.equals("end")) {
            switch (cmd) {
                case "0":
                    System.out.println("Opcion 0: crearPerfil");
                    d.crearPerfil();
                    System.out.println("Opcion 0 finalizada");
                    break;

                case "1":
                    System.out.println("Opcion 1: modificarPerfil");
                    d.modificarPerfil();
                    System.out.println("Opcion 1 finalizada");
                    break;

                case "2":
                    System.out.println("Opcion 2: eliminarPerfil");
                    d.eliminarPerfil();
                    System.out.println("Opcion 2 finalizada");
                    break;

                case "3":
                    System.out.println("Opcion 3: generarSupermercado");
                    d.generarSupermercado();
                    System.out.println("Opcion 3 finalizada");
                    break;

                case "4":
                    System.out.println("Opcion 4: consultarSupermercado");
                    d.consultarSupermercado();
                    System.out.println("Opcion 4 finalizada");
                    break;

                case "5":
                    System.out.println("Opcion 5: modificarNombreSupermercado");
                    d.modificarNombreSupermercado();
                    System.out.println("Opcion 5 finalizada");
                    break;

                case "6":
                    System.out.println("Opcion 6: eliminarSupermercado");
                    d.eliminarSupermercado();
                    System.out.println("Opcion 6 finalizada");
                    break;

                case "7":
                    System.out.println("Opcion 7: duplicarSupermercado");
                    d.duplicarSupermercado();
                    System.out.println("Opcion 7 finalizada");
                    break;

                case "8":
                    System.out.println("Opcion 8: anadirProducto");
                    d.anadirProducto();
                    System.out.println("Opcion 8 finalizada");
                    break;

                case "9":
                    System.out.println("Opcion 9: modificarProducto");
                    d.modificarProducto();
                    System.out.println("Opcion 9 finalizada");
                    break;

                case "10":
                    System.out.println("Opcion 10: eliminarProducto");
                    d.eliminarProducto();
                    System.out.println("Opcion 10 finalizada");
                    break;

                case "11":
                    System.out.println("Opcion 11: intercambiarProductos");
                    d.intercambiarProductos();
                    System.out.println("Opcion 11 finalizada");
                    break;

                case "12":
                    System.out.println("Opcion 12: consultaStock");
                    d.consultaStock();
                    System.out.println("Opcion 12 finalizada");
                    break;

                case "13":
                    System.out.println("Opcion 13: consultaProducto");
                    d.consultaProducto();
                    System.out.println("Opcion 13 finalizada");
                    break;

                case "14":
                    System.out.println("Opcion 14: crearSimilitud");
                    d.crearSimilitud();
                    System.out.println("Opcion 14 finalizada");
                    break;

                case "15":
                    System.out.println("Opcion 15: modificarSimilitud");
                    d.modificarSimilitud();
                    System.out.println("Opcion 15 finalizada");
                    break;

                case "16":
                    System.out.println("Opcion 16: eliminarSimilitud");
                    d.eliminarSimilitud();
                    System.out.println("Opcion 16 finalizada");
                    break;

                case "17":
                    System.out.println("Opcion 17: consultaSimilitud");
                    d.consultaSimilitud(); //queda estas
                    System.out.println("Opcion 17 finalizada");
                    break;

                case "18":
                    System.out.println("Opcion 18: cambiarAlgoritmo");
                    d.cambiarAlgoritmo(); //queda esta
                    System.out.println("Opcion 18 finalizada");
                    break;

                case "-1":
                case "end":
                    System.out.println("Fin del programa.");
                    break;

                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
            System.out.println("Dale enter para mostrar las opciones disponibles");
            d.in.nextLine();
            System.out.println("");
            d.Usage();
            System.out.println("Seleccione opcion: ");
            cmd = d.in.nextLine();
        }
        d.in.close();
    }
}
