package src.drivers;

import src.main.domain.controllers.CtrlDominio;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Este Driver sirve para provar los metodos puramente de CtrlDominio. Permite al Usuario provar
 * diferentes metodos atraves de una interfice por terminal. Permite ejecutar metodos proporcionados por CtrlDominio
 * @author Andres Lucian Laptes Costan (andres.lucian.laptes@estudiantat.upc.edu)
 * */
public class DriverDominio {
    private static CtrlDominio ctrlDominio = new CtrlDominio();
    private static boolean registrado = false;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Bienvenido");
        mostrarUsoRegistro();
        boolean first = true;

        while(true){
            String input = scanner.nextLine().trim();
            String[] partes = input.split(" ");

            if (partes[0].equalsIgnoreCase("salir")) {
                System.out.println("Saliendo...");
                break;
            }

            if (!registrado) {
                if (!first) {
                    mostrarUsoRegistro();
                    first = true;
                }
                switch (partes[0]){
                    case "crearPerfil": {
                        if (partes.length == 5) {
                            try {
                                ctrlDominio.crearPerfil(partes[1], partes[2], partes[3], partes[4]);
                                registrado = true;
                                System.out.println("Usuario creado");
                                System.out.println("Dale a enter para continuar");
                                String nada = scanner.nextLine();
                                mostrarUsoComandos();
                            } catch (Exception e) {
                                System.out.println(e.getMessage());
                                System.out.println("Dale a enter para continuar");
                                String nada = scanner.nextLine();
                                mostrarUsoRegistro();
                            }
                        }
                        else System.out.println("Numero de parametros invalido");
                        break;
                    }
                    case "logIn": {
                        if (partes.length == 3) {
                            try {
                                registrado = ctrlDominio.logIn(partes[1], partes[2]);
                            } catch (Exception e) {
                                System.out.println(e.getMessage());
                            }
                            if(registrado){
                                System.out.println("Iniciada la sesion");
                                mostrarUsoComandos();
                            }
                        }
                        else System.out.println("Numero de parametros invalido");
                        break;
                    }
                    default: {
                        System.out.println("Comando invalido");
                        System.out.println("Dale a enter para continuar");
                        String nada = scanner.nextLine();
                        mostrarUsoRegistro();
                        break;
                    }
                }
            }
            else{
                switch (partes[0]){
                    case "modificarPerfil":{
                        if(partes.length == 5){
                            ctrlDominio.modificarPerfil(partes[1], partes[2], partes[3], partes[4]);
                            System.out.println("Perfil modificado");
                        }
                        else System.out.println("Numero de parametros invalido");
                        break;
                    }
                    case "eliminarPerfil":{
                        if(partes.length == 1){
                            ctrlDominio.eliminarPerfil();
                            System.out.println("Perfil eliminado");
                            registrado = false;
                            System.out.println("Dale a enter para continuar");
                        }
                        else System.out.println("Numero de parametros invalido");
                        break;
                    }
                    case "generarSupermercado":{
                        if (partes.length == 3){
                            ctrlDominio.generarSupermercado(partes[1], Integer.parseInt(partes[2]));
                            System.out.println("Supermercado generado");
                        }
                        else System.out.println("Numero de parametros invalido");
                        break;
                    }
                    case "modificarSupermercado":{
                        if(partes.length == 3){
                            ctrlDominio.modificarSupermercado(partes[1], partes[2]);
                            System.out.println("Supermercado modificado");
                        }
                        else System.out.println("Numero de parametros invalido");
                        break;
                    }
                    case "borrarSupermercados":{
                        if(partes.length == 1){
                            ctrlDominio.borrarSupermercados();
                            System.out.println("Supermercados borrados");
                        }
                        else System.out.println("Numero de parametros invalido");
                        break;
                    }
                    case "eliminarSupermercado":{
                        if(partes.length == 2){
                            try {
                                ctrlDominio.eliminarSupermercado(partes[1]);
                                System.out.println("Supermercado borrado");
                            } catch (Exception e) {
                                System.out.println(e.getMessage());
                            }
                        }
                        else System.out.println("Numero de parametros invalido");
                        break;
                    }
                    case "duplicarSupermercado":{
                        if(partes.length == 3){
                            ctrlDominio.duplicarSupermercado(partes[1], partes[2]);
                            System.out.println("Supermercado duplicado");
                        }
                        else System.out.println("Numero de parametros invalido");
                        break;
                    }
                    case "seleccionarIdioma":{
                        if(partes.length == 2){
                            ctrlDominio.seleccionaIdioma(partes[1]);
                            System.out.println("Idioma seleccionado");
                        }
                        else System.out.println("Numero de parametros invalido");
                        break;
                    }
                    case "consultarSupermercado": {
                        if(partes.length == 2){
                            ArrayList<String> lista = ctrlDominio.consultaSupermercado(partes[1]);
                            System.out.println(lista);
                        }
                        else System.out.println("Numero de parametros invalido");
                        break;
                    }
                    case "logOut":{
                        if(partes.length == 1){
                            registrado = false;
                            System.out.println("Sesion Cerrada");
                            mostrarUsoRegistro();
                        }
                        else System.out.println("Numero de parametros invalido");
                        break;
                    }
                    case "anyadirProducto":{
                        if(partes.length == 4){
                            try {
                                double precio = Double.parseDouble(partes[3]);
                                ctrlDominio.anadirProducto(partes[1], partes[2], precio);
                                System.out.println("Producto anyadido");
                            }
                            catch (NumberFormatException e){
                                System.out.println("Error: Parametros invalidos");
                            }
                        }
                        else System.out.println("Numero de parametros invalido");
                        break;
                    }
                    case "modificarProducto":{
                        if(partes.length == 5){
                            try {
                                double precio = Double.parseDouble(partes[4]);
                                ctrlDominio.modificarProducto(partes[1], partes[2], partes[3], precio);
                                System.out.println("Producto modificado");
                            }
                            catch (NumberFormatException e){
                                System.out.println("Error: Parametros invalidos");
                            }
                        }
                        else System.out.println("Numero de parametros invalido");
                        break;
                    }
                    case "eliminarProducto":{
                        if(partes.length == 3){
                            try {
                                ctrlDominio.eliminarProducto(partes[1], partes[2]);
                                System.out.println("Producto eliminado");
                            } catch (Exception e) {
                                System.out.println(e.getMessage());
                            }
                        }
                        else System.out.println("Numero de parametros invalido");
                        break;
                    }
                    case "cambiarAlgoritmo":{
                        if(partes.length == 3){
                            try {
                                ctrlDominio.cambiarAlgoritmo(partes[1], partes[2]);
                                System.out.println("Algoritmo cambiado");
                            } catch (Exception e) {
                                System.out.println(e.getMessage());
                            }
                        }
                        else System.out.println("Numero de parametros invalido");
                        break;
                    }
                    case "intercambiarProductos":{
                        if(partes.length == 4) {
                            ctrlDominio.intercambiarProductos(partes[1], partes[2], partes[3]);
                            System.out.println("Productos intercambiados");
                        }
                        else System.out.println("Numero de parametros invalido");
                        break;
                    }
                    case "consultarStock":{
                        if(partes.length == 2){
                            ArrayList<String> stock = ctrlDominio.consultaStock(partes[1]);
                            System.out.println(stock);
                        }
                        else System.out.println("Numero de parametros invalido");
                        break;
                    }
                    case "consultarProducto":{
                        if(partes.length == 3){
                            ArrayList<String> lista = ctrlDominio.consultaProducto(partes[1], partes[2]);
                            System.out.println(lista);
                        }
                        else System.out.println("Numero de parametros invalido");
                        break;
                    }
                    case "crearSimilitud":{
                        if(partes.length == 5){
                            try {
                                int similitud = Integer.parseInt(partes[4]);
                                ctrlDominio.crearSimilitud(partes[1], partes[2], partes[3], similitud);
                                System.out.println("Similitud creada");
                            }
                            catch (Exception e){
                                System.out.println("Error: Parametros invalidos");
                            }
                        }
                        else System.out.println("Numero de parametros invalido");
                        break;
                    }
                    case "modificarSimilitud": {
                        if (partes.length == 5) {
                            try {
                                int similitud = Integer.parseInt(partes[4]);
                                ctrlDominio.modificarSimilitud(partes[1], partes[2], partes[3], similitud);
                                System.out.println("Similitud modificada");
                            } catch (Exception e) {
                                System.out.println(e.getMessage());
                            }
                        }
                        else System.out.println("Numero de parametros invalido");
                        break;
                    }
                    case "eliminarSimilitud": {
                        if (partes.length == 4) {
                            try {
                                ctrlDominio.eliminarSimilitud(partes[1], partes[2], partes[3]);
                                System.out.println("Similitud eliminada");
                            } catch (NumberFormatException e) {
                                System.out.println("Error: Parametros invalidos");
                            }
                        }
                        else System.out.println("Numero de parametros invalido");
                        break;
                    }
                    case "consultarSimilitud":{
                        if(partes.length == 4){
                            try {
                                int value = ctrlDominio.consultaSimilitud(partes[1], partes[2], partes[3]);
                                System.out.println("Similitud consultada: " + value);
                            } catch (Exception e) {
                                System.out.println(e.getMessage());
                            }
                        }
                        else System.out.println("Numero de parametros invalido");
                        break;
                    }
                    case "getDatosUsuario": {
                        ArrayList<String> aux = ctrlDominio.getDatosUsuarios();
                        for (int i = 0; i < aux.size(); i += 2) {
                            System.out.println(aux.get(i) + aux.get(i + 1));
                        }
                        break;
                    }
                    case "consultarDistribucionSupermercado" : {
                        if (partes.length == 2) {
                            try {
                                ArrayList<String> aux = ctrlDominio.consultarDistribucion(partes[1]);
                                for (int i = 0; i < aux.size(); ++i) {
                                    System.out.print(aux.get(i));
                                }
                            } catch (Exception e) {
                                System.out.println(e.getMessage());
                            }
                        }
                        break;
                    }
                    default:{
                        System.out.println("Comando invalido");
                        mostrarUsoComandos();
                        break;
                    }
                }
                if (registrado) {
                    System.out.println("Añade tu siguiente comando");
                }
            }
        }
    }
    private static void mostrarUsoRegistro(){
        System.out.println("Registrate o inicia sesion\n");
        System.out.println("Iniciar sesion -> logIn <nombre usuario> <contrasenya>");
        System.out.println("Registrarse -> crearPerfil <nombre usuario> <contrasenya> <correo> <idioma>");
        System.out.println("Salir -> salir\n");
    }

    private static void mostrarUsoComandos(){
        System.out.println("Ejecuta un comando \n");
        System.out.println("Modificar Perfil -> modificarPerfil <nuevoNombreUsuario> <contrasenya> <idioma> <correo>");
        System.out.println("Eliminar Perfil -> eliminarPerfil");
        System.out.println("Generar Supermercado -> generarSupermercado <Nombre supermercado> <NumeroEstanterias>");
        System.out.println("Modificar Supermercado -> modificarSupermercado <supermercado>");
        System.out.println("Borrar Supermercados -> borrarSupermercados");
        System.out.println("Eliminar Supermercado -> eliminarSupermercado <supermercado>");
        System.out.println("Duplicar Supermercado -> duplicarSupermercado <supermercado> <supermercado nuevo>");
        System.out.println("Seleccionar Idioma -> seleccionarIdioma <idioma>");
        System.out.println("Consultar Supermercado -> consultarSupermercado <supermercado>");
        System.out.println("Log Out -> logOut");
        System.out.println("Consultar datos de Usuario actual -> getDatosUsuario");
        System.out.println("Anyadir Producto -> anyadirProducto <supermercado> <producto> <precio>");
        System.out.println("Modificar Producto -> modificarProducto <supermercado> <Nombre producto> <Nuevo Nombre Producto> <Nuevo Precio>");
        System.out.println("Eliminar Producto -> eliminarProducto <supermercado> <producto>");
        System.out.println("Cambiar Algoritmo -> cambiarProducto <supermercado> <algoritmo>");
        System.out.println("Intercambiar Productos -> intercambiarProductos <supermercado> <producto1> <producto2>");
        System.out.println("Consultar Stock -> consultarStock <supermercado>");
        System.out.println("Consultar Distribucion Supermercado -> consultarDistribucionSupermercado <Nombre Supermercado>");
        System.out.println("Consultar Producto -> consultarProducto <supermercado> <producto>");
        System.out.println("Crear Similitud -> crearSimilitud <supermercado> <producto1> <producto2> <similitud>");
        System.out.println("Modificar Similitud -> modificarSimilitud <supermercado> <producto1> <producto2> <similitud>");
        System.out.println("Eliminar Similitud -> eliminarSimilitud <supermercado> <producto1> <producto2> <similitud>");
        System.out.println("Consultar Similitud -> consultarSimilitud <supermercado> <producto1> <producto2>");
        System.out.println("Salir -> salir\n");
    }
}
