package src.drivers;

import src.main.domain.controllers.CtrlProducto;
import src.main.domain.classes.Producto;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.*;

/**
 * Este Driver sirve para provar los metodos puramente de CtrlProducto. Permite al Usuario provar
 * diferentes metodos a traves de una interfice por terminal. Permite ejecutar metodos proporcionados por CtrlProducto
 * @author Asier García Elvira (asier.garcia@estudiantat.upc.edu)
 * */
public class DriverProducto {

    private CtrlProducto ctrlProd;
    private Scanner scanner;

    public DriverProducto(CtrlProducto ctrlProd) {
        this.ctrlProd = ctrlProd;
        this.scanner = new Scanner(System.in);
    }

    private void Usage() {
        System.out.println("Usage: seleccione una de las opciones");
        System.out.println("    Finaliza al obtener un -1 o un end");
        System.out.println("Opción 0: getProducto");
        System.out.println("Opción 1: modificarProducto");
        System.out.println("Opcion 2: crearSimilitud");
        System.out.println("Opcion 3: modificarSimilitud");
        System.out.println("Opcion 4: eliminarSimilitud");
        System.out.println("Opcion 5: consultarSimilitud");
        System.out.println("Opcion 6: consultarSimilitudes");
        System.out.println("Opcion 7: existsProducto");
        System.out.println("Opcion 8: agregarProducto");
        System.out.println("Opcion 9: eliminarProducto");
        System.out.println("Opcion 10: getDatosSuperProd");
        System.out.println("Opcion 11: getProductos");

    }

    // Opcion 0: Obtener producto
    public void getProducto() {
        // Pedir el nombre del supermercado
        System.out.println("Introduce el nombre del supermercado al que pertenecen los productos:");
        String Super = scanner.nextLine();

        // Pedir nombre del producto
        System.out.println("Introduce el nombre del primer producto:");
        String prod1 = scanner.nextLine();

        Producto producto = ctrlProd.getProducto(Super, prod1);
        System.out.println("Producto: " + producto.getNombre() + ", Precio: " + producto.getPrecio());
    }

    // Opcion 1: Modificar producto
    public void modificarProducto() {
        System.out.println("Introduce el nombre del supermercado al que pertenece le producto:");
        String Super = scanner.nextLine();

        System.out.println("Introduce el nombre del producto:");
        String Nombre = scanner.nextLine();

        System.out.println("Introduce nuevo nombre del producto:");
        String nuevoNombre = scanner.nextLine();
        double nuevoPrecio = -1;

        // Intentar leer el nuevo precio
        while (true) {
            try {
                System.out.println("Introduce nuevo precio del producto:");
                nuevoPrecio = Double.parseDouble(scanner.nextLine());
                break;  // Si es válido, salimos del bucle
            } catch (NumberFormatException e) {
                System.out.println("Error: Por favor ingresa un valor numérico válido para el precio.");
            }
        }

        ctrlProd.modificarProducto(Nombre, nuevoNombre, nuevoPrecio, Super);
        System.out.println("Producto modificado con éxito.");
    }

    // Opcion 2: Crear similitud
    public void crearSimilitud() {
        // Pedir el nombre del supermercado
        System.out.println("Introduce el nombre del supermercado al que pertenecen los productos:");
        String Super = scanner.nextLine();

        // Pedir nombre del producto
        System.out.println("Introduce el nombre del primer producto:");
        String prod1 = scanner.nextLine();

        System.out.println("Introduce el nombre del primer producto:");
        String prod2 = scanner.nextLine();

        // Pedir el porcentaje de similitud
        int porcentajeSimilitud = -1;
        while (porcentajeSimilitud == -1) {
            try {
                System.out.println("Introduce el porcentaje de similitud:");
                porcentajeSimilitud = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Error: Por favor ingresa un valor numérico válido para el porcentaje de similitud.");
            }
        }

        // Llamar al método de CtrlProducto para crear la similitud
        ctrlProd.crearSimilitud(Super, prod1, prod2, porcentajeSimilitud);
        System.out.println("Similitud creada con éxito.");
    }

    // Opcion 3: Modificar similitud
    public void modificarSimilitud() {
        // Pedir el nombre del supermercado
        System.out.println("Introduce el nombre del supermercado al que pertenecen los productos:");
        String Super = scanner.nextLine();

        // Pedir nombre del producto
        System.out.println("Introduce el nombre del primer producto:");
        String prod1 = scanner.nextLine();

        System.out.println("Introduce el nombre del primer producto:");
        String prod2 = scanner.nextLine();

        // Pedir el porcentaje de similitud
        int newporcentajeSimilitud = -1;
        while (newporcentajeSimilitud == -1) {
            try {
                System.out.println("Introduce el nuevo porcentaje de similitud:");
                newporcentajeSimilitud = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Error: Por favor ingresa un valor numérico válido para el porcentaje de similitud.");
            }
        }

        // Llamar al método de CtrlProducto para modificar la similitud
        ctrlProd.modificarSimilitud(Super, prod1, prod2, newporcentajeSimilitud);
        System.out.println("Similitud modificada con éxito.");
    }

    // Opcion 4: Eliminar similitud
    public void eliminarSimilitud() {
        // Pedir el nombre del supermercado
        System.out.println("Introduce el nombre del supermercado al que pertenecen los productos:");
        String Super = scanner.nextLine();

        // Pedir nombre del producto
        System.out.println("Introduce el nombre del primer producto:");
        String prod1 = scanner.nextLine();

        System.out.println("Introduce el nombre del primer producto:");
        String prod2 = scanner.nextLine();

        // Llamar al método de CtrlProducto para eliminar la similitud
        ctrlProd.eliminarSimilitud(Super, prod1, prod2);
        System.out.println("Similitud eliminada con éxito.");
    }

    // Opcion 5: Consultar similitud
    public void consultarSimilitud() {
        // Pedir el nombre del supermercado
        System.out.println("Introduce el nombre del supermercado al que pertenecen los productos:");
        String Super = scanner.nextLine();

        // Pedir nombre del producto
        System.out.println("Introduce el nombre del primer producto:");
        String prod1 = scanner.nextLine();

        System.out.println("Introduce el nombre del primer producto:");
        String prod2 = scanner.nextLine();

        // Llamar al método de CtrlProducto para consultar la similitud
        int similitud = ctrlProd.consultarSimilitud(Super, prod1, prod2);
        System.out.println("Similitud con el producto: " + similitud + "%");
    }

    // Opcion 6: Consultar todas las similitudes
    public void consultarSimilitudes() {
        // Pedir el nombre del supermercado
        System.out.println("Introduce el nombre del supermercado al que pertenecen los productos:");
        String Super = scanner.nextLine();

        // Pedir nombre del producto
        System.out.println("Introduce el nombre del producto:");
        String prod1 = scanner.nextLine();


        ArrayList<String> similitudes = ctrlProd.consultarSimilitudes(Super, prod1);
        for (String similitud : similitudes) {
            System.out.println(similitud);
        }
    }

    //Opcion 7: Existe un producto
    public void existsProducto() {

        System.out.println("Introduce el nombre del supermercado al que pertenece el producto:");
        String Super = scanner.nextLine();

        System.out.println("Introduce el nombre del producto:");
        String prod = scanner.nextLine();

        boolean exists = ctrlProd.existsProducto(Super, prod);
        if(exists) System.out.println("El producto existe");
        else System.out.println("El producto no existe");

    }

    //Opcion 8: Agregar un producto
    public void agregarProducto() {

        System.out.println("Introduce el nombre del supermercado al que pertenece el producto:");
        String Super = scanner.nextLine();

        System.out.println("Introduce el nombre del producto:");
        String prod = scanner.nextLine();

        int ultimoId = -1;
        while (ultimoId == -1) {
            try {
                System.out.println("Introduce el nuevo porcentaje de similitud:");
                ultimoId = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Error: Por favor ingresa un valor numérico válido para el porcentaje de similitud.");
            }
        }

        double precio = -1;
        while (precio == -1) {
            try {
                System.out.println("Introduce el nuevo porcentaje de similitud:");
                precio = Double.parseDouble(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Error: Por favor ingresa un valor numérico válido para el porcentaje de similitud.");
            }
        }

        ctrlProd.agregarProducto(Super, prod, ultimoId, precio);
        System.out.println("Producto agregado con exito");
    }

    //Opcion 9: Eliminar un producto
    public void eliminarProducto() {

        System.out.println("Introduce el nombre del supermercado al que pertenece el producto:");
        String Super = scanner.nextLine();

        System.out.println("Introduce el nombre del producto:");
        String prod = scanner.nextLine();

        ctrlProd.eliminarProducto(Super, prod);
        System.out.println("Producto eliminado con exito");
    }

    //Opcion 10: Obtener datos de un producto
    public void getDatosSuperProd() {
        System.out.println("Introduce el nombre del supermercado al que pertenece el producto:");
        String Super = scanner.nextLine();
        ArrayList<Map<String, Object>> datosProducto = ctrlProd.getDatosSuperProd(Super, "null");
        System.out.println("Información del producto:");
        /*for (Map.Entry<String, Object> entry : datosProducto.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }*/
    }

    //Opcion 11: Obtener datos de un producto
    public void getProductos() {
        System.out.println("Introduce el nombre del supermercado al que pertenece el producto:");
        String Super = scanner.nextLine();

        ArrayList<Producto> prods = ctrlProd.getProductos(Super);

        for(Producto prod : prods) {
            System.out.println(prod.getNombre() + " " + prod.getId() + " " + prod.getPrecio() + " " + prod.getSimilitudes());
        }
    }


    // Método principal para ejecutar el Driver
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Pedir los datos del producto al usuario
        System.out.println("Introduce los datos para el producto:");

        // Pedir ID del producto
        int id = -1;
        while (id == -1) {
            try {
                System.out.println("Introduce el ID del producto:");
                id = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Error: Por favor ingresa un valor numérico válido para el ID.");
            }
        }

        // Pedir nombre del producto
        System.out.println("Introduce el nombre del producto:");
        String nombre = scanner.nextLine();

        // Pedir precio del producto
        double precio = -1;
        while (precio == -1) {
            try {
                System.out.println("Introduce el precio del producto:");
                precio = Double.parseDouble(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Error: Por favor ingresa un valor numérico válido para el precio.");
            }
        }

        // Crear el CtrlProducto con los datos proporcionados
        CtrlProducto ctrlProd = new CtrlProducto(nombre, id, precio, "SuperPrueba");

        // Crear el DriverProducto y ejecutar la interacción
        DriverProducto dp = new DriverProducto(ctrlProd);
        dp.Usage();

        // Continuar con la interacción
        while (true) {
            System.out.println("Seleccione opción (-1 para salir): ");
            String cmd = dp.scanner.nextLine();

            if (cmd.equals("-1") || cmd.equals("end")) {
                break;
            }

            switch (cmd) {
                case "0":
                    dp.getProducto();
                    break;
                case "1":
                    dp.modificarProducto();
                    break;
                case "2":
                    dp.crearSimilitud();
                    break;
                case "3":
                    dp.modificarSimilitud();
                    break;
                case "4":
                    dp.eliminarSimilitud();
                    break;
                case "5":
                    dp.consultarSimilitud();
                    break;
                case "6":
                    dp.consultarSimilitudes();
                    break;
                case "7":
                    dp.existsProducto();
                    break;
                case "8":
                    dp.agregarProducto();
                    break;
                case "9":
                    dp.eliminarProducto();
                    break;
                case "10":
                    dp.getDatosSuperProd();
                    break;
                case "11":
                    dp.getProductos();
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        }
        dp.scanner.close();
    }
}
