package src.drivers;

import src.main.domain.controllers.CtrlAlgoritmo;
import src.main.domain.classes.exceptions.ExcepcionNoAlgoritmo;
import src.main.domain.classes.exceptions.ExcepcionTamanyosDistintos;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Este Driver sirve para provar los metodos de CtrlAlgoritmo. Permite al Usuario provar
 * diferentes metodos atraves de una interfice por terminal. Permite ejecutar metodos proporcionados por CtrlAlgoritmo
 * @author Asier García Elvira (asier.garcia@estudiantat.upc.edu)
 * */
public class DriverCtrlAlgoritmo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicitar el algoritmo al usuario
        String algoritmo = "";
        while (true) {
            System.out.println("Elige el algoritmo: Backtracking, HillClimbing, Aproximacion");
            algoritmo = scanner.nextLine().trim();
            if (algoritmo.equalsIgnoreCase("Backtracking") || algoritmo.equalsIgnoreCase("HillClimbing") || algoritmo.equalsIgnoreCase("Aproximacion")) {
                break;
            } else {
                System.out.println("Error: Algoritmo invalido, escoge entre -> Backtracking, HillClimbing, Aproximacion");
            }
        }

        // Crear instancia de CtrlAlgoritmo
        CtrlAlgoritmo ctrlAlgoritmo;
        try {
            ctrlAlgoritmo = new CtrlAlgoritmo(algoritmo);
        } catch (ExcepcionNoAlgoritmo e) {
            System.out.println("Error: " + e.getMessage());
            return;
        }

        // Pedir la cantidad de productos y posiciones
        int n = 0;
        while (true) {
            System.out.println("Introduce el número de productos:");
            try {
                n = scanner.nextInt();
                if (n > 0) {
                    break;
                } else {
                    System.out.println("Error: El número de productos debe ser un número positivo.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Error: Por favor, ingresa un número entero válido.");
                scanner.nextLine(); // Limpiar el buffer
            }
        }

        // Ingresar la matriz de similitudes
        System.out.println("Introduce la matriz de similitudes (valores enteros):");
        ArrayList<ArrayList<Integer>> similitudes = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            ArrayList<Integer> fila = new ArrayList<>();
            for (int j = 0; j < n; j++) {
                while (true) {
                    try {
                        fila.add(scanner.nextInt());
                        break;
                    } catch (InputMismatchException e) {
                        System.out.println("Error: Por favor, ingresa un valor entero.");
                        scanner.nextLine(); // Limpiar el buffer
                    }
                }
            }
            similitudes.add(fila);
        }

        // Ingresar la lista de posiciones
        System.out.println("Introduce las posiciones iniciales de los productos:");
        ArrayList<Integer> posiciones = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            while (true) {
                try {
                    posiciones.add(scanner.nextInt());
                    break;
                } catch (InputMismatchException e) {
                    System.out.println("Error: Por favor, ingresa un valor entero para la posición.");
                    scanner.nextLine(); // Limpiar el buffer
                }
            }
        }

        // Generar la solución
        try {
            ArrayList<Integer> solucion = ctrlAlgoritmo.getSolucion(similitudes, posiciones);
            System.out.println("Solución encontrada: " + solucion);
        } catch (ExcepcionTamanyosDistintos e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}