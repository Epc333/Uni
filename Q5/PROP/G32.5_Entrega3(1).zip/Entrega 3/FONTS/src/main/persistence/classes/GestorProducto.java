package src.main.persistence.classes;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import src.main.domain.classes.Producto;

import javax.lang.model.type.ArrayType;
import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.lang.Number;

/**
 * Esta clase representa un gestor de productos. 
 * Permite cargar y gestionar los productos usados en el programa.
 * @author Andres Lucian Laptes Costan (andres.lucian.laptes@estudiantat.upc.edu)
 */
public class GestorProducto {

    /**
     * Transforma los datos de las similitudes de los productos a un formato adecuado.
     * @param data Lista de similitudes de productos.
     * @return Lista de similitudos en formato adecuado.
     */
    private static ArrayList<ArrayList<Integer>> transformDataSim(ArrayList<?> data) {
        ArrayList<ArrayList<Integer>> dataSim = new ArrayList<>();
        for (Object l : data) {
            if (l instanceof ArrayList) {
                ArrayList<Integer> list = new ArrayList<>();
                for (Object o : (ArrayList) l) {
                    if (o instanceof Integer) {
                        list.add((Integer) o);
                    } else if (o instanceof Double) {
                        list.add(((Double) o).intValue());
                    }
                }
                dataSim.add(list);
            }
        }

        return dataSim;
    }

    /**
     * Transforma los datos de los productos a un formato adecuado.
     * @param data Lista de productos.
     * @return Lista de productos en formato adecuado.
     */
    private static List<Map<String, Object>> transformData(List<Map<String, Object>> data) {
        for (Map<String, Object> map : data) {
            if (map.containsKey("IdProducto")) {
                Object idProducto = map.get("IdProducto");
                if (idProducto instanceof Double) {
                    map.put("IdProducto", ((Double) idProducto).intValue());
                } else if (idProducto instanceof Integer) {
                    map.put("IdProducto", ((Integer) idProducto).intValue());
                }
            }

            if (map.containsKey("Similitudes")) {
                Object similitudes = map.get("Similitudes");
                if (similitudes instanceof ArrayList) {
                    ArrayList<ArrayList<Integer>> list = transformDataSim((ArrayList<?>) similitudes);
                    map.put("Similitudes", list);
                }
            }

        }

        return data;
    }

    /**
     * Guarda un producto en el archivo .json de productos.
     * @param producto Producto a guardar.
     */
    public static void guardarProducto(Map<String, Object> producto) {
        Gson gson = new GsonBuilder().setPrettyPrinting().enableComplexMapKeySerialization().disableHtmlEscaping().create();

        Path paths = Paths.get( "FONTS", "src", "main", "persistence", "json", "Productos.json");
        String filePath = paths.toAbsolutePath().toString();

        try {
            List<Map<String, Object>> productos;
            File file = new File(filePath);

            if (file.exists() && file.length() > 0) {
                FileReader reader = new FileReader(filePath);
                productos = gson.fromJson(reader, new TypeToken<List<Map<String, Object>>>() {}.getType());
                reader.close();
                productos = transformData(productos);
            } else {
                productos = new ArrayList<>();
            }

            if (productos == null) {
                productos = new ArrayList<>();
            }

            String nombreProducto = (String) producto.get("Nombre");
            Integer idProducto = (Integer) producto.get("IdProducto");
            String supermercado1 = (String) producto.get("Supermercado");
            String usuario = (String) producto.get("Usuario");
            boolean productoActualizado = false;

            for (int i = 0; i < productos.size(); i++) {
                String nombre = (String) productos.get(i).get("Nombre");
                Integer id = (Integer) productos.get(i).get("IdProducto");
                String supermercado2 = (String) productos.get(i).get("Supermercado");
                String usuario2 = (String) productos.get(i).get("Usuario");

                if (nombre != null && nombre.equals(nombreProducto) && id == idProducto && supermercado1.equals(supermercado2) && usuario2.equals(usuario)) {
                    productos.set(i, producto);
                    productoActualizado = true;
                    System.out.println("Producto actualizado exitosamente.");
                    break;
                }
            }

            if (!productoActualizado) {
                productos.add(producto);
                System.out.println("Nuevo producto añadido exitosamente.");
            }

            FileWriter writer = new FileWriter(filePath);
            gson.toJson(productos, writer);
            writer.close();

        } catch (IOException e) {
            System.out.println("Error al escribir el archivo: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error inesperado: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Carga los productos de un usuario y un supermercado especifico.
     * @param usuario Usuario del que se quieren cargar los productos.
     * @param supermercado Supermercado del que se quieren cargar los productos.
     * @return Mapa con los productos del usuario y supermercado pasados por parametro.
     */
    public static Map<Integer, Map<String, Object>> cargarProducto(String usuario, String supermercado) {
        Gson gson = new GsonBuilder().setPrettyPrinting().enableComplexMapKeySerialization().disableHtmlEscaping().create();

        Path paths = Paths.get( "FONTS", "src", "main", "persistence", "json", "Productos.json");
        String filePath = paths.toAbsolutePath().toString();

        try {
            FileReader reader = new FileReader(filePath);
            List<Map<String, Object>> productos = gson.fromJson(reader, new TypeToken<List<Map<String, Object>>>() {}.getType());
            reader.close();
            if (productos == null || productos.isEmpty()) {
                return null;
            }
            productos = transformData(productos);
            Map< Integer , Map<String, Object>> aux = new HashMap<>();
            for (Map<String, Object> p : productos) {
                if (p == null) continue;

                String prodSupermercado = (String) p.get("Supermercado");
                String prodNombre = (String) p.get("Nombre");
                String prodUsuario = (String) p.get("Usuario");
                Integer prodId = (Integer) p.get("IdProducto");


                if (prodSupermercado == null || prodNombre == null) continue;

                if (prodUsuario.equals(usuario) && supermercado.equals(prodSupermercado)) {
                     aux.put(prodId, p);
                }
            }
            if(!aux.isEmpty()) return aux;

            throw new IllegalArgumentException("Producto no encontrado en el supermercado especificado.");

        } catch (FileNotFoundException e) {
            throw new IllegalArgumentException("Archivo no encontrado: " + filePath);
        } catch (IOException e) {
            throw new IllegalArgumentException("Error al leer el archivo: " + e.getMessage());
        } catch (Exception e) {
            throw new IllegalArgumentException("Error inesperado: " + e.getMessage());
        }
    }

    /**
     * Elimina un producto de un usuario y supermercado especifico.
     * @param usuario Usuario del que pertenece el supermercado.
     * @param supermercado Supermercado del que se quiere eliminar el producto.
     * @param nombreProducto Nombre del producto que se quiere eliminar.
     */
    public static void eliminarProd(String usuario, String supermercado, String nombreProducto) {
        Gson gson = new GsonBuilder().setPrettyPrinting().enableComplexMapKeySerialization().disableHtmlEscaping().create();

        Path paths = Paths.get( "FONTS", "src", "main", "persistence", "json", "Productos.json");
        String filePath = paths.toAbsolutePath().toString();

        try {
            FileReader reader = new FileReader(filePath);
            List<Map<String, Object>> productos = gson.fromJson(reader, new TypeToken<List<Map<String, Object>>>() {}.getType());
            reader.close();

            productos = transformData(productos);
            if (productos == null || productos.isEmpty()) {
                throw new IllegalArgumentException("No hay productos almacenados.");
            }

            boolean productoEncontrado = false;
            for (Iterator<Map<String, Object>> iterator = productos.iterator(); iterator.hasNext(); ) {
                Map<String, Object> p = iterator.next();

                if (p == null) continue;

                String prodSupermercado = (String) p.getOrDefault("Supermercado", "").toString().trim();
                String prodNombre = (String) p.getOrDefault("Nombre", "").toString().trim();
                String prodUsuario = (String) p.getOrDefault("Usuario", "").toString().trim();
                if (usuario.trim().equalsIgnoreCase(prodUsuario) && supermercado.trim().equalsIgnoreCase(prodSupermercado) &&
                        nombreProducto.trim().equalsIgnoreCase(prodNombre)) {
                    iterator.remove();
                    productoEncontrado = true;
                    break;
                }
            }

            if (!productoEncontrado) {
                throw new IllegalArgumentException("Producto no encontrado en el supermercado especificado.");
            }

            FileWriter writer = new FileWriter(filePath);
            gson.toJson(productos, writer);
            writer.close();

            System.out.println("Producto eliminado exitosamente.");

        } catch (FileNotFoundException e) {
            throw new IllegalArgumentException("Archivo no encontrado: " + filePath);
        } catch (IOException e) {
            throw new IllegalArgumentException("Error al escribir el archivo: " + e.getMessage());
        } catch (Exception e) {
            throw new IllegalArgumentException("Error inesperado: " + e.getMessage());
        }
    }
}


