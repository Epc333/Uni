package src.main.persistence.classes;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.*;
import java.lang.reflect.Array;
import java.lang.reflect.Type;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

/**
 * Esta clase representa un gestor de supermercado. 
 * Permite cargar y gestionar los distintos supermercados y sus productos.
 * @author Andres Lucian Laptes Costan (andres.lucian.laptes@estudiantat.upc.edu)
 */
public class GestorSupermercado {

    /**
     * Constructora que inicializa un gestor de supermercado vacio.
     */
    public GestorSupermercado() {}

    /**
     * Carga el supermercado seleccionado.
     * @param sup Nombre del supermercado
     * @param usuario Nombre del usuario al que pertenece el supermercado
     * @return Mapa Devuelve la informacion del supermercado sup
     */
    public static Map<String, Object> cargarSupermercado(String sup, String usuario) {
        Gson gson =  new GsonBuilder().setPrettyPrinting().enableComplexMapKeySerialization().setDateFormat("MMM dd, yyyy, hh:mm:ss a").disableHtmlEscaping().create();;

        Path paths = Paths.get("FONTS", "src", "main", "persistence", "json", "Supermercados.json");
        String filePath = paths.toAbsolutePath().toString();

        try {
            FileReader reader = new FileReader(filePath);

            BufferedReader bufferedReader = new BufferedReader(reader);
            if (bufferedReader.readLine() == null) {
                bufferedReader.close();
                reader.close();
                return new HashMap<>();
            }

            reader = new FileReader(filePath);
            List<Map<String, Object>> supermercados = gson.fromJson(reader, List.class);
            reader.close();

            supermercados = transformData(supermercados);

            for (Map<String, Object> supermercado : supermercados) {
                String nombre = (String) supermercado.get("Nombre");
                String propietario = (String) supermercado.get("Pertenece al Usuario");

                if (nombre != null && propietario != null && nombre.equals(sup) && propietario.equals(usuario)) {
                    return supermercado;
                }
            }

            throw new IllegalArgumentException("No se ha encontrado el supermercado");
        } catch (FileNotFoundException e) {
            System.out.println("Archivo no encontrado: " + filePath);
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error inesperado: " + e.getMessage());
        }

        return null;
    }

    /**
     * Elimina el supermercado seleccionado y lo borra del archivo Supermercados.json.
     * @param sup Nombre del supermercado
     * @param usuario Nombre del usuario al que pertenece el supermercado
     */
    public static void eliminarSuper(String sup, String usuario) {
        Gson gson = new GsonBuilder().setPrettyPrinting().enableComplexMapKeySerialization().setDateFormat("MMM dd, yyyy, hh:mm:ss a").disableHtmlEscaping().create();

        Path paths = Paths.get("FONTS", "src", "main", "persistence", "json", "Supermercados.json");
        String filePath = paths.toAbsolutePath().toString();

        try {
            FileReader reader = new FileReader(filePath);
            List<Map<String, Object>> supermercados = gson.fromJson(reader, List.class);
            reader.close();

            supermercados = transformData(supermercados);

            sup = sup.trim();
            usuario = usuario.trim();

            boolean encontrado = false;
            for (Iterator<Map<String, Object>> iterator = supermercados.iterator(); iterator.hasNext();) {
                Map<String, Object> supermercado = iterator.next();
                String nombre = (String) supermercado.get("Nombre");
                String propietario = (String) supermercado.get("Pertenece al Usuario");

                if (nombre != null && propietario != null &&
                        nombre.trim().equalsIgnoreCase(sup) &&
                        propietario.trim().equalsIgnoreCase(usuario)) {
                    iterator.remove();
                    encontrado = true;
                    break;
                }
            }

            if (encontrado) {
                FileWriter writer = new FileWriter(filePath);
                gson.toJson(supermercados, writer);
                writer.close();
            } else {
                System.out.println("Supermercado no encontrado.");
            }
        } catch (FileNotFoundException e) {
            System.out.println("Archivo no encontrado: " + filePath);
        } catch (IOException e) {
            System.out.println("Error al escribir el archivo: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error inesperado: " + e.getMessage());
        }
    }

    /**
     * Devuelve los nombres de los productos del supermercado seleccionado.
     * @param sup Nombre del supermercado
     * @param usuario Nombre del usuario al que pertenece el supermercado
     * @return Lista Devuelve los nombres de los productos del supermercado sup
     */
    public static ArrayList<String> getNombresDeProductos(String sup, String usuario) {
        Gson gson =  new GsonBuilder().setPrettyPrinting().enableComplexMapKeySerialization().setDateFormat("MMM dd, yyyy, hh:mm:ss a").disableHtmlEscaping().create();;

        Path paths = Paths.get("FONTS", "src", "main", "persistence", "json", "Supermercados.json");
        String filePath = paths.toAbsolutePath().toString();

        try {
            FileReader reader = new FileReader(filePath);
            List<Map<String, Object>> supermercados = gson.fromJson(reader, List.class);
            supermercados = transformData(supermercados);
            reader.close();

            for (Map<String, Object> supermercado : supermercados) {
                String nombre = (String) supermercado.get("Nombre");
                String propietario = (String) supermercado.get("Pertenece al Usuario");

                if (nombre != null && propietario != null && nombre.equals(sup) && propietario.equals(usuario)) {
                    return (ArrayList<String>) supermercado.get("Distribucion");
                }
            }

            throw new IllegalArgumentException("No se ha encontrado el supermercado");
        } catch (FileNotFoundException e) {
            System.out.println("Archivo no encontrado: " + filePath);
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error inesperado: " + e.getMessage());
        }

        return null;
    }

    /**
     * Convierte los datos de la distribucion del supermercado seleccionado a un formato adecuado.
     * @param data Contiene la informacion del supermercado
     * @return Lista de distribucion en formato adecuado
     */
    private static ArrayList<ArrayList<Integer>> convertDataDist (List<?> data) {
        ArrayList<ArrayList<Integer>> list = new ArrayList<>();
        if (data == null) {return list;}
        for(Object lista : data) {
            ArrayList<Integer> lista1 = new ArrayList<>();
            if (lista != null) {
                if (lista instanceof List) {
                    for (Object id : (List<?>) lista) {
                        if (id instanceof Double) {
                            lista1.add(((Double) id).intValue());
                        } else if (id instanceof Integer) {
                            lista1.add((int) id);
                        }
                    }
                }
            }
            list.add(lista1);
        }
        return list;
    }

    /**
     * Convierte los datos del stock del supermercado seleccionado a un formato adecuado.
     * @param data Contiene la informacion del supermercado
     * @return Lista de stock en formato adecuado
     */
    private static ArrayList<Integer> convertDataStock (List<?> data) {
        ArrayList<Integer> list = new ArrayList<>();
        if (data == null) {return list;}

        for (Object lista : data) {
            if (lista != null) {
                if (lista instanceof Double) {
                    list.add(((Double) lista).intValue());
                } else if (lista instanceof Integer) {
                    list.add((int) lista);
                }
            }
        }

        return list;
    }

    /**
     * Transforma los datos del supermercado seleccionado a un formato adecuado.
     * @param supermercados Contiene la informacion de los supermercados
     * @return Lista de supermercados en formato adecuado
     */
    private static List<Map<String, Object>> transformData(List<Map<String, Object>> supermercados) {
        for (Map<String, Object> supermercado : supermercados) {
            if (supermercado.containsKey("Numero Estanterías")) {
                Object data = supermercado.get("Numero Estanterías");
                if (data instanceof Double) {
                    supermercado.put("Numero Estanterías", ((Double) data).intValue());
                }
            }

            if (supermercado.containsKey("Distribución")) {
                Object data = supermercado.get("Distribución");
                if (data instanceof ArrayList) {
                    ArrayList<ArrayList<Integer>> nuevosDatos = convertDataDist((List<?>) data);
                    supermercado.put("Distribución", nuevosDatos);
                }
            }

            if (supermercado.containsKey("Stock")) {
                Object data = supermercado.get("Stock");
                if (data instanceof List) {
                    ArrayList<Integer> nuevosStock = convertDataStock((List<?>) data);
                    supermercado.put("Stock", nuevosStock);
                }
            }

        }

        return supermercados;
    }

    /**
     * Guarda el supermercado seleccionado en el archivo Supermercados.json.
     * @param sup Contiene la informacion del supermercado
     */
    public static void guardarSupermercado(Map<String, Object> sup) {
        Gson gson = new GsonBuilder().setPrettyPrinting().enableComplexMapKeySerialization().setDateFormat("MMM dd, yyyy, hh:mm:ss a").disableHtmlEscaping().create();
        List<Map<String, Object>> supermercados = new ArrayList<>();

        Path paths = Paths.get("FONTS", "src", "main", "persistence", "json", "Supermercados.json");
        String filePath = paths.toAbsolutePath().toString();

        try (Reader reader = new FileReader(filePath)) {
            Type listType = new TypeToken<List<Map<String, Object>>>() {}.getType();
            supermercados = gson.fromJson(reader, listType);

            if (supermercados == null) {
                supermercados = new ArrayList<>();
            }
        } catch (FileNotFoundException e) {
            System.out.println("Archivo no encontrado, se creará uno nuevo.");
        } catch (IOException e) {
            System.err.println("Error al leer el archivo: " + e.getMessage());
        }

        supermercados = transformData(supermercados);

        String nombreNuevo = (String) sup.get("Nombre");
        String usuarioNuevo = (String) sup.get("Pertenece al Usuario");

        if (nombreNuevo == null || usuarioNuevo == null) {
            throw new IllegalArgumentException("El supermercado debe contener 'nombre' y 'Pertenece al Usuario'.");
        }

        boolean sobrescrito = false;
        for (int i = 0; i < supermercados.size(); i++) {
            Map<String, Object> supermercadoExistente = supermercados.get(i);
            String nombreExistente = (String) supermercadoExistente.get("Nombre");
            String usuarioExistente = (String) supermercadoExistente.get("Pertenece al Usuario");

            if (nombreExistente != null && usuarioExistente != null &&
                    nombreNuevo.equals(nombreExistente) && usuarioNuevo.equals(usuarioExistente)) {
                supermercados.set(i, sup);
                sobrescrito = true;
                break;
            }
        }

        if (!sobrescrito) {
            supermercados.add(sup);
        }

        try (Writer writer = new FileWriter(filePath)) {
            gson.toJson(supermercados, writer);
        } catch (IOException e) {
            System.err.println("Error al guardar el archivo: " + e.getMessage());
        }
    }
}
