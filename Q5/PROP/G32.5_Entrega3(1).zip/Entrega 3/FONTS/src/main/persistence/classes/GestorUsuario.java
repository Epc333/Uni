package src.main.persistence.classes;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

/**
 * Esta clase representa un gestor de usuario. 
 * Permite cargar y gestionar los usuarios y sus datos.
 * @author Andres Lucian Laptes Costan (andres.lucian.laptes@estudiantat.upc.edu)
 */
public class GestorUsuario {

    /**
     * Constructora que inicializa un gestor de usuario vacio.
     */
    public GestorUsuario() {
    }

    /**
     * Estructura un array de Strings en un Map<String, Object> con los datos de un usuario.
     * @param datosUsuario ArrayList<String> con los datos del usuario.
     * @return Map<String, Object> con los datos del usuario
     */
    private static Map<String, Object> estructurarArray(ArrayList<String> datosUsuario) {
        Map<String, Object> usuarioMap = new LinkedHashMap<>();
        List<String> supermercados = new ArrayList<>();
        boolean procesarSupermercados = false;

        for (int i = 0; i < datosUsuario.size(); i++) {
            String clave = datosUsuario.get(i);

            if (procesarSupermercados) {
                supermercados.add(clave);
            } else {
                switch (clave) {
                    case "Nombre":
                        usuarioMap.put("Nombre", datosUsuario.get(++i));
                        break;
                    case "Password":
                        usuarioMap.put("Password", datosUsuario.get(++i));
                        break;
                    case "Email":
                        usuarioMap.put("Email", datosUsuario.get(++i));
                        break;
                    case "Idioma":
                        usuarioMap.put("Idioma", datosUsuario.get(++i));
                        break;
                    case "Supermercados":
                        procesarSupermercados = true;
                        break;
                }
            }
        }

        usuarioMap.put("Supermercados", supermercados);

        return usuarioMap;
    }

    /**
     * Guarda un usuario en el archivo Usuarios.json.
     * @param usuario Datos del usuario a guardar.
     * @throws IOException
     */
    public void guardarUsuario(ArrayList<String> usuario) throws IOException {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();

        Path paths = Paths.get("FONTS", "src", "main", "persistence", "json", "Usuarios.json");
        String filePath = paths.toAbsolutePath().toString();

        List<Map<String, Object>> listaUsuarios;
        try (FileReader reader = new FileReader(filePath)) {
            Type listType = new TypeToken<List<Map<String, Object>>>() {}.getType();
            listaUsuarios = gson.fromJson(reader, listType);

            if (listaUsuarios == null) {
                listaUsuarios = new ArrayList<>();
            }
        } catch (IOException e) {
            listaUsuarios = new ArrayList<>();
        }

        Map<String, Object> nuevoUsuario = estructurarArray(usuario);

        String nombreNuevoUsuario = (String) nuevoUsuario.get("Nombre");
        boolean usuarioReemplazado = false;

        for (int i = 0; i < listaUsuarios.size(); i++) {
            Map<String, Object> usuarioExistente = listaUsuarios.get(i);
            String nombreExistente = (String) usuarioExistente.get("Nombre");

            if (nombreExistente != null && nombreExistente.equals(nombreNuevoUsuario)) {
                listaUsuarios.set(i, nuevoUsuario);
                usuarioReemplazado = true;
                break;
            }
        }

        if (!usuarioReemplazado) {
            listaUsuarios.add(nuevoUsuario);
        }

        try (FileWriter writer = new FileWriter(filePath)) {
            gson.toJson(listaUsuarios, writer);
        }
    }

    /**
     * Elimina un usuario del archivo Usuarios.json.
     * @param Usuario Nombre del usuario a eliminar.
     * @throws IOException
     */
    public static void eliminarUsuario(String Usuario) throws IOException {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();

        Path paths = Paths.get("FONTS", "src", "main", "persistence", "json", "Usuarios.json");
        String filePath = paths.toAbsolutePath().toString();

        List<Map<String, Object>> listaUsuarios;
        try (FileReader reader = new FileReader(filePath)) {
            Type listType = new TypeToken<List<Map<String, Object>>>() {}.getType();
            listaUsuarios = gson.fromJson(reader, listType);

            if (listaUsuarios == null) {
                throw new IOException("El archivo JSON está vacío o no contiene al usuario.");
            }
        }

        boolean usuarioEncontrado = false;
        for (int i = 0; i < listaUsuarios.size(); i++) {
            Map<String, Object> usuario = listaUsuarios.get(i);
            String nombre = (String) usuario.get("Nombre");

            if (nombre != null && nombre.equals(Usuario)) {
                listaUsuarios.remove(i);
                usuarioEncontrado = true;
                break;
            }
        }

        if (!usuarioEncontrado) {
            throw new IOException("Usuario con nombre '" + Usuario + "' no encontrado.");
        }

        try (FileWriter writer = new FileWriter(filePath)) {
            gson.toJson(listaUsuarios, writer);
        }
    }

    /**
     * Funcion que comprueba si un usuario existe en el archivo Usuarios.json.
     * @param user Nombre del usuario a comprobar.
     * @return True si el usuario existe, False en caso contrario.
     */
    public static boolean existeUsuario(String user) {
        boolean found = false;
        Gson gson = new Gson();

        Path paths = Paths.get("FONTS", "src", "main", "persistence", "json", "Usuarios.json");
        String filePath = paths.toAbsolutePath().toString();

        List<Map<String, Object>> listaUsuarios = null;
        try (FileReader reader = new FileReader(filePath)) {
            Type listType = new TypeToken<List<Map<String, Object>>>() {}.getType();
            listaUsuarios = gson.fromJson(reader, listType);

            if (listaUsuarios == null) {
                return false;
            }
        } catch (Exception e) {
            System.err.println("Error en el archivo JSON: " + e.getMessage());
        }

        for (Map<String, Object> usuario : listaUsuarios) {
            if (usuario.get("Nombre").equals(user)) found = true;
        }

        return found;
    }

    /**
     * Carga un usuario del archivo Usuarios.json.
     * @param nombreUsuario Nombre del usuario a cargar.
     * @return Lista con los datos del usuario.
     * @throws IOException
     */
    public static ArrayList<String> cargarUsuario(String nombreUsuario) throws IOException {
        Gson gson = new Gson();

        Path paths = Paths.get("FONTS", "src", "main", "persistence", "json", "Usuarios.json");
        String filePath = paths.toAbsolutePath().toString();

        List<Map<String, Object>> listaUsuarios;
        try (FileReader reader = new FileReader(filePath)) {
            Type listType = new TypeToken<List<Map<String, Object>>>() {}.getType();
            listaUsuarios = gson.fromJson(reader, listType);

            if (listaUsuarios == null) {
                throw new IOException("El archivo JSON está vacío o no contiene usuarios.");
            }
        }

        for (Map<String, Object> usuario : listaUsuarios) {
            String nombre = (String) usuario.get("Nombre");
            if (nombre != null && nombre.equals(nombreUsuario)) {
                ArrayList<String> datosUsuario = new ArrayList<>();

                datosUsuario.add("Nombre");
                datosUsuario.add((String) usuario.get("Nombre"));

                datosUsuario.add("Password");
                datosUsuario.add((String) usuario.get("Password"));

                datosUsuario.add("Email");
                datosUsuario.add((String) usuario.get("Email"));

                datosUsuario.add("Idioma");
                datosUsuario.add((String) usuario.get("Idioma"));

                datosUsuario.add("Supermercados");
                List<String> supermercados = (List<String>) usuario.get("Supermercados");
                if (supermercados != null) {
                    datosUsuario.addAll(supermercados);
                }

                return datosUsuario;
            }
        }

        throw new IOException("Usuario con nombre '" + nombreUsuario + "' no encontrado.");
    }
}
