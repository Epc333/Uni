package src.main.persistence.classes;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Esta clase representa un gestor de diccionarios. 
 * Permite cargar y gestionar los diccionarios y idiomas usados en el programa.
 * @author Andres Lucian Laptes Costan (andres.lucian.laptes@estudiantat.upc.edu)
 */
public class GestorDiccionario {

    /** Diccionario que se esta usando acutalmente */
    private Map<Integer,String> diccionarioActual;

    /**
     * Obtiene el diccionario actual que se esta usando y lo carga en el atributo diccionarioActual.
     * @param Idioma
     * @throws FileNotFoundException
     */
    private void leerDiccionario(String Idioma) throws FileNotFoundException {
        Gson gson = new Gson();

        Path paths = Paths.get("FONTS", "src", "main", "persistence", "json", "Diccionario.json");
        String filePath = paths.toAbsolutePath().toString();

        try (FileReader reader = new FileReader(filePath)) {
            JsonObject json = JsonParser.parseReader(reader).getAsJsonObject();

            if (!json.has(Idioma)) throw new IllegalArgumentException("The selected language didn't exist");

            JsonObject idomaJson = json.getAsJsonObject(Idioma);
            Map<String, String> aux = gson.fromJson(idomaJson, Map.class);
            for (Map.Entry<String, String> entry : aux.entrySet()) {
                diccionarioActual.put(Integer.parseInt(entry.getKey()), entry.getValue());
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Constructora que inicializa un diccionario vacio.
     */
    public GestorDiccionario() {
        diccionarioActual = new HashMap<>();
    }

    /**
     * Carga el diccionario seleccionado.
     * @param name El idioma del diccionario que se quiere cargar.
     * @return El diccionario cargado.
     * @throws FileNotFoundException
     */
    public Map<Integer,String> cargarDiccionario(String name) throws FileNotFoundException {
        leerDiccionario(name);
        return diccionarioActual;
    }
}
