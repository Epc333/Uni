package src.main.persistence.controllers;

import src.main.persistence.classes.GestorDiccionario;
import src.main.persistence.classes.GestorProducto;
import src.main.persistence.classes.GestorSupermercado;
import src.main.persistence.classes.GestorUsuario;


import java.io.FileNotFoundException;
import java.io.InvalidClassException;
import java.util.ArrayList;
import java.util.Map;

/**
 * Esta representa el CtrlPersistencia del programa.
 * Permite cargar y gestionar todos los datos del programa.
 * Sirve para implementar la persistencia de datos del programa.
 * @author Andres Lucian Laptes Costan (andres.lucian.laptes@estudiantat.upc.edu)
 */
public class CtrlPersistencia {

    /** Instancia de GestorUsuario  */
    private GestorUsuario gestorUsuario;

    /** Instancia de GestorSupermercado  */
    private GestorSupermercado gestorSupermercado;

    /** Instancia de GestorProducto  */
    private GestorProducto gestorProducto;

    /** Instancia de GestorDiccionario  */
    private GestorDiccionario gestorDiccionario;

    /**
     * Constructora que inicializa un CtrlPersistencia.
     */
    public CtrlPersistencia() {
        gestorUsuario = new GestorUsuario();
        gestorSupermercado = new GestorSupermercado();
        gestorProducto = new GestorProducto();
        gestorDiccionario = new GestorDiccionario();
    }

    /**
     * Comprueba si existe un usuario.
     * @param usuario Usuario a comprobar.  
     * @return Devuelve true si existe el usuario, false en caso contrario.
     */
    public boolean existsUsuario(String usuario) {
        try {
            return gestorUsuario.existeUsuario(usuario);
        } catch (Exception e) {
            throw new IllegalArgumentException(e.getMessage());
        }
    }

    /**
     * Comprueba si existe un producto en un supermercado.
     * @param producto Producto a comprobar.
     * @param usuario Usuario propietario del supermercado.
     * @param supermercado Supermercado en que deberia estar el producto.  
     * @return Devuelve true si existe el producto, false en caso contrario.
     */
    public boolean existProducto(String producto, String usuario, String supermercado) {
        try {

            Map<Integer, Map<String, Object>> datos = gestorProducto.cargarProducto(producto, usuario);
            for (Map<String, Object> dato : datos.values()) {
                String nameProd = (String) dato.get("Nombre");
                String nameUser = (String) dato.get("Usuario");
                String nameSuper = (String) dato.get("Supermercado");
                if (producto.equals(nameProd) && supermercado.equals(nameSuper) && usuario.equals(nameUser)) {return true;}
            }
            return false;

        } catch (Exception e) {
            throw new IllegalArgumentException(e.getMessage());
        }
    }

    /**
     * Guarda un usuario.
     * @param datos Datos del usuario a guardar.
     */
    public void guardarUsuario(ArrayList<String> datos) {
        try {
            gestorUsuario.guardarUsuario(datos);
        } catch (Exception e) {
            throw new IllegalArgumentException(e.getMessage());
        }
    }

    /**
     * Carga un usuario de los archivos .json.
     * @param nombre Nombre del usuario a cargar.
     * @return Lista con los datos del usuario.
     */
    public ArrayList<String> cargarUsuario(String nombre) {
        try {
            return gestorUsuario.cargarUsuario(nombre);
        } catch (Exception e) {
            throw new IllegalArgumentException(e.getMessage());
        }
    }

    /**
     * Elimina un usuario de los archivos .json.
     * @param nombre Nombre del usuario a eliminar.
     */
    public void eliminarUsuario(String nombre) {
        try {
            gestorUsuario.eliminarUsuario(nombre);
        } catch (Exception e) {
            throw new IllegalArgumentException(e.getMessage());
        }
    }

    /**
     * Guarda un supermercado en los archivos .json.
     * @param sup Datos del supermercado a guardar.
     */
    public void guardarSupermercado(Map<String, Object> sup) {
        try {
            gestorSupermercado.guardarSupermercado(sup);
        } catch (Exception e) {
            throw new IllegalArgumentException(e.getMessage());
        }
    }

    /**
     * Elimina un supermercado de los archivos .json.
     * @param nombre Nombre del supermercado a eliminar.
     * @param User Usuario propietario del supermercado.
     */
    public void eliminarSupermercado(String nombre,String User) {
        try {
            gestorSupermercado.eliminarSuper(nombre, User);
        } catch (Exception e) {
            throw new IllegalArgumentException(e.getMessage());
        }
    }

    /**
     * Carga un supermercado de los archivos .json.
     * @param nombre Nombre del supermercado a cargar.
     * @param usuario Usuario propietario del supermercado.
     * @return Mapa con los datos del supermercado.
     */
    public Map<String, Object> cargarSupermercado(String nombre, String usuario) {
        try {
            return gestorSupermercado.cargarSupermercado(nombre, usuario);
        } catch (Exception e) {
            throw new IllegalArgumentException(e.getMessage());
        }
    }

    /**
     * Guarda un producto en los archivos .json.
     * @param prod Datos del producto a guardar.
     */
    public void guardarProducto(Map<String, Object> prod) {
        try {
            gestorProducto.guardarProducto(prod);
        } catch (Exception e) {
            throw new IllegalArgumentException(e.getMessage());
        }
    }

    /**
     * Carga todos los productos de un supermercado de los archivos .json.
     * @param usuario Usuario propietario del supermercado.
     * @param supermercado Supermercado en que esta el producto.
     * @return Mapa con los datos del producto.
     */
    public Map<Integer, Map<String, Object>> cargarProducto(String usuario, String supermercado) {
        try {
            return gestorProducto.cargarProducto(usuario, supermercado);
        } catch (Exception e) {
            throw new IllegalArgumentException(e.getMessage());
        }
    }

    /**
     * DEvuelve los nombres de los productos de un supermercado.
     * @param supermercado Supermercado que se quiere conultar.
     * @param User Usuario propietario del supermercado.
     * @return Lista con los nombres de los productos.
     */
    public ArrayList<String> getNombresDeProductos(String supermercado, String User) {
        try {
            return gestorSupermercado.getNombresDeProductos(supermercado, User);
        } catch (Exception e) {
            throw new IllegalArgumentException(e.getMessage());
        }
    }

    /**
     * Elimina un producto de los archivos .json.
     * @param usuario Usuario propietario del supermercado.
     * @param supermercado Supermercado en que esta el producto.
     * @param producto Producto a eliminar.
     */
    public void eliminarProd(String usuario, String supermercado, String producto) {
        try {
            gestorProducto.eliminarProd(usuario, supermercado, producto);
        } catch (Exception e) {
            throw new IllegalArgumentException(e.getMessage());
        }
    }

    /**
     * Carga el diccionario seleccionado.
     * @param Idioma El idioma del diccionario que se quiere cargar.
     * @return El diccionario cargado.
     * @throws FileNotFoundException
     * @throws InvalidClassException
     */
    public Map<Integer, String> cargarDiccionario (String Idioma) throws FileNotFoundException, InvalidClassException {
        Map<Integer, String> aux = null;
        try {
            aux = gestorDiccionario.cargarDiccionario(Idioma);
        } catch (Exception e) {
            throw new InvalidClassException(e.getMessage());
        }
        return aux;
    }
}
