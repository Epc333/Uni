package src.main.presentation.views;

import src.main.presentation.controllers.CtrlPresentacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Esta vista permite modificar un porcentaje de similitud entre dos productos.
 * Contiene un único campo que muestra el porcentaje actual, el cual podremos modificar.
 * Debajo tendremos el botón para confirmar la modificación, y en la esquina superior derecha el de salida.
 * @author Vinyet Granda Planas (vinyet.granda@estudiantat.upc.edu)
 */

public class VistaModSimilitud {
    private JFrame frame;

    /**
     * Cosntructora de la vista
     */

    public VistaModSimilitud(String supermercado, String prod1, String prod2) {
        frame = new JFrame(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),41));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 200);

        JPanel panelPrincipal = new JPanel(new BorderLayout());

        JPanel panelSuperior = new JPanel(new BorderLayout());

        JButton botonExit = new JButton(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),1));
        panelSuperior.add(botonExit, BorderLayout.EAST);

        botonExit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new VistaProducto(supermercado, prod1);
            }
        });

        panelPrincipal.add(panelSuperior, BorderLayout.NORTH);

        JPanel panelContenido = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel simLabel = new JLabel(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),42));
        gbc.gridx = 0;
        gbc.gridy = 0;
        panelContenido.add(simLabel, gbc);

        JTextField SimText = new JTextField(15);
        gbc.gridx = 1;
        panelContenido.add(SimText, gbc);

        SimText.setText(String.valueOf(CtrlPresentacion.getSimilitud(supermercado, prod1, prod2)));

        JButton modificarButton = new JButton(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),17));
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        panelContenido.add(modificarButton, gbc);

        modificarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nuevaSim = SimText.getText();
                int error = 0;
                if(nuevaSim.trim().isEmpty()) JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 121), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                else {
                    try {
                        error = CtrlPresentacion.modSimilitud(supermercado, prod1, prod2, Integer.parseInt(nuevaSim));
                    } catch (NumberFormatException ex) {
                        error = 119;
                    }
                    if (error == 109)
                        JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 109), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                    else if (error == 115)
                        JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 115), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                    else if (error == 119)
                        JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 119), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                    else {
                        frame.dispose();
                        new VistaProducto(supermercado, prod1);
                    }
                }
            }
        });

        panelPrincipal.add(panelContenido, BorderLayout.CENTER);
        frame.add(panelPrincipal);
        frame.setVisible(true);
    }

}
