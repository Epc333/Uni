package src.main.presentation.views;


import src.main.presentation.controllers.CtrlPresentacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 * Esta vista permite añadir una similitud entre el producto al cual
 * la estamos añadiendo y otro de su mismo supermercado.
 * Tenemos un menú de opciones de productos del supermercado con el que crear una similitud y
 * debajo un campo para indicar el porcentaje de similitud que tendrán los productos.
 * Debajo tendremos el botón de creación y en la esquina superior derecha.
 * @author Vinyet Granda Planas (vinyet.granda@estudiantat.upc.edu)
 */


public class VistaAddSimilitud extends JFrame {
    private JFrame frame;

    /**
     * Cosntructora de la vista
     */
    public VistaAddSimilitud(String supermercado, String prod1) {
        frame = new JFrame(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),6));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 250);

        JPanel panelSuperior = new JPanel(new BorderLayout());

        JButton botonExit = new JButton(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),1));
        panelSuperior.add(botonExit, BorderLayout.EAST);

        botonExit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new VistaProducto(supermercado, prod1);
            }
        });

        JPanel panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.add(panelSuperior, BorderLayout.NORTH);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JPanel panelCentro = new JPanel(new GridBagLayout());

        JLabel productoLabel = new JLabel(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),3));
        gbc.gridx = 0;
        gbc.gridy = 0;
        panelCentro.add(productoLabel, gbc);

        ArrayList<String> productos = CtrlPresentacion.getProductosSim(supermercado, prod1);
        JComboBox<String> comboBoxProductos = new JComboBox<>(productos.toArray(new String[0]));
        gbc.gridx = 1;
        panelCentro.add(comboBoxProductos, gbc);

        JLabel porcentajeLabel = new JLabel(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),7));
        gbc.gridx = 0;
        gbc.gridy = 1;
        panelCentro.add(porcentajeLabel, gbc);

        JTextField porcentajeText = new JTextField(15);
        gbc.gridx = 1;
        panelCentro.add(porcentajeText, gbc);

        JButton añadirButton = new JButton(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),8));
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;  // El botón ocupa dos columnas
        panelCentro.add(añadirButton, gbc);

        añadirButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String prod2 = (String) comboBoxProductos.getSelectedItem();
                String porcentaje = porcentajeText.getText();
                int error = 0;
                try {
                    error = CtrlPresentacion.crearSimilitud(supermercado, prod1, prod2, Integer.valueOf(porcentaje));
                }
                catch (NumberFormatException ex) {
                    error = 119;
                }

                if(error == 111) JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 111), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                else if(error == 115) JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 115), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                else if (error == 119) JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 119), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                else {
                    frame.dispose();
                    new VistaProducto(supermercado, prod1);
                }

            }
        });

        panelPrincipal.add(panelCentro, BorderLayout.CENTER);
        frame.add(panelPrincipal);
        frame.setVisible(true);
    }

}
