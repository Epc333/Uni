package src.main.presentation.views;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import src.main.presentation.controllers.CtrlPresentacion;

/**
 * 	Esta vista es la primera pantalla que aparece al iniciar nuestro programa.
 *  Esta muestra una página inicial con un título central, donde los usuarios podrán acceder al sistema.
 *  Los usuarios ingresan sus datos en los campos indicados. Debajo, tenemos dos botones:
 *  uno para entrar en el sistema y otro para acceder a la vista de registro, para los usuarios que todavía no tengan cuenta.
 * @author Vinyet Granda Planas (vinyet.granda@estudiantat.upc.edu)
 */

public class VistaLogin extends JFrame {
    private JFrame frame;

    /**
     * Cosntructora de la vista
     */
    public VistaLogin() {
        String idioma = "Castellano";
        JPanel panel = new JPanel(new GridBagLayout());
        frame = new JFrame(CtrlPresentacion.getFrase(idioma,31) + " PROP");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 400);
        frame.add(panel);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;

        JLabel titulo = new JLabel(CtrlPresentacion.getFrase(idioma,31));
        titulo.setFont(titulo.getFont().deriveFont(20.0f));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(titulo, gbc);

        JLabel usuarioLabel = new JLabel(CtrlPresentacion.getFrase(idioma,10));
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(usuarioLabel, gbc);

        JTextField usuarioText = new JTextField(15);
        gbc.gridx = 1;
        panel.add(usuarioText, gbc);

        JLabel passwordLabel = new JLabel(CtrlPresentacion.getFrase(idioma,12));
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(passwordLabel, gbc);

        JPasswordField passwordText = new JPasswordField(15);
        gbc.gridx = 1;
        panel.add(passwordText, gbc);

        JButton loginButton = new JButton(CtrlPresentacion.getFrase(idioma,32));
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        panel.add(loginButton, gbc);

        JButton registerButton = new JButton(CtrlPresentacion.getFrase(idioma,33));
        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(registerButton, gbc);

        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new VistaRegistro();
            }
        });

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usuarioText.getText();
                char[] password = passwordText.getPassword();
                int error = CtrlPresentacion.LogIn(username, new String(password));

                if(error == 104) JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(idioma, 104), "Error", JOptionPane.ERROR_MESSAGE);
                else if (error == 112) JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(idioma, 112), "Error", JOptionPane.ERROR_MESSAGE);
                else if(error == 114) JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(idioma, 114), "Error", JOptionPane.ERROR_MESSAGE);
                else {
                    frame.dispose();
                    new VistaMenuSupermercado();
                }
            }
        });

        frame.setVisible(true);
    }



    public static void main(String[] args) {
        new VistaLogin();
    }

}