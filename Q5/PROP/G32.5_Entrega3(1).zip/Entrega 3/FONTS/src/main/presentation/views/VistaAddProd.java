package src.main.presentation.views;


import src.main.presentation.controllers.CtrlPresentacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Esta vista permite añadir un producto a un de los supermercados del usuario,
 * tendremos dos campos a rellenar, el primero con el nombre y el segundo con el precio.
 * Debajo de estos tenemos el botón para crear el producto y en la esquina superior derecha el botón de salida
 *  @author Vinyet Granda Planas (vinyet.granda@estudiantat.upc.edu)
 */

public class         VistaAddProd extends JFrame {
    private JFrame frame;

    /**
     * Cosntructora de la vista
     */
    public VistaAddProd(String supermercado) {

        frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        JButton botonExit = new JButton(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),1));
        JPanel panelSuperior = new JPanel(new BorderLayout()); //Para los botones superiores

        panelSuperior.add(botonExit, BorderLayout.EAST);

        botonExit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new VistaEstanterias(supermercado);
            }
        });

        JPanel panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.add(panelSuperior, BorderLayout.NORTH);

        JPanel panelCentro = new JPanel(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel tituloLabel = new JLabel(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),2));
        tituloLabel.setFont(new Font("Arial", Font.BOLD, 24));
        tituloLabel.setHorizontalAlignment(JLabel.CENTER);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;  // El título ocupa dos columnas
        panelCentro.add(tituloLabel, gbc); //Titulo

        JLabel nombreLabel = new JLabel(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),3));
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        panelCentro.add(nombreLabel, gbc); //nombre producto

        JTextField nombreTextField = new JTextField(15);
        gbc.gridx = 1;
        gbc.gridy = 1;
        panelCentro.add(nombreTextField, gbc); //Field nombre prod

        JLabel precioLabel = new JLabel(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),4));
        gbc.gridx = 0;
        gbc.gridy = 2;
        panelCentro.add(precioLabel, gbc); //Precio

        JTextField precioTextField = new JTextField(10);
        gbc.gridx = 1;
        gbc.gridy = 2;
        panelCentro.add(precioTextField, gbc); //Field precio

        JButton crearButton = new JButton(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),5));
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        panelCentro.add(crearButton, gbc); //boton crear

        crearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombreProducto = nombreTextField.getText();
                String precioProducto = precioTextField.getText();
                int error = 0;
                if(nombreProducto.trim().isEmpty() || precioProducto.isEmpty()) JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 121), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                else {
                    try {
                        error = CtrlPresentacion.crearProd(supermercado, nombreProducto, Double.parseDouble(precioProducto));
                    } catch (NumberFormatException ex) {
                        error = 118;
                    }
                    if (error == 106)
                        JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 106), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                    else if (error == 116)
                        JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 116), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                    else if (error == 118)
                        JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 118), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                    else {
                        frame.dispose();
                        new VistaEstanterias(supermercado);
                    }
                }
            }
        });
        panelPrincipal.add(panelCentro, BorderLayout.CENTER);
        frame.add(panelPrincipal);
        frame.setVisible(true);
    }
}

