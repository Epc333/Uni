package src.main.presentation.views;

import src.main.presentation.controllers.CtrlPresentacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

/**
 * Esta vista muestra los atributos del producto, con dos títulos uno para el nombre y otro para el precio.
 * Además tendremos un desplegable para ver todas las similitudes que tiene ese producto con otros de su
 * mismo supermercado. Debajo tenemos un botón de gestión de similitud que nos permitirá ver el porcentaje
 * de similitud, modificarlo o eliminar la similitud.
 * Además en la esquina superior derecha tendremos un botón que nos permitirá acceder a diferentes vistas
 * respecto al producto.
 * @author Vinyet Granda Planas (vinyet.granda@estudiantat.upc.edu)
 */

public class VistaProducto {
    private JFrame frame;

    /**
     * Cosntructora de la vista
     */

    public VistaProducto(String supermercado, String nombreProducto) {
        frame = new JFrame(nombreProducto);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 400);

        JPanel panelPrincipal = new JPanel(new BorderLayout());

        JPanel panelSuperior = new JPanel(new BorderLayout());
        JButton botonMenu = new JButton("☰");
        panelSuperior.add(botonMenu, BorderLayout.EAST);

        JPopupMenu popupMenu = new JPopupMenu();
        JMenuItem modProd = new JMenuItem(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),40));
        JMenuItem addProd = new JMenuItem(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),6));
        JMenuItem delProd = new JMenuItem(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),47));
        JMenuItem guardar = new JMenuItem(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),37));
        JMenuItem exit = new JMenuItem(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),1));

        modProd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new VistaModProducto(supermercado, nombreProducto);
            }
        });

        addProd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new VistaAddSimilitud(supermercado, nombreProducto);
            }
        });

        delProd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                int error = CtrlPresentacion.eliminarProd(supermercado, nombreProducto);
                if(error == 107) JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 107), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                else {
                    frame.dispose();
                    new VistaEstanterias(supermercado);
                }
            }
        });

        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new VistaEstanterias(supermercado);
            }
        });

        guardar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CtrlPresentacion.guardar();
            }
        });

        popupMenu.add(modProd);
        popupMenu.add(addProd);
        popupMenu.add(delProd);
        popupMenu.add(guardar);
        popupMenu.add(exit);

        botonMenu.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                popupMenu.show(botonMenu, e.getX(), e.getY());
            }
        });

        panelPrincipal.add(panelSuperior, BorderLayout.NORTH);

        JPanel panelContenido = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel tituloLabel = new JLabel(nombreProducto, SwingConstants.CENTER);
        tituloLabel.setFont(tituloLabel.getFont().deriveFont(24.0f));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panelContenido.add(tituloLabel, gbc);

        JLabel precioLabel = new JLabel(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),4));
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        panelContenido.add(precioLabel, gbc);

        JLabel precioValueLabel = new JLabel(String.format("%.2f €", CtrlPresentacion.getPrecio(supermercado, nombreProducto)));  // Mostrar precio con dos decimales
        gbc.gridx = 1;
        panelContenido.add(precioValueLabel, gbc);

        JLabel similitudesLabel = new JLabel(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),46));
        gbc.gridx = 0;
        gbc.gridy = 2;
        panelContenido.add(similitudesLabel, gbc);
        ArrayList<String> productosSimilares = CtrlPresentacion.getSimilitudes(supermercado, nombreProducto);
        JComboBox<String> comboBoxSimilitudes = new JComboBox<>(productosSimilares.toArray(new String[0]));
        gbc.gridx = 1;
        panelContenido.add(comboBoxSimilitudes, gbc);

        JButton gestionSimilitudButton = new JButton(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),45));
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        panelContenido.add(gestionSimilitudButton, gbc);

        panelPrincipal.add(panelContenido, BorderLayout.CENTER);
        JPopupMenu popupMenu2 = new JPopupMenu();
        JMenuItem modSim = new JMenuItem(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),41));
        JMenuItem delSim = new JMenuItem(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),44));

        modSim.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombreProducto2 = (String) comboBoxSimilitudes.getSelectedItem();
                frame.dispose();
                new VistaModSimilitud(supermercado, nombreProducto, nombreProducto2);
            }
        });

        delSim.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombreProducto2 = (String) comboBoxSimilitudes.getSelectedItem();
                CtrlPresentacion.eliminarSimilitud(supermercado, nombreProducto, nombreProducto2);
                frame.dispose();
                new VistaProducto(supermercado, nombreProducto);
            }
        });

        popupMenu2.add(modSim);
        popupMenu2.add(delSim);

        gestionSimilitudButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                popupMenu2.show(gestionSimilitudButton, e.getX(), e.getY());
            }
        });

        frame.add(panelPrincipal);
        frame.setVisible(true);
    }
}
