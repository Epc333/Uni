package src.main.presentation.views;

import src.main.presentation.controllers.CtrlPresentacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Arrays;

/**
 * Esta vista permite modificar cualquiera de los datos del usuario.
 * Los datos ya están precargados con la información actual del usuario y pueden ser editados.
 * Una vez cambiados los datos, el usuario puede confirmar con el botón de modificar,
 * que está justo debajo o salir con el de la esquina superior derecha sin modificar nada.
 * Es básicamente la misma ventana que el registro pero con alguna pequeña modificación.
 * @author Vinyet Granda Planas (vinyet.granda@estudiantat.upc.edu)
 */

public class VistaConfiguracion extends JFrame {
    private JFrame frame;

    /**
     * Cosntructora de la vista
     */
    public VistaConfiguracion() {
        frame = new JFrame(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),9));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 400);

        JPanel panelSuperior = new JPanel(new BorderLayout());

        JButton botonMenu = new JButton("☰");
        panelSuperior.add(botonMenu, BorderLayout.EAST);

        JPopupMenu popupMenu = new JPopupMenu();
        JMenuItem delUsr = new JMenuItem(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),53));
        JMenuItem exit = new JMenuItem(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),1));



        delUsr.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CtrlPresentacion.eliminarUsuario();
                frame.dispose();
                new VistaLogin();
            }
        });

        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new VistaMenuSupermercado();
            }
        });

        popupMenu.add(delUsr);
        popupMenu.add(exit);

        botonMenu.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                popupMenu.show(botonMenu, e.getX(), e.getY());
            }
        });

        JPanel panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.add(panelSuperior, BorderLayout.NORTH);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.CENTER;

        JPanel panelCentro = new JPanel(new GridBagLayout());

        JLabel titulo = new JLabel(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),9));
        titulo.setFont(titulo.getFont().deriveFont(24.0f));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panelCentro.add(titulo, gbc);

        JLabel usuarioLabel = new JLabel(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),10));
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        panelCentro.add(usuarioLabel, gbc);

        JTextField usuarioText = new JTextField(15);
        gbc.gridx = 1;
        panelCentro.add(usuarioText, gbc);

        JLabel mailLabel = new JLabel(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),11));
        gbc.gridx = 0;
        gbc.gridy = 2;
        panelCentro.add(mailLabel, gbc);

        JTextField mailText = new JTextField(15);
        gbc.gridx = 1;
        panelCentro.add(mailText, gbc);

        JLabel passwordLabel = new JLabel(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),12));
        gbc.gridx = 0;
        gbc.gridy = 3;
        panelCentro.add(passwordLabel, gbc);

        JPasswordField passwordText = new JPasswordField(15);
        gbc.gridx = 1;
        panelCentro.add(passwordText, gbc);

        JLabel confirmPasswordLabel = new JLabel(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),13));
        gbc.gridx = 0;
        gbc.gridy = 4;
        panelCentro.add(confirmPasswordLabel, gbc);

        JPasswordField confirmPasswordText = new JPasswordField(15);
        gbc.gridx = 1;
        panelCentro.add(confirmPasswordText, gbc);

        usuarioText.setText(CtrlPresentacion.getName());
        mailText.setText(CtrlPresentacion.getEmail());

        passwordText.setEchoChar('\u2022');
        confirmPasswordText.setEchoChar('\u2022');

        JButton showPasswordButton = new JButton(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),14));
        gbc.gridx = 2;
        gbc.gridy = 3;
        gbc.gridheight = 2;
        panelCentro.add(showPasswordButton, gbc);

        showPasswordButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (passwordText.getEchoChar() == '\u2022') {
                    passwordText.setEchoChar((char) 0);
                    confirmPasswordText.setEchoChar((char) 0);
                    showPasswordButton.setText(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),15));
                } else {
                    passwordText.setEchoChar('\u2022');
                    confirmPasswordText.setEchoChar('\u2022');
                    showPasswordButton.setText(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),14));
                }
            }
        });

        JLabel idiomaLabel = new JLabel(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),16));
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridheight = 1;
        panelCentro.add(idiomaLabel, gbc);

        String[] idiomas = { "Castellano", "Catalan", "Ingles", "Rumano" };
        JComboBox<String> comboBoxIdiomas = new JComboBox<>(idiomas);
        comboBoxIdiomas.setSelectedItem(CtrlPresentacion.getIdioma());
        gbc.gridx = 1;
        panelCentro.add(comboBoxIdiomas, gbc);

        JButton ModificarButton = new JButton(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),17));
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        panelCentro.add(ModificarButton, gbc);

        ModificarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usuarioText.getText();
                String mail = mailText.getText();
                char[] password = passwordText.getPassword();
                char[] confirmPassword = confirmPasswordText.getPassword();
                String idioma = (String) comboBoxIdiomas.getSelectedItem();

                if (new String(password).equals(new String(confirmPassword))) {
                    String Password = new String(password);
                    if(username.trim().isEmpty()) JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 121), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                    else if(mail.trim().isEmpty()) JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 121), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                    else if(Password.equals("[]") && Password.length() <= 12) JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 104), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                    else {
                        if(Password.trim().isEmpty()) Password = null;
                        if(username.equals(CtrlPresentacion.getName())) username = null;
                        if(idioma.equals(CtrlPresentacion.getIdioma())) idioma = null;
                        if(mail.equals(CtrlPresentacion.getEmail())) mail = null;
                        if(Password == null && username == null && idioma == null && mail == null) JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 110), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                        else{
                            int error = CtrlPresentacion.modificarUsuario(username, mail, Password, idioma);
                            if (error == 110)
                                JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 110), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                            else if (error == 101)
                                JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 101), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                            else if (error == 104)
                                JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 104), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                            else {
                                frame.dispose();
                                new VistaMenuSupermercado();
                            }
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "Las contraseñas no coinciden.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        panelPrincipal.add(panelCentro, BorderLayout.CENTER);
        frame.add(panelPrincipal);
        frame.setVisible(true);
    }
}
