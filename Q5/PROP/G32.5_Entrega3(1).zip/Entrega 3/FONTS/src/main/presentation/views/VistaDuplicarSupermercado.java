package src.main.presentation.views;

import src.main.presentation.controllers.CtrlPresentacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Esta vista permite duplicar un supermercado ya existente.
 * Tenemos dos campos que rellenar, el nombre que le asignaremos al nuevo supermercado
 * y un desplegable para seleccionar entre todos los supermercados del usuario cual de ellos desea duplicar.
 * Debajo de estos tendremos el botón de duplicar y en la esquina superior derecha el botón de salir.
 * @author Vinyet Granda Planas (vinyet.granda@estudiantat.upc.edu)
 */

public class VistaDuplicarSupermercado {
    private JFrame frame;

    /**
     * Cosntructora de la vista
     */
    public VistaDuplicarSupermercado() {
        frame = new JFrame(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),23));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        JPanel panelSuperior = new JPanel(new BorderLayout());

        JButton botonMenu = new JButton("☰");
        panelSuperior.add(botonMenu, BorderLayout.EAST);

        JButton exit = new JButton(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),1));
        panelSuperior.add(exit, BorderLayout.EAST);

        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new VistaMenuSupermercado();
            }
        });

        JPanel panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.add(panelSuperior, BorderLayout.NORTH);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.CENTER;

        JPanel panelCentro = new JPanel(new GridBagLayout());

        JLabel titulo = new JLabel(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),23));
        titulo.setFont(titulo.getFont().deriveFont(24.0f));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panelCentro.add(titulo, gbc);

        JLabel nombreSupermercadoLabel = new JLabel(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),21));
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        panelCentro.add(nombreSupermercadoLabel, gbc);

        JTextField nombreSupermercadoText = new JTextField(15);
        gbc.gridx = 1;
        panelCentro.add(nombreSupermercadoText, gbc);

        JLabel supermercadoLabel = new JLabel(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),24));
        gbc.gridx = 0;
        gbc.gridy = 2;
        panelCentro.add(supermercadoLabel, gbc);

        String[] supermercados = CtrlPresentacion.getNombresSupers().toArray(new String[0]);
        JComboBox<String> comboBoxSupermercados = new JComboBox<>(supermercados);
        gbc.gridx = 1;
        panelCentro.add(comboBoxSupermercados, gbc);

        JButton duplicarButton = new JButton(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),25));
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        panelCentro.add(duplicarButton, gbc);

        duplicarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombrenuevo = nombreSupermercadoText.getText();
                String nombreDuplica = (String) comboBoxSupermercados.getSelectedItem();
                if(nombrenuevo.trim().isEmpty()) JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 121), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                else {
                    int error = CtrlPresentacion.duplicaSupermercado(nombreDuplica, nombrenuevo);
                    if (error == 105)
                        JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 105), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                    else {
                        frame.dispose();
                        new VistaMenuSupermercado();
                    }
                }
            }
        });

        panelPrincipal.add(panelCentro, BorderLayout.CENTER);
        frame.add(panelPrincipal);
        frame.setVisible(true);
    }
}