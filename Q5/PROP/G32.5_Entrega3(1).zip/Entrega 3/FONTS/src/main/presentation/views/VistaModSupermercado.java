package src.main.presentation.views;


import src.main.presentation.controllers.CtrlPresentacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Esta vista permite modificar los atributos de nuestro supermercado. En este tenemos el campo del nombre del
 * supermercado en el que ya estará rellenado el nombre actual del supermercado que queremos modificar.
 * Y un desplegable con los posibles algoritmos por si queremos cambiar la distribución del supermercado.
 * Debajo tenemos un botón para confirmar las modificaciones y en la esquina superior derecha el botón de salida.
 * @author Vinyet Granda Planas (vinyet.granda@estudiantat.upc.edu)
 */

public class VistaModSupermercado {
    private JFrame frame;

    /**
     * Cosntructora de la vista
     */

    public VistaModSupermercado(String nombreSupermercado) {

        frame = new JFrame(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),27));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        JPanel panelPrincipal = new JPanel(new BorderLayout());
        JPanel panelSuperior = new JPanel(new BorderLayout());

        JButton exit = new JButton(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),1));
        panelSuperior.add(exit, BorderLayout.EAST);  // Lo colocamos en la esquina superior derecha

        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new VistaEstanterias(nombreSupermercado);
            }
        });

        panelPrincipal.add(panelSuperior, BorderLayout.NORTH);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.CENTER;

        JPanel panelCentro = new JPanel(new GridBagLayout());

        JLabel titulo = new JLabel(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),27));
        titulo.setFont(titulo.getFont().deriveFont(24.0f));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panelCentro.add(titulo, gbc);

        JLabel nombreSupermercadoLabel = new JLabel(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),21));
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        panelCentro.add(nombreSupermercadoLabel, gbc);

        JTextField nombreSupermercadoText = new JTextField(15);
        gbc.gridx = 1;
        panelCentro.add(nombreSupermercadoText, gbc);

        JLabel numEstanteriasLabel = new JLabel(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),22));
        gbc.gridx = 0;
        gbc.gridy = 2;
        panelCentro.add(numEstanteriasLabel, gbc);

        JLabel numEstanteriasLabel2 = new JLabel(String.valueOf(CtrlPresentacion.getNEstanterias(nombreSupermercado)));
        gbc.gridx = 1;
        panelCentro.add(numEstanteriasLabel2, gbc);

        JLabel algoritmoLabel = new JLabel(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),43));
        gbc.gridx = 0;
        gbc.gridy = 3;
        panelCentro.add(algoritmoLabel, gbc);

        String[] algoritmos = { " ", "Back Tracking", "Hill Climbing", "2-Aproximación" };
        JComboBox<String> comboBoxAlgoritmos = new JComboBox<>(algoritmos);
        String algoritmo = CtrlPresentacion.getAlgoritmo(nombreSupermercado);
        if(algoritmo != null) comboBoxAlgoritmos.setSelectedItem(algoritmo);
        gbc.gridx = 1;
        panelCentro.add(comboBoxAlgoritmos, gbc);

        JButton modificarButton = new JButton(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),17));
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        panelCentro.add(modificarButton, gbc);

        nombreSupermercadoText.setText(nombreSupermercado);

        modificarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String newNombreSupermercado = nombreSupermercadoText.getText();
                String algoritmoSeleccionado = (String) comboBoxAlgoritmos.getSelectedItem();
                if(newNombreSupermercado.trim().isEmpty()) JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 121), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                else {
                    int error = CtrlPresentacion.modificarSuper(nombreSupermercado, newNombreSupermercado, algoritmoSeleccionado);
                    if (error == 105)
                        JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 105), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                    else if (error == 117)
                        JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 117), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                    else {
                        frame.dispose();
                        new VistaEstanterias(newNombreSupermercado);
                    }
                }
            }
        });

        panelPrincipal.add(panelCentro, BorderLayout.CENTER);
        frame.add(panelPrincipal);
        frame.setVisible(true);
    }

}
