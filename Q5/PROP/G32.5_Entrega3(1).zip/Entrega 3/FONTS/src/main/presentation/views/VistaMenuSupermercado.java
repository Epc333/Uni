package src.main.presentation.views;

import src.main.presentation.controllers.CtrlPresentacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

/**
 * Esta vista presenta todos los supermercados creados por el usuario hasta ahora.
 * Nos los muestra a modo de botones y en filas de dos, incluye una barra
 * de desplazamiento vertical y otra horizontal que nos permite explorar todos los supermercados.
 * Además tenemos un botón de configuración en la esquina superior izquierda que nos permitirá modificar nuestros datos.
 * También tenemos un botón en la esquina superior derecha que nos desplegará un menú de opciones
 * de gestión para el menú de supermercados.
 * @author Vinyet Granda Planas (vinyet.granda@estudiantat.upc.edu)
 */

public class VistaMenuSupermercado extends JFrame {
    private JFrame frame;

    /**
     * Cosntructora de la vista
     */

    public VistaMenuSupermercado() {
        frame = new JFrame(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 34));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 500);

        JPanel panelPrincipal = new JPanel(new BorderLayout());
        JPanel panelBotonesArriba = new JPanel(new BorderLayout());

        JButton botonMenu = new JButton("☰");
        panelBotonesArriba.add(botonMenu, BorderLayout.EAST);

        JPopupMenu popupMenu = new JPopupMenu();
        JMenuItem crearSuper = new JMenuItem(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 20));
        JMenuItem dupSuper = new JMenuItem(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),35));
        JMenuItem borrarTSuper = new JMenuItem(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),36));
        JMenuItem guardar = new JMenuItem(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),37));
        JMenuItem logOut = new JMenuItem(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),38));

        crearSuper.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new VistaCrearSupermercado();
            }
        });

        dupSuper.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new VistaDuplicarSupermercado();
            }
        });

        borrarTSuper.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CtrlPresentacion.borrarSupermercados();
                frame.dispose();
                new VistaMenuSupermercado();
            }
        });

        guardar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CtrlPresentacion.guardar();
            }
        });

        logOut.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CtrlPresentacion.LogOut();
                frame.dispose();
                new VistaLogin();
            }
        });

        popupMenu.add(crearSuper);
        popupMenu.add(dupSuper);
        popupMenu.add(borrarTSuper);
        popupMenu.add(guardar);
        popupMenu.add(logOut);

        botonMenu.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                popupMenu.show(botonMenu, e.getX(), e.getY());
            }
        });

        JButton botonConfiguracion = new JButton(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),9));
        panelBotonesArriba.add(botonConfiguracion, BorderLayout.WEST);

        botonConfiguracion.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                frame.dispose();
                new VistaConfiguracion();
            }
        });

        panelPrincipal.add(panelBotonesArriba, BorderLayout.NORTH);

        JPanel panelBotonesCentro = new JPanel();
        panelBotonesCentro.setLayout(new GridLayout(0, 2, 10, 10));

        int numBotones = CtrlPresentacion.getNumSupermercados();
        ArrayList<String> nombreSupers = CtrlPresentacion.getNombresSupers();
        for (int i = 1; i <= numBotones; i++) {
            JButton boton = new JButton(nombreSupers.get(i - 1));
            boton.setPreferredSize(new Dimension(200, 200));

            boton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String supermercado = boton.getText();
                    System.out.println("Supermercado: " + supermercado);
                    frame.dispose();
                    new VistaEstanterias(supermercado);
                }
            });

            panelBotonesCentro.add(boton);
        }

        JScrollPane scrollPane = new JScrollPane(panelBotonesCentro);
        scrollPane.setPreferredSize(new Dimension(450, 400));
        panelPrincipal.add(scrollPane, BorderLayout.CENTER);
        frame.add(panelPrincipal);
        frame.setVisible(true);
    }

}
