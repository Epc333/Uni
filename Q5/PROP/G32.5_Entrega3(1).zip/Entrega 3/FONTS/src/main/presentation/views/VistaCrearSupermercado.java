package src.main.presentation.views;

import src.main.presentation.controllers.CtrlPresentacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * Esta vista nos permite crear un nuevo supermercado.
 * Tenemos dos campos para escribir los datos obligatorios de un supermercado, el nombre y el número de estanterías.
 * En la parte inferior tenemos un botón para crear el supermercado.
 * Y como en todas las vistas también tenemos el botón de salir en la esquina superior derecha.
 * @author Vinyet Granda Planas (vinyet.granda@estudiantat.upc.edu)
 */

public class VistaCrearSupermercado extends JFrame {
    private JFrame frame;

    /**
     * Cosntructora de la vista
     */
    public VistaCrearSupermercado() {
        frame = new JFrame(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),20));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        JPanel panelSuperior = new JPanel(new BorderLayout());

        JButton exit = new JButton(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),1));
        panelSuperior.add(exit, BorderLayout.EAST);  // Lo colocamos en la esquina superior izquierda

        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new VistaMenuSupermercado();
            }
        });

        JPanel panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.add(panelSuperior, BorderLayout.NORTH);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.CENTER;

        JPanel panelCentro = new JPanel(new GridBagLayout());

        JLabel titulo = new JLabel(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),20));
        titulo.setFont(titulo.getFont().deriveFont(24.0f));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panelCentro.add(titulo, gbc);

        JLabel nombreLabel = new JLabel(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),21));
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        panelCentro.add(nombreLabel, gbc);

        JTextField nombreText = new JTextField(15);
        gbc.gridx = 1;
        panelCentro.add(nombreText, gbc);

        JLabel estanteriasLabel = new JLabel(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),22));
        gbc.gridx = 0;
        gbc.gridy = 2;
        panelCentro.add(estanteriasLabel, gbc);

        JTextField estanteriasText = new JTextField(15);
        gbc.gridx = 1;
        panelCentro.add(estanteriasText, gbc);

        JButton crearButton = new JButton(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),5));
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        panelCentro.add(crearButton, gbc);

        crearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre = nombreText.getText();
                String estanterias = estanteriasText.getText();
                int error = 0;
                if(nombre.trim().isEmpty()) JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 121), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                else if (estanterias.trim().isEmpty()) JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 121), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                else {
                    try {
                        error = CtrlPresentacion.generarSupermercado(nombre, Integer.parseInt(estanterias));
                    } catch (NumberFormatException ex) {
                        error = 120;
                    }
                    if (error == 105)
                        JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 105), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                    else if (error == 120)
                        JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 120), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                    else {
                        frame.dispose();
                        new VistaMenuSupermercado();
                    }
                }
            }
        });

        panelPrincipal.add(panelCentro, BorderLayout.CENTER);
        frame.add(panelPrincipal);
        frame.setVisible(true);
    }

}

