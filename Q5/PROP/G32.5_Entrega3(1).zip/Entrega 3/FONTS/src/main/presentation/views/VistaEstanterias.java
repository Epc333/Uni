package src.main.presentation.views;

import src.main.presentation.controllers.CtrlPresentacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

/**
 * Esta vista nos muestra el supermercado que previamente hemos seleccionado para visualizar.
 * Todos los productos aparecen como botones dentro de estanterías, que nos permitirán acceder a la información del producto.
 * Incluyendo dos barras de desplazamiento una horizontal y otra vertical para explorar todos los productos del supermercado.
 * Además tenemos en la esquina superior derecha un botón de opciones posibles a realizar en el supermercado en el que nos encontramos.
 * @author Vinyet Granda Planas (vinyet.granda@estudiantat.upc.edu)
 */

public class VistaEstanterias {
    private JFrame frame;

    /**
     * Cosntructora de la vista
     */
    public VistaEstanterias(String nombreSupermercado) {
        frame = new JFrame(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),26));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 500);

        JPanel panelPrincipal = new JPanel(new BorderLayout());

        JPanel panelBotonesArriba = new JPanel(new BorderLayout());

        JButton botonMenu = new JButton("☰");
        panelBotonesArriba.add(botonMenu, BorderLayout.EAST);

        JPopupMenu popupMenu = new JPopupMenu();
        JMenuItem modSuper = new JMenuItem(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),27));
        JMenuItem inter = new JMenuItem(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),49));
        JMenuItem consStock = new JMenuItem(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),28));
        JMenuItem addProd = new JMenuItem(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),29));
        JMenuItem delSuper = new JMenuItem(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),30));
        JMenuItem guardar = new JMenuItem(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),37));
        JMenuItem exit = new JMenuItem(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),1));

        modSuper.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new VistaModSupermercado(nombreSupermercado);
            }
        });

        consStock.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new VistaConsStock(nombreSupermercado);
            }
        });

        addProd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new VistaAddProd(nombreSupermercado);
            }
        });

        delSuper.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int error = CtrlPresentacion.borrarSupermercado(nombreSupermercado);
                if(error == 108) JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 108), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                frame.dispose();
                new VistaMenuSupermercado();
            }
        });

        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new VistaMenuSupermercado();
            }
        });

        guardar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CtrlPresentacion.guardar();
            }
        });

        inter.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new VistaIntercambiarProductos(nombreSupermercado);
            }
        });

        popupMenu.add(modSuper);
        popupMenu.add(inter);
        popupMenu.add(consStock);
        popupMenu.add(addProd);
        popupMenu.add(delSuper);
        popupMenu.add(guardar);
        popupMenu.add(exit);

        botonMenu.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                popupMenu.show(botonMenu, e.getX(), e.getY());
            }
        });

        panelPrincipal.add(panelBotonesArriba, BorderLayout.NORTH);

        double estanterias = CtrlPresentacion.getNEstanterias(nombreSupermercado);
        JPanel panelCentro = new JPanel();
        panelCentro.setLayout(new GridLayout((int) estanterias, 1, 10, 10)); // Usar GridLayout con el número de filas y columnas

        ArrayList<String> nombreProductos = CtrlPresentacion.getNombresProds(nombreSupermercado);
        int numBotones = nombreProductos.size();
        for (int i = 1; i <= estanterias; i++) {
            int prodsFila = (int) Math.ceil(numBotones/(estanterias-i+1));
            JPanel panelAux = new JPanel();
            panelAux.setLayout(new GridLayout(1, CtrlPresentacion.getProdFila(nombreSupermercado), 10, 10));

            for(int j = 0; j < prodsFila; j++) {
                JButton boton = new JButton(nombreProductos.get(nombreProductos.size()-numBotones));

                double precio = CtrlPresentacion.getPrecio(nombreSupermercado, nombreProductos.get(nombreProductos.size()-numBotones));
                if(precio < 10) boton.setBackground(new Color(144, 238, 144));
                else if(precio < 25) boton.setBackground(new Color(255, 200, 100));
                else boton.setBackground(new Color(255, 140, 153));

                boton.setOpaque(true);
                boton.setBorderPainted(false);
                boton.setFocusPainted(false);
                boton.setContentAreaFilled(true);

                boton.setPreferredSize(new Dimension(125, 50));

                boton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String producto = boton.getText();
                        System.out.println("Prod: " + producto);
                        frame.dispose();
                        new VistaProducto(nombreSupermercado, producto);
                    }
                });

                panelAux.add(boton);
                --numBotones;
            }

            panelCentro.add(panelAux);
        }

        JScrollPane scrollPane = new JScrollPane(panelCentro);
        scrollPane.setPreferredSize(new Dimension(450, 400));
        panelPrincipal.add(scrollPane, BorderLayout.CENTER);
        frame.add(panelPrincipal);
        frame.setVisible(true);
    }
}