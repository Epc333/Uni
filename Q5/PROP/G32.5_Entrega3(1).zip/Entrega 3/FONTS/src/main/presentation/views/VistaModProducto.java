package src.main.presentation.views;

import src.main.presentation.controllers.CtrlPresentacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Esta vista permite modificar los atributos del producto.
 * Consta de dos campos, ya rellenados con el nombre y precio actuales para que podamos modificarlos.
 * Además tendremos debajo el botón de modificar para confirmar los cambios y el botón de salida en
 * la esquina superior derecha.
 * @author Vinyet Granda Planas (vinyet.granda@estudiantat.upc.edu)
 */

public class VistaModProducto extends JFrame {
    private JFrame frame;

    /**
     * Cosntructora de la vista
     */

    public VistaModProducto(String supermercado, String nombreProducto) {
        frame = new JFrame(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),40));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        JPanel panelPrincipal = new JPanel(new BorderLayout());

        JPanel panelSuperior = new JPanel(new BorderLayout());

        JButton botonExit = new JButton(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),1));
        panelSuperior.add(botonExit, BorderLayout.EAST);

        botonExit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new VistaProducto(supermercado, nombreProducto);
            }
        });

        panelPrincipal.add(panelSuperior, BorderLayout.NORTH);

        JPanel panelContenido = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel nombreLabel = new JLabel(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),3));
        gbc.gridx = 0;
        gbc.gridy = 0;
        panelContenido.add(nombreLabel, gbc);

        JTextField nombreText = new JTextField(15);

        gbc.gridx = 1;
        panelContenido.add(nombreText, gbc);

        JLabel precioLabel = new JLabel(CtrlPresentacion.getFrase( CtrlPresentacion.getIdioma(),4));
        gbc.gridx = 0;
        gbc.gridy = 1;
        panelContenido.add(precioLabel, gbc);

        JTextField precioText = new JTextField(15);
        gbc.gridx = 1;
        panelContenido.add(precioText, gbc);

        nombreText.setText(nombreProducto);
        precioText.setText(String.valueOf(CtrlPresentacion.getPrecio(supermercado, nombreProducto)));

        JButton modificarButton = new JButton(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),17));
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        panelContenido.add(modificarButton, gbc);

        modificarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nuevoNombre = nombreText.getText();
                String nuevoPrecio = precioText.getText();
                int error = 0;
                if(nuevoNombre.trim().isEmpty()) JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 121), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                else {
                    try {
                        error = CtrlPresentacion.modificarProd(supermercado, nombreProducto, nuevoNombre, Double.parseDouble(nuevoPrecio));
                    } catch (NumberFormatException ex) {
                        error = 118;
                    }
                    if (error == 110)
                        JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 110), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                    else if (error == 106)
                        JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 106), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                    else if (error == 116)
                        JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 116), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                    else if (error == 118)
                        JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 118), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                    else {
                        frame.dispose();
                        new VistaProducto(supermercado, nuevoNombre);
                    }
                }
            }
        });
        panelPrincipal.add(panelContenido, BorderLayout.CENTER);
        frame.add(panelPrincipal);
        frame.setVisible(true);
    }

}
