package src.main.presentation.views;

import src.main.presentation.controllers.CtrlPresentacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Esta vista permite a los usuarios crear una nueva cuenta en el sistema.
 * Esta vista consiste en una página con un título central, y diferentes campos los cuales podremos rellenar para registrarnos,
 * como el usuario, el mail, el idioma (que se selecciona con un desplegable de opciones) y la contraseña )
 * la cual tiene un boton para estar oculta o mostrarla al usuario).
 * Además tenemos debajo el botón de registrar para confirmar el registro y un botón de salida en la esquina superior derecha
 * para salir de la vista sin registrarnos.
 * @author Vinyet Granda Planas (vinyet.granda@estudiantat.upc.edu)
 */

public class VistaRegistro {
    private JFrame frame;

    /**
     * Cosntructora de la vista
     */
    public VistaRegistro() {
        String idioma = "Castellano";
        frame = new JFrame(CtrlPresentacion.getFrase(idioma, 48));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 400);

        JButton botonExit = new JButton(CtrlPresentacion.getFrase(idioma,1));
        JPanel panelSuperior = new JPanel(new BorderLayout()); //Para los botones superiores

        panelSuperior.add(botonExit, BorderLayout.EAST);

        botonExit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new VistaLogin();
            }
        });

        JPanel panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.add(panelSuperior, BorderLayout.NORTH);

        JPanel panel = new JPanel(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.CENTER;

        JLabel titulo = new JLabel(CtrlPresentacion.getFrase(idioma,48));
        titulo.setFont(titulo.getFont().deriveFont(24.0f));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(titulo, gbc);

        JLabel usuarioLabel = new JLabel(CtrlPresentacion.getFrase(idioma,10));
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(usuarioLabel, gbc);

        JTextField usuarioText = new JTextField(15);
        gbc.gridx = 1;
        panel.add(usuarioText, gbc);

        JLabel mailLabel = new JLabel(CtrlPresentacion.getFrase(idioma,11));
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(mailLabel, gbc);

        JTextField mailText = new JTextField(15);
        gbc.gridx = 1;
        panel.add(mailText, gbc);

        JLabel passwordLabel = new JLabel(CtrlPresentacion.getFrase(idioma,12));
        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(passwordLabel, gbc);

        JPasswordField passwordText = new JPasswordField(15);
        gbc.gridx = 1;
        panel.add(passwordText, gbc);

        JLabel confirmPasswordLabel = new JLabel(CtrlPresentacion.getFrase(idioma,13));
        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(confirmPasswordLabel, gbc);

        JPasswordField confirmPasswordText = new JPasswordField(15);
        gbc.gridx = 1;
        panel.add(confirmPasswordText, gbc);

        passwordText.setEchoChar('\u2022');
        confirmPasswordText.setEchoChar('\u2022');

        JButton showPasswordButton = new JButton(CtrlPresentacion.getFrase(idioma,14));
        gbc.gridx = 2;
        gbc.gridy = 3;
        gbc.gridheight = 2;
        panel.add(showPasswordButton, gbc);

        showPasswordButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (passwordText.getEchoChar() == '\u2022') {
                    passwordText.setEchoChar((char) 0);
                    confirmPasswordText.setEchoChar((char) 0);
                    showPasswordButton.setText(CtrlPresentacion.getFrase(idioma,15));
                } else {
                    passwordText.setEchoChar('\u2022');
                    confirmPasswordText.setEchoChar('\u2022');
                    showPasswordButton.setText(CtrlPresentacion.getFrase(idioma,14));
                }
            }
        });

        JLabel idiomaLabel = new JLabel(CtrlPresentacion.getFrase(idioma,16));
        String[] idiomas = { idioma, "Catalan", "Ingles", "Rumano" };
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridheight = 1;
        panel.add(idiomaLabel, gbc);

        JComboBox<String> comboBoxIdiomas = new JComboBox<>(idiomas);
        gbc.gridx = 1;
        panel.add(comboBoxIdiomas, gbc);

        JButton registrarButton = new JButton(CtrlPresentacion.getFrase(idioma,33));
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        panel.add(registrarButton, gbc);

        registrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usuarioText.getText();
                String mail = mailText.getText();
                char[] password = passwordText.getPassword();
                char[] confirmPassword = confirmPasswordText.getPassword();
                String idioma = (String) comboBoxIdiomas.getSelectedItem();

                if (new String(password).equals(new String(confirmPassword))) {
                    if(username.trim().isEmpty()) JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(idioma, 121), CtrlPresentacion.getFrase(idioma, 100), JOptionPane.ERROR_MESSAGE);
                    else if(mail.trim().isEmpty()) JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(idioma, 121), CtrlPresentacion.getFrase(idioma, 100), JOptionPane.ERROR_MESSAGE);
                    else {
                        int error = CtrlPresentacion.crearPerfil(username, mail, new String(password), idioma);
                        if (error == 101)
                            JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(idioma, 101), "Error", JOptionPane.ERROR_MESSAGE);
                        else if (error == 102)
                            JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(idioma, 102), "Error", JOptionPane.ERROR_MESSAGE);
                        else if (error == 103)
                            JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(idioma, 103), "Error", JOptionPane.ERROR_MESSAGE);
                        else if (error == 104)
                            JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(idioma, 104), "Error", JOptionPane.ERROR_MESSAGE);
                        else {
                            frame.dispose();
                            new VistaLogin();
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "Las contraseñas no coinciden.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        panelPrincipal.add(panel, BorderLayout.CENTER);
        frame.add(panelPrincipal);
        frame.setVisible(true);
    }

}