package src.main.presentation.views;

import src.main.presentation.controllers.CtrlPresentacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 * Esta vista nos mostrará un listado con todos los productos disponibles del supermercado con su nombre,
 * acompañado de su precio correspondiente.
 * Si hay muchos productos se incluye una barra de desplazamiento para explorar todas la lista.
 * En este caso solo tendremos el botón de salida en la esquina superior derecha.
 * @author Vinyet Granda Planas (vinyet.granda@estudiantat.upc.edu)
 */

public class VistaConsStock extends JFrame {
    private JFrame frame;

    /**
     * Cosntructora de la vista
     */
    public VistaConsStock(String nombreSupermercado) {
        frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 500);

        JPanel panelSuperior = new JPanel(new BorderLayout());

        JButton botonExit = new JButton(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),1));
        panelSuperior.add(botonExit, BorderLayout.EAST);

        botonExit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new VistaEstanterias(nombreSupermercado);
            }
        });

        JLabel tituloLabel = new JLabel(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),18));
        tituloLabel.setFont(tituloLabel.getFont().deriveFont(24.0f));
        tituloLabel.setHorizontalAlignment(JLabel.CENTER);
        panelSuperior.add(tituloLabel, BorderLayout.CENTER);

        JPanel panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.add(panelSuperior, BorderLayout.NORTH);

        JPanel panelCentro = new JPanel();
        panelCentro.setLayout(new BoxLayout(panelCentro, BoxLayout.Y_AXIS));

        ArrayList<String> stock = CtrlPresentacion.getStock(nombreSupermercado);
        for (int i = 0; i < stock.size(); i += 2) {
            JLabel productoLabel = new JLabel( stock.get(i) + " - " + CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),19) + (stock.get(i + 1)) + " €");
            productoLabel.setFont(productoLabel.getFont().deriveFont(14.0f));
            panelCentro.add(productoLabel);
            JLabel espacio = new JLabel(" ");
            espacio.setFont(espacio.getFont().deriveFont(4.0f));
            panelCentro.add(espacio);
        }

        JScrollPane scrollPane = new JScrollPane(panelCentro);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        panelPrincipal.add(scrollPane, BorderLayout.CENTER);

        frame.add(panelPrincipal);
        frame.setVisible(true);
    }
}

