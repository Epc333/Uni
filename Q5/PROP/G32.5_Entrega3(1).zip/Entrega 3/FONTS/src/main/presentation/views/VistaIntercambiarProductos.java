package src.main.presentation.views;

import src.main.presentation.controllers.CtrlPresentacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

/**
 * Esta vista muestra los atributos del producto, con dos títulos uno para el nombre y otro para el precio.
 * Además tendremos un desplegable para ver todas las similitudes que tiene ese producto con otros de su
 * mismo supermercado. Debajo tenemos un botón de gestión de similitud que nos permitirá ver el porcentaje
 * de similitud, modificarlo o eliminar la similitud.
 * Además en la esquina superior derecha tendremos un botón que nos permitirá acceder a diferentes vistas
 * respecto al producto.
 * @author Vinyet Granda Planas (vinyet.granda@estudiantat.upc.edu)
 */

public class VistaIntercambiarProductos extends JFrame {
    private JFrame frame;

    /**
     * Cosntructora de la vista
     */

    public VistaIntercambiarProductos(String supermercado) {
        frame = new JFrame(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 49));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 400);

        JPanel panelPrincipal = new JPanel(new BorderLayout());

        JPanel panelSuperior = new JPanel(new BorderLayout());
        JButton exit = new JButton(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 1));
        panelSuperior.add(exit, BorderLayout.EAST);

        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new VistaEstanterias(supermercado);
            }
        });
        panelPrincipal.add(panelSuperior, BorderLayout.NORTH);

        JPanel panelContenido = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel tituloLabel = new JLabel(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 49), SwingConstants.CENTER);
        tituloLabel.setFont(tituloLabel.getFont().deriveFont(24.0f));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panelContenido.add(tituloLabel, gbc);

        JLabel Prod1Label = new JLabel(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),50));
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        panelContenido.add(Prod1Label, gbc);

        JComboBox<String> comboBoxProductos1 = new JComboBox<>(CtrlPresentacion.getProductos(supermercado).toArray(new String[0]));
        gbc.gridx = 1;
        panelContenido.add(comboBoxProductos1, gbc);

        JLabel Prod2Label = new JLabel(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),51));
        gbc.gridx = 0;
        gbc.gridy = 2;
        panelContenido.add(Prod2Label, gbc);

        JComboBox<String> comboBoxProductos2 = new JComboBox<>(CtrlPresentacion.getProductos(supermercado).toArray(new String[0]));
        gbc.gridx = 1;
        panelContenido.add(comboBoxProductos2, gbc);

        JButton intercambiarButton = new JButton(CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(),52));
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        panelContenido.add(intercambiarButton, gbc);

        panelPrincipal.add(panelContenido, BorderLayout.CENTER);

        intercambiarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombreProducto1 = (String) comboBoxProductos1.getSelectedItem();
                String nombreProducto2 = (String) comboBoxProductos2.getSelectedItem();
                int error = CtrlPresentacion.intercambiarProductos(supermercado, nombreProducto1, nombreProducto2);
                if(error == 113) JOptionPane.showMessageDialog(frame, CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 113), CtrlPresentacion.getFrase(CtrlPresentacion.getIdioma(), 100), JOptionPane.ERROR_MESSAGE);
                else {
                    frame.dispose();
                    new VistaEstanterias(supermercado);
                }
            }
        });


        frame.add(panelPrincipal);
        frame.setVisible(true);
    }
}
