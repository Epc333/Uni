package src.main.presentation.controllers;

import java.lang.reflect.Array;
import java.util.ArrayList;

import src.main.domain.classes.exceptions.SizePasswordException;
import src.main.domain.controllers.CtrlDominio;
import src.main.presentation.views.VistaEstanterias;
import src.main.presentation.views.VistaLogin;
import src.main.presentation.views.VistaMenuSupermercado;

/**
 * Esta classe controla la capa de Presentacion
 * Permite gestionar la interacción entre la capa de presentación y la capa de dominio
 * @author Eudald Pizarro (eudald.pizarro@estudiantat.upc.edu)
 */

public class CtrlPresentacion {

    /** Controlador de la capa de dominio */
    private static CtrlDominio cd = new     CtrlDominio();

    /**
     * Esta funcion inicia la vista principal del programa
     */

    public static void iniciar() {
        new VistaLogin();
    }

    /**
     * Esta funcion inicia la sesion del Usuario con su usuario y contraseña
     * @param username Nombre de usuario 
     * @param password Contraseña del usuario
     * @return True si se ha podido iniciar sesion, False en caso contrario
     */
    public static int LogIn(String username, String password) {
        try {
            cd.logIn(username, password);
        } catch (Exception e) {
            if(e.getMessage().contains("Password Error!")) return 104;
            else if(e.getMessage().contains("No user with this username")) return 112;
            else if(e.getMessage().contains("Incorrect password")) return 114;
        }
        return 0;
    }

    /**
     * Esta funcion guarda los datos modificados del usuario hasta ahora y cierra la sesion del usuario actual
     */
    public static void LogOut(){
        cd.logOut();
    }

    /**
     * Esta funcion crea una cuenta en nuestro sistema con los datos indicdos
     * @param username El nombre del usuario
     * @param email El email del usuario
     * @param password La contraseña del usuario
     * @param idioma El idioma en el que se quiere ver el programa
     * @return Uno de los posibles casos de error
     */
    public static int crearPerfil(String username, String email, String password, String idioma) {
        try {
            cd.crearPerfil(username, password, idioma, email);
        } catch (Exception e) {
            if (e.getMessage().contains("This name has been registered")) {
                return 101;
            } else if (e.getMessage().contains("This mail has been registered")) {
                return 102;
            } else if (e.getMessage().contains(idioma + "is not a valid language")){
                return 103;
            } else if (e.getMessage().contains(("Password Error!"))) {
                return 104;
            }
        }
        return 0;
    }

    /**
     *  Esta funcion borra todos los Supermercados de la cuenta del usuario
     */
    public static void borrarSupermercados(){
        cd.borrarSupermercados();
    }

    /**
     *  Esta funcion guarda los datos del usuario
     */
    public static void guardar(){
        cd.guardarUsuarioMemoria();
    }

    /**
     * Esta funcion debuelve el numero total de supermercados que tiene el usuario creados
     * @return Uno de los posibles casos de error
     */
    public static int getNumSupermercados(){
        return cd.getNombresSupers().size();
    }

    /**
     * Esta funcion devuelve el nombre de todos los supermercados que tiene el usuario creados
     * @return Lista de nombres de supermercado
     */
    public static ArrayList<String> getNombresSupers(){
        return cd.getNombresSupers();
    }

    /** 
     * Esta funcion devuelve el numero de estanterias del supermercado selecionado
     * @param supermercado Nombre del supermercado
     * @return El numero de estanterias
     */
    public static int getNEstanterias(String supermercado){
        ArrayList<String> info = cd.consultaSupermercado(supermercado);
        return Integer.parseInt(info.get(2)); // 0 -> nombre, 1 -> fecha, 2 -> numEstanterias
    }

    /**
     * Esta funcion devuelve el número de productos que hay en cada estanteria
     * @param supermercado Nombre del supermercado
     * @return El número de productos por estanteria
     */
    public static int getProdFila(String supermercado){
        ArrayList<String> info = cd.consultaSupermercado(supermercado);
        double estantes_aux = (double) Integer.parseInt(info.get(3))/Integer.parseInt(info.get(2));
        return (int) Math.ceil(estantes_aux);
    }

    /** 
     * Esta funcion duplica un supermercado
     * @param nombreOriginal Nombre del supermercado original
     * @param nombreNuevo Nomrbe del nuevo supermercado duplicado
     * @return Uno de los posibles casos de error
     */
    public static int duplicaSupermercado(String nombreOriginal, String nombreNuevo){
        try{
            cd.duplicarSupermercado(nombreOriginal, nombreNuevo);
            cd.guardarUsuarioMemoria();
        }
        catch(Exception e){
            if (e.getMessage().contains(("There is a super with this name"))){
                return 105;
            }
        }
        return 0;
    }

    /** 
     * Esta funcion crea un nuevo supermercado
     * @param nombre El nombre del supermercado
     * @param estanterias El número de estanterías
     * @return Uno de los posibles casos de error
     */
    public static int generarSupermercado(String nombre, int estanterias){
        try{
            cd.generarSupermercado(nombre, estanterias);
        } catch(Exception e){
            if (e.getMessage().contains(("Error: There is a super with this name"))){
                return 105;
            }
            else if(e.getMessage().contains(("This name is not valid"))){
                return 105;
            }
        }
        return 0;
    }

    /** 
     * Esta funcion borra el supermercado selecionado
     * @param nombreSupermercado El nombre del supermercado
     * @return Uno de los posibles casos de error
     */
    public static int borrarSupermercado(String nombreSupermercado){
        try {
            cd.eliminarSupermercado(nombreSupermercado);
            cd.guardarUsuarioMemoria();
        }catch(Exception e){}
        return 0;
    }

    /** 
     * Esta funcion modifica el nombre o el algoritmo de un supermercado
     * @param nombreSupermercado El nombre actual del supermercado
     * @param newNombreSupermercado El nuevo nombre
     * @param algoritmo El nuevo algoritmo
     * @return Uno de los posibles casos de error
     */
    public static int modificarSuper(String nombreSupermercado, String newNombreSupermercado, String algoritmo){
        try{
            if(nombreSupermercado == newNombreSupermercado) {
                cd.modificarSupermercado(nombreSupermercado, newNombreSupermercado);
            }
            cd.cambiarAlgoritmo(newNombreSupermercado, algoritmo);
            cd.guardarUsuarioMemoria();
        } catch(Exception e){
            if (e.getMessage().contains(("There is a super with this name"))){
                return 105;
            }
            else if (e.getMessage().contains(("There is no algorithm selected"))){
                return 117;
            }
        }
        return 0;
    }

    /** 
     * Esta funcion devuelve el stock del supermercado indicado
     * @param nombreSupermercado Nombre del supermercado
     * @return Una lista con le nombre y el precio de todos los productos del supermercado selecionado
     */
    public static ArrayList<String> getStock(String nombreSupermercado){
        return cd.consultaStock(nombreSupermercado);
    }

    /** 
     * Esta funcion crea un producto en el supermercado indicado
     * @param nombreSupermercado Nombre del supermercado
     * @param nombreProd Nombre del producto
     * @param precio Precio del producto
     * @return Uno de los posibles casos de error
     */
    public static int crearProd(String nombreSupermercado, String nombreProd, Double precio){
        try{
            cd.anadirProducto(nombreSupermercado, nombreProd, precio);
        } catch(Exception e){
            if (e.getMessage().contains(("It already exists the product"))){
                return 106;
            }
            else if (e.getMessage().contains(("Product already exists"))) {
                return 106;
            }
            else if (e.getMessage().contains(("Invalid price"))){
                return 116;
            }
        }
        return 0;
    }

    /** 
     * Esta funcion elimina el prodcuto indicado del supermercado indicado
     * @param nombreSupermercado Nombre del supermercado
     * @param nombreProd Nombre del producto
     * @return Uno de los posibles casos de error
     */
    public static int eliminarProd(String nombreSupermercado, String nombreProd){
        try {
            cd.eliminarProducto(nombreSupermercado, nombreProd);
            cd.guardarUsuarioMemoria();
        } catch(Exception e){
            if (e.getMessage().contains(("Error: There isn't a product with this name"))){
                return 107;
            }
        }
        return 0;
    }

    /** 
     * Esta funcion elimina una Similitud entre dos productos
     * @param nombreSupermercado Nombre del supermercado
     * @param nombreProducto Nombre del producto1
     * @param nombreProducto2 Nombre del producto2
     * @return Uno de los posibles casos de error
     */
    public static int eliminarSimilitud(String nombreSupermercado, String nombreProducto, String nombreProducto2){
        cd.eliminarSimilitud(nombreSupermercado, nombreProducto, nombreProducto2);
        cd.guardarUsuarioMemoria();
        return 0;
    }

    /** 
     * Esta funcion devuelve una similitud
     * @param nombreSupermercado Nombre del supermercado
     * @param nombreProducto Nombre del producto1
     * @param nombreProducto2 Nombre del producto2
     * @return El porcentaje de similitus y en caso contrario uno de los posibles casos de error
     */
    public static int getSimilitud(String nombreSupermercado, String nombreProducto, String nombreProducto2){
        try {
            return cd.consultaSimilitud(nombreSupermercado, nombreProducto, nombreProducto2);
        } catch(Exception e){
        }
        return 0;
    }

    /**
     * Esta funcion modifica un producto de un supermercado
     * @param nombreSupermercado Nombre del supermercado
     * @param nombreProducto Nombre del producto a modificar
     * @param nuevoNombre Nuevo nombre del producto
     * @param nuevoPrecio Nuevo precio del producto
     * @return Uno de los posibles casos de error
     */
    public static int modificarProd(String nombreSupermercado, String nombreProducto, String nuevoNombre, Double nuevoPrecio){
        try{
            cd.modificarProducto(nombreSupermercado, nombreProducto, nuevoNombre, nuevoPrecio);
            cd.guardarUsuarioMemoria();
        } catch(Exception e){
            if (e.getMessage().contains(("There is no values to modify"))){
                return 110;
            }
            else if (e.getMessage().contains(("Product already exists"))) {
                return 106;
            }
            else if (e.getMessage().contains(("Invalid price"))){
                return 116;
            }
        }
        return 0;
    }

    /** 
     * Esta funcion crea una similitud
     * @param nombreSupermercado Nombre del supermercado
     * @param prod1 Nombre del producto1
     * @param prod2 Nombre del producto2
     * @param porcentaje Porcentaje de similitud
     * @return Uno de los posibles casos de error
     */
    public static int crearSimilitud(String nombreSupermercado, String prod1, String prod2, int porcentaje){
        try{
            cd.crearSimilitud(nombreSupermercado, prod1, prod2, porcentaje);
        }catch(Exception e){
            if (e.getMessage().contains(("The Similarity already exists"))){
                return 111;
            }
            else if (e.getMessage().contains(("Invalid value of similarity"))){
                return 115;
            }
        }
        return 0;
    }
    
    /** 
     * Esta funcion modifica una similitud
     * @param nombreSupermercado Nombre del supermercado
     * @param prod1 Nombre del producto1
     * @param prod2 Nombre del producto2
     * @param nuevaSimilitud Nuevo porcentaje de similitud
     * @return Uno de los posibles casos de error
     */
    public static int modSimilitud(String nombreSupermercado, String prod1, String prod2, int nuevaSimilitud){
        try {
            cd.modificarSimilitud(nombreSupermercado, prod1, prod2, nuevaSimilitud);
        } catch(Exception e){
            if (e.getMessage().contains(("The Similarity doesn't exist"))){
                return 109;
            }
            else if (e.getMessage().contains(("Invalid value of similarity"))){
                return 115;
            }
        }
        return 0;
    }

    /** 
     * Esta funcion devuelve el nombre del usuario logeado
     * @return El nombre del usuario
     */
    public static String getName(){
        return cd.getName();
    }

    /** 
     * Esta funcion devuelve el email del usuario logeado
     * @return El email del usuario logeado
     */
    public static String getEmail(){
        ArrayList<String> info = cd.getDatosUsuarios();
        return info.get(5); // 1 -> nombre, 3 -> contraseña,  5 -> email, 7 -> idioma
    }

    /** 
     * Esta funcion devuelve el idioma del usuario logeado
     * @return El idioma del usuario logeado
     */
    public static String getIdioma(){
        ArrayList<String> info = cd.getDatosUsuarios();
        return info.get(7); // 1 -> nombre, 3 -> contraseña,  5 -> email, 7 -> idioma
    }

    /** 
     * Esta funcion devuelve la lista de similitudes de un producto
     * @param supermercado Supermercado al que pertenece el producto
     * @param producto Nombre del producto
     * @return Una lista de los nombres con los que le producto tiene alguna similitud
     */
    public static ArrayList<String> getSimilitudes(String supermercado, String producto){
        ArrayList<String> info = cd.consultaSimilitudes(supermercado,producto);
        ArrayList<String> aux = new ArrayList<>();
        for(int i = 0; i < info.size(); i += 2){
            aux.add(info.get(i));
        }
        return aux;
    }

    /** 
     * Esta funcion devuelve una frase en el idioma indicado
     * @param idioma Nombre del idioma
     * @param i Identificador de la frase
     * @return Un string que corresponde a la frase pedida
     */
    public static String getFrase (String idioma, int i){
        return cd.getFrase(idioma, i);
    }

    /** 
     * Esta funcion devuelve la lista de los nombres de los productos de un supermercado
     * @param supermercado nombre del supermercado
     * @return Una lista de los nombres de lso productos del supermercado
     */
    public static ArrayList<String> getNombresProds(String supermercado){
        ArrayList<String> stock = cd.consultaStock(supermercado);
        ArrayList<String> prods = new ArrayList<>();
        for(int i = 0; i < stock.size(); i += 2){
            prods.add(stock.get(i));
        }
        return prods;
    }

    /** 
     * Esta funcion devuelve el precio de un producto
     * @param nombreSupermercado Nombre del supermercado
     * @param producto Nombre del producto
     * @return El precio de un producto
     */
    public static double getPrecio(String nombreSupermercado, String producto) {
        return Double.parseDouble(cd.consultaProducto(nombreSupermercado, producto).get(1));
    }

    /**
     * Esta funcion modifica los datos del usuario
     * @param nombre Nuevo nombre del usuario
     * @param email Nuevo email del usuario
     * @param password Nueva contraseña del usuario
     * @param idioma Nuevo idioma del usuario
     * @return Uno de los posibles casos de error
     */
    public static int modificarUsuario(String nombre, String email, String password, String idioma) {
        try {
            cd.modificarPerfil(nombre, password, idioma, email);
        } catch (Exception e) {
            if (e.getMessage().contains(("Error: There is no value to modify"))) {
                return 110;
            } else if (e.getMessage().contains(("The username already exists"))) {
                return 101;
            }
            else if(e.getMessage().contains(("Password Error!"))) return 104;
        }
        return 0;
    }

    /**
     * Esta funcion devuelve la contraseña del usuario
     * @return La contraseña del usuario
     */ 
    public static String getPassword(){
        return cd.getPassword();
    }

    /**
     * Esta funcion devuelve el algoritmo con el que se ha ordenado un supermercado
     * @param supermercado Nombre del supermercado
     * @return El algoritmo del supermercado
     */
    public static String getAlgoritmo(String supermercado){
        return cd.getAlgoritmo(supermercado);
    }

    /**
     * Esta funcion devuelve una lista con los productos que tienen similitud con el producto pasado como parametro
     * @param supermercado Supermercado al que pertenece el producto
     * @param producto Nombre del producto que se quieren obtener las similitudes
     * @return Una lista con los nombres de los productos que tienen similitud con el producto pasado como parametro
     */
    public static ArrayList<String> getProductosSim(String supermercado, String producto){
        ArrayList<String> stock = cd.consultaStock(supermercado);
        ArrayList<String> prods = new ArrayList<>();
        for(int i = 0; i < stock.size(); i += 2){
            if(!stock.get(i).equals(producto)) prods.add(stock.get(i));
        }
        return prods;
    }

    /**
     * Esta funcion devuelve una lista con los productos de un supermercado
     * @param supermercado Nombre del supermercado
     * @return Una lista con los nombres de los productos del supermercado
     */
    public static ArrayList<String> getProductos(String supermercado){
        ArrayList<String> stock = cd.consultaStock(supermercado);
        ArrayList<String> prods = new ArrayList<>();
        for(int i = 0; i < stock.size(); i += 2){
            prods.add(stock.get(i));
        }
        return prods;
    }

    /**
     * Esta funcion intercambia dos productos de un supermercado
     * @param supermercado Nombre del supermercado
     * @param producto1 Nombre del primer producto
     * @param producto2 Nombre del segundo producto
     * @return Uno de los posibles casos de error
     */
    public static int intercambiarProductos(String supermercado, String producto1, String producto2){
        try{
            cd.intercambiarProductos(supermercado, producto1, producto2);
        }
        catch (Exception e){
            if (e.getMessage().contains(("Error: You have selected the same product"))){
                return 113;
            }
        }
        return 0;
    }

    /**
     * Esta funcion elimina el usuario actual
     */
    public static void eliminarUsuario(){
        cd.eliminarPerfil();
    }
}

