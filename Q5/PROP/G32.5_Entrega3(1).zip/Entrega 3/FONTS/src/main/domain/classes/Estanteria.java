package src.main.domain.classes;

import java.util.ArrayList;

/**
 * Esta clase contiene los métodos para gestionar la distribución de productos en una estantería.
 * @author Eudald Pizarro Cami (eudald.pizarro@estudiantat.upc.edu)
 */
public class Estanteria {
    /** Lista que contiene los productos en la estantería. */
    private ArrayList<Producto> fila;

    /**
     * Constructora por defecto que inicializa una estantería vacía.
     */
    public Estanteria() {
        this.fila = new ArrayList<Producto>();
    }

    /**
     * Constructora de copia que crea una nueva estantería copiando los productos de otra estantería.
     * @param estanteria La estantería a copiar.
     */
    public Estanteria(Estanteria estanteria) {
        this.fila = new ArrayList<>();
        for (Producto p : estanteria.fila) {
            Producto act = new Producto(p);
            this.fila.add(act);
        }
    }

    /**
     * Constructora que inicializa la estantería con una lista de productos.
     * @param prod Lista de productos para inicializar la estantería.
     */
    public Estanteria(ArrayList<Producto> prod) {
        this.fila = new ArrayList<>();
        for (int i = 0; i < prod.size(); i++) {
            this.fila.add(prod.get(i));
        }
    }

    /**
     * Reemplaza el producto en la posición especificada de la estantería.
     * @param i Índice del producto a reemplazar.
     * @param producto El producto con el que se reemplazará.
     */
    public void replace(int i, Producto producto) {
        this.fila.set(i, producto);
    }

    /**
     * Inserta un producto en una posición específica de la estantería.
     * @param i Índice en el cual insertar el producto.
     * @param producto El producto a insertar.
     */
    public void insertProducto(int i, Producto producto) {
        this.fila.add(i, producto);
    }

    /**
     * Elimina un producto específico de la estantería.
     * @param producto El producto a eliminar.
     */
    public void removeProducte(Producto producto) {
        this.fila.remove(producto);
    }

    /**
     * Elimina el producto en la posición especificada de la estantería.
     * @param i Índice del producto a eliminar.
     */
    public void removeProducte(int i) {
        this.fila.remove(i);
    }

    /**
     * Añade un producto al final de la estantería.
     * @param producto El producto a añadir.
     */
    public void agregarProducto(Producto producto) {
        this.fila.add(producto);
    }

    /**
     * Devuelve el producto en la posición especificada de la estantería.
     * @param i Índice del producto a obtener.
     * @return El producto en la posición indicada.
     */
    public Producto getProducto(int i) {
        return this.fila.get(i);
    }

    /**
     * Devuelve un producto en función de su nombre.
     * @param nombre Nombre del producto a buscar.
     * @return El producto con el nombre especificado o null si no se encuentra.
     */
    public Producto getProducto(String nombre) {
        for (int i = 0; i < fila.size(); i++) {
            if (fila.get(i).getNombre().equals(nombre)) {
                return fila.get(i);
            }
        }
        return null;
    }

    /**
     * Devuelve el número total de productos en la estantería.
     * @return El número de productos.
     */
    public int getNumeroDeProductos() {
        return this.fila.size();
    }

    /**
     * Devuelve una lista con todos los productos de la estantería.
     * @return Una lista de productos en la estantería.
     */
    public ArrayList<Producto> getProductos() {
        return new ArrayList<>(fila);
    }

    /**
     * Devuelve una lista con los productos de la estantería (similar a getProductos).
     * @return Una lista con los productos en la estantería.
     */
    public ArrayList<Producto> consultarEstanterias() {
        ArrayList<Producto> prods = new ArrayList<>();
        for (int i = 0; i < fila.size(); i++) {
            prods.add(fila.get(i));
        }
        return prods;
    }

    /**
     * Elimina todos los productos de la estantería.
     */
    public void limpiarDatos() {
        fila.clear();
    }

    /**
     * Devuelve una lista con los identificadores de los productos de la estantería.
     * @return Una lista de enteros que representan los identificadores de los productos.
     */
    public ArrayList<Integer> getIdentificadores() {
        ArrayList<Integer> identificadores = new ArrayList<>();
        for (int i = 0; i < fila.size(); i++) {
            identificadores.add(fila.get(i).getId());
        }
        return identificadores;
    }

    /**
     * Verifica si existe un producto en la estantería con un nombre específico.
     * @param nombre El nombre del producto a buscar.
     * @return true si existe el producto, false en caso contrario.
     */
    public boolean existsProducto(String nombre) {
        for (int i = 0; i < fila.size(); i++) {
            if (fila.get(i).getNombre().equals(nombre)) return true;
        }
        return false;
    }

    /**
     * Devuelve la posición de un producto en la estantería dado su nombre.
     * @param nombre El nombre del producto.
     * @return La posición del producto o null si no se encuentra.
     */
    public Integer getPosicion(String nombre) {
        for (int i = 0; i < fila.size(); i++) {
            if (fila.get(i).getNombre().equals(nombre)) return i;
        }
        return null;
    }
}

