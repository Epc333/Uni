package src.main.domain.classes.functions;

import src.main.domain.classes.Algoritmo;

import java.util.ArrayList;
import java.util.List;

/**
 * Aproximacion es una subclase de Algoritmo que implementa un algoritmo de ordenación de productos de 2-aproximación.
 * @author Asier García Elvira (asier.garcia@estudiantat.upc.edu)
 */
public class Aproximacion extends Algoritmo {

    /* Método que implementa ordenar de Algoritmo con un algoritmo de 2-aproximación
     * @parametros Matriz de similitudes con índice igual a posición del producto y lista de posiciones, con indice igual a posicion y contenido igual a id producto
     * @return Lista con los ids de productos ordenados
     */

    @Override
    public ArrayList<Integer> buscarSolucion(ArrayList<ArrayList<Integer>> similitudes, ArrayList<Integer> posiciones) {
        int n = similitudes.size();

        // Construir el Árbol de Expansión Máxima en términos de posiciones
        List<Arista> aristas = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                aristas.add(new Arista(i, j, similitudes.get(i).get(j)));
            }
        }

        // Ordenar aristas por peso de mayor a menor
        aristas.sort((a1, a2) -> a2.getPeso() - a1.getPeso());

        // Usamos Union-Find para evitar ciclos
        UnionFind uf = new UnionFind(n);
        ArrayList<ArrayList<Integer>> mst = new ArrayList<>();
        for (int i = 0; i < n; i++) mst.add(new ArrayList<>());

        for (Arista arista : aristas) {
            if (uf.unir(arista.getDesde(), arista.getHasta())) {
                mst.get(arista.getDesde()).add(arista.getHasta());
                mst.get(arista.getHasta()).add(arista.getDesde());
            }
        }

        // Recorrido en preorden para obtener el orden aproximado (en términos de posiciones)
        ArrayList<Integer> ordenPosiciones = new ArrayList<>();
        boolean[] visitado = new boolean[n];
        dfsPreorden(0, mst, visitado, ordenPosiciones);

        // Traducir el orden de posiciones a ids de productos
        ArrayList<Integer> ordenProductos = new ArrayList<>();
        for (int posicion : ordenPosiciones) {
            ordenProductos.add(posiciones.get(posicion));
        }

        return ordenProductos;
    }

    /* Esta función recursiva realiza un DFS en preorden en un árbol
     * @parametros El nodo actual, el árbol, un array de visitados y una lista con el orden hasta el momento
     */

    private static void dfsPreorden(int nodo, ArrayList<ArrayList<Integer>> mst, boolean[] visitado, ArrayList<Integer> orden) {
        visitado[nodo] = true;
        orden.add(nodo);
        for (int vecino : mst.get(nodo)) {
            if (!visitado[vecino]) {
                dfsPreorden(vecino, mst, visitado, orden);
            }
        }
    }
}