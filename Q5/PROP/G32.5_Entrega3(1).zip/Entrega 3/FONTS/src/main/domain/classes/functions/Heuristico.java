package src.main.domain.classes.functions;

import src.main.domain.classes.Estado;


/**
 * Esta clase representa cuanto de bueno es una distribucion de productos, en otras palabras,
 * representa el Huristico del Hill-Climbing
 * @author Andres Lucian Laptes Costan (andres.lucian.laptes@estudiantat.upc.edu)
 * */
public class Heuristico {
    private int value;

    public Heuristico(Estado act) {
        value = 0;

        int end = act.getNumeroProductos();
        for (int i = 0; i < end; ++i) {
            if (i == 0) {
                value += act.getSimilitudProductos(i, end - 1) + act.getSimilitudProductos(i, i + 2);
            } else if (i == end - 1) {
                value += act.getSimilitudProductos(i, i - 1) + act.getSimilitudProductos(i, 0);
            } else {
                value += act.getSimilitudProductos(i, i - 1) + act.getSimilitudProductos(i, i + 1);
            }
        }
    }

    public int getValue() {return value;}

    public boolean isLower(Heuristico a) {
        return value < a.value;
    }

    public boolean isUpper(Heuristico a) {
        return value > a.value;
    }
}
