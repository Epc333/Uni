package src.main.domain.controllers;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import src.main.domain.classes.*;
import src.main.domain.classes.exceptions.ExcepcionNoAlgoritmo;
import src.main.domain.classes.exceptions.ExcepcionTamanyosDistintos;

/**
 * El controlador de Supermercado se encarga de gestionar los productos, la gestión del supermercado, los algoritmos y las estanterías.
 * @author Eudald Pizarro Cami (eudald.pizarro@estudiantat.upc.edu)
 */
public class CtrlSupermercado {

    //** Lista de supermercados */
    private ArrayList<Supermercado> Supermercados;

    //** Instancia CtrlProducto */
    private CtrlProducto Productos;

    //** Último identificador de producto usado */
    private int ultimoId;

    //** Mapa de algoritmos asociados a los supermercados */
    private Map<String, String> AlgoritmoSupers;

    // CONSTRUCTORAS

    /**
     * Constructora por defecto del controlador de supermercado.
     * Inicializa los atributos principales.
     */
    public CtrlSupermercado(){
        this.Supermercados = new ArrayList<Supermercado>();
        this.Productos = new CtrlProducto();
        this.ultimoId = 0;
        this.AlgoritmoSupers = new LinkedHashMap<>();
    }

    /**
     * Constructora con parámetros para crear un supermercado específico.
     * @param nombre El nombre del supermercado.
     * @param n_estanterias El número de estanterías del supermercado.
     * @throws ExcepcionNoAlgoritmo si no hay algoritmo asociado.
     */
    public CtrlSupermercado(String nombre, int n_estanterias) throws ExcepcionNoAlgoritmo {
        this.Supermercados = new ArrayList<>();
        this.Productos = new CtrlProducto();
        this.ultimoId = 0;
        this.AlgoritmoSupers = new LinkedHashMap<>();
        Supermercado supermercado = new Supermercado(nombre, n_estanterias);
        Supermercados.add(supermercado);
        AlgoritmoSupers.put(supermercado.getNombre(), "NoAlgoritmo");
    }

    /**
     * Constructora de copia.
     * Crea un nuevo controlador de supermercado a partir de otro existente.
     * @param s El controlador de supermercado a copiar.
     */
    public CtrlSupermercado(CtrlSupermercado s) {
        this.Supermercados = new ArrayList<>();
        for (Supermercado supermercado : s.Supermercados){
            this.Supermercados.add(new Supermercado(supermercado));
        }
        this.Productos = new CtrlProducto(s.Productos);
        this.ultimoId = s.ultimoId;
        this.AlgoritmoSupers = s.AlgoritmoSupers;
    }

    /**
     * Genera un nuevo supermercado y lo añade a la lista de supermercados.
     * @param nombre El nombre del supermercado.
     * @param n_estanterias El número de estanterías del supermercado.
     */
    public void generarSuper(String nombre, int n_estanterias) {
        if(nombre != null && AlgoritmoSupers.get(nombre) != null)
            throw new IllegalArgumentException("This name is not valid");
        Supermercado aux = new Supermercado(nombre, n_estanterias);
        Supermercados.add(aux);
        AlgoritmoSupers.put(nombre, "NoAlgoritmo");
    }

    // MODIFICADORAS

    /**
     * Modifica el nombre de un supermercado existente.
     * @param nombreSuper El nombre actual del supermercado.
     * @param nuevoNombre El nuevo nombre para el supermercado.
     */
    public void modificarNombre(String nombreSuper, String nuevoNombre){
        if(nuevoNombre != null && AlgoritmoSupers.get(nuevoNombre) == null) {
            for (Supermercado supermercado : Supermercados) {
                if (supermercado.getNombre().equals(nombreSuper)) {
                    Productos.modificarNombreSuper(nombreSuper, nuevoNombre);
                    supermercado.modificarNombre(nuevoNombre);
                    AlgoritmoSupers.put(nuevoNombre, AlgoritmoSupers.get(nombreSuper));
                    AlgoritmoSupers.remove(nombreSuper);
                    break;
                }
            }
        } else throw new IllegalArgumentException("There is a super with this name");
    }

    /**
     * Agrega un producto a un supermercado.
     * @param nombreSuper El nombre del supermercado.
     * @param nombreProd El nombre del producto.
     * @param precio El precio del producto.
     */
    public void agregarProducto(String nombreSuper, String nombreProd, double precio){
        for (Supermercado supermercado : Supermercados){
            if (supermercado.getNombre().equals(nombreSuper)){
                if (!Productos.existsProducto(nombreSuper, nombreProd)) {
                    Productos.agregarProducto(nombreSuper, nombreProd, ultimoId, precio);
                    Producto p = Productos.getProducto(nombreSuper, nombreProd);
                    supermercado.agregarProducto(p);
                    ultimoId += 1;
                }
                else throw new IllegalArgumentException("It already exists the product");
                break;
            }
        }
        throw new IllegalArgumentException("The supermarket doesn't exists");
    }

    /**
     * Elimina un producto de un supermercado.
     * @param nombreSuper El nombre del supermercado.
     * @param nombreProd El nombre del producto.
     */
    public void eliminarProducto(String nombreSuper, String nombreProd){
        boolean found = false;
        for (Supermercado supermercado : Supermercados){
            if (supermercado.getNombre().equals(nombreSuper)){
                if (Productos.existsProducto(nombreSuper, nombreProd)){
                    Productos.eliminarProducto(nombreSuper, nombreProd);
                    supermercado.eliminarProducto(nombreProd);
                    found = true;
                    break;
                }
                else throw new IllegalArgumentException("The product doesn't exists");
            }
        }
        if (!found) throw new IllegalArgumentException("The supermarket doesn't exists");
    }

    /**
     * Cambia el algoritmo asociado a un supermercado.
     * @param nombreSuper El nombre del supermercado.
     * @param alg El nombre del nuevo algoritmo.
     * @throws ExcepcionTamanyosDistintos si los tamaños de los arrays no coinciden.
     * @throws ExcepcionNoAlgoritmo si el algoritmo no es válido.
     */
    public void cambiarAlgoritmo(String nombreSuper, String alg) throws ExcepcionTamanyosDistintos, ExcepcionNoAlgoritmo {
        AlgoritmoSupers.put(nombreSuper, alg);
        for (Supermercado supermercado : Supermercados){
            if (supermercado.getNombre().equals(nombreSuper)){
                CtrlAlgoritmo algoritmo = new CtrlAlgoritmo(alg);

                ArrayList<Integer> posiciones = supermercado.getIdentificadores();
                ArrayList<ArrayList<Integer>> similitudes = getSimilitudes(nombreSuper, posiciones);

                posiciones = algoritmo.getSolucion(similitudes, posiciones);

                ArrayList<Producto> productosOrdenados = new ArrayList<>();
                ArrayList<Producto> prod = Productos.getProductos(nombreSuper);
                for (Integer id : posiciones) {
                    for (Producto p : prod) {
                        if (p.getId() == id) {
                            productosOrdenados.add(p);
                        }
                    }
                }

                supermercado.modificarStock(productosOrdenados);
                supermercado.recalcularEstanterias();
                break;
            }
        }
        throw new IllegalArgumentException("The supermarket doesn't exists");
    }

    /**
     * Reordena las estanterías de un supermercado usando su algoritmo asignado.
     * @param nombreSuper El nombre del supermercado.
     * @throws ExcepcionTamanyosDistintos si los tamaños de los arrays no coinciden.
     * @throws ExcepcionNoAlgoritmo si no hay un algoritmo asociado.
     */
    public void reordenarEstanteria(String nombreSuper) throws ExcepcionTamanyosDistintos, ExcepcionNoAlgoritmo {
        for(Map.Entry<String,String> algoritmo: AlgoritmoSupers.entrySet()){
            if(algoritmo.getKey().equals(nombreSuper)){
                if (algoritmo.getValue() != null) cambiarAlgoritmo(nombreSuper, algoritmo.getValue());
                else throw new IllegalArgumentException("There is no algorithm selected");
            }
        }
    }

    /**
     * Intercambia dos productos en un supermercado.
     * @param nombreSuper El nombre del supermercado.
     * @param nameProd1 El nombre del primer producto.
     * @param nameProd2 El nombre del segundo producto.
     */
    public void intercambiarProductos(String nombreSuper, String nameProd1, String nameProd2){
        for (Supermercado supermercado : Supermercados){
            if (supermercado.getNombre().equals(nombreSuper)){
                supermercado.intercambiarProductos(nameProd1, nameProd2); // No implementado correctamente aún.
                AlgoritmoSupers.put(nombreSuper, "NoAlgoritmo");
            }
        }
        throw new IllegalArgumentException("The supermarket doesn't exists");
    }

    /**
     * Crea una similitud entre dos productos en un supermercado.
     * @param nombreSuper El nombre del supermercado.
     * @param prod1 El nombre del primer producto.
     * @param prod2 El nombre del segundo producto.
     * @param similitud El valor de la similitud entre los productos.
     */
    public void crearSimilitud(String nombreSuper, String prod1, String prod2, int similitud){
        for (Supermercado supermercado : Supermercados){
            if (supermercado.getNombre().equals(nombreSuper)){
                ArrayList<Producto> stock = supermercado.getStock();
                Producto p1 = null;
                Producto p2 = null;
                for (Producto prod : stock){
                    if (prod.getNombre().equals(prod1)) p1 = prod;
                    if (prod.getNombre().equals(prod2)) p2 = prod;
                }
                if (p1 != null && p2 != null){
                    Productos.crearSimilitud(nombreSuper, prod1, prod2, similitud);
                    Productos.crearSimilitud(nombreSuper, prod2, prod1, similitud);
                }
                else throw new IllegalArgumentException("One or more products doesn't exists");
                break;
            }
        }
        throw new IllegalArgumentException("The supermarket doesn't exists");
    }

    /**
     * Modifica la similitud entre dos productos en un supermercado.
     * @param nombreSuper El nombre del supermercado.
     * @param prod1 El nombre del primer producto.
     * @param prod2 El nombre del segundo producto.
     * @param similitud El nuevo valor de la similitud entre los productos.
     */
    public void modificarSimilitud(String nombreSuper, String prod1, String prod2, int similitud){
        for (Supermercado supermercado : Supermercados){
            if (supermercado.getNombre().equals(nombreSuper)){
                ArrayList<Producto> stock = supermercado.getStock();
                Producto p1 = null;
                Producto p2 = null;
                for (Producto prod : stock){
                    if (prod.getNombre().equals(prod1)) p1 = prod;
                    if (prod.getNombre().equals(prod2)) p2 = prod;
                }
                if (p1 != null && p2 != null){
                    Productos.modificarSimilitud(nombreSuper, prod1, prod2, similitud);
                    Productos.modificarSimilitud(nombreSuper, prod2, prod1, similitud);
                }
                else throw new IllegalArgumentException("One or more products doesn't exists");
                break;
            }
        }
        throw new IllegalArgumentException("The supermarket doesn't exists");
    }

    /**
     * Elimina la similitud entre dos productos en un supermercado.
     * @param nombreSuper El nombre del supermercado.
     * @param prod1 El nombre del primer producto.
     * @param prod2 El nombre del segundo producto.
     */
    public void eliminarSimilitud(String nombreSuper, String prod1, String prod2){
        boolean exists = false;
        for (Supermercado supermercado : Supermercados){
            if (supermercado.getNombre().equals(nombreSuper)){
                exists = true;
                ArrayList<Producto> stock = supermercado.getStock();
                Producto p1 = null;
                Producto p2 = null;
                for (Producto prod : stock){
                    if (prod.getNombre().equals(prod1)) p1 = prod;
                    if (prod.getNombre().equals(prod2)) p2 = prod;
                }
                if (p1 != null && p2 != null){
                    Productos.eliminarSimilitud(nombreSuper, prod1, prod2);
                    Productos.eliminarSimilitud(nombreSuper, prod2, prod1);
                }
                else throw new IllegalArgumentException("The product doesn't exists");
                break;
            }
        }
        if (!exists) throw new IllegalArgumentException("The supermarket doesn't exists");
    }

    /**
     * Modifica un producto existente en un supermercado.
     * @param nombreSuper El nombre del supermercado.
     * @param prod El nombre actual del producto.
     * @param name El nuevo nombre del producto.
     * @param precio El nuevo precio del producto.
     */
    public void modificarProducto(String nombreSuper, String prod, String name, double precio){
        for (Supermercado supermercado : Supermercados){
            if (supermercado.getNombre().equals(nombreSuper)){
                Productos.modificarProducto(prod, name ,precio, nombreSuper);
                break;
            }
        }
    }

    /**
     * Limpia todos los datos del sistema.
     */
    public void limpiarDatos(){
        for (Supermercado supermercado : Supermercados){
            supermercado.limpiarDatos();
        }
        Supermercados = null;
        ultimoId = 0;
        Productos = null;
        AlgoritmoSupers = null;
    }

    // CONSULTORAS

    /**
     * Consulta la información de un supermercado.
     * @param nombreSuper El nombre del supermercado.
     * @return Un ArrayList con la información del supermercado.
     */
    public ArrayList<String> consultarSupermercado(String nombreSuper){
        for (Supermercado s : Supermercados){
            if (s.getNombre().equals(nombreSuper)){
                ArrayList<String> info = new ArrayList<String>();
                info.add(nombreSuper);
                info.add(String.valueOf(s.getFecha()));
                info.add(String.valueOf(s.getN_estanterias()));
                info.add(String.valueOf(s.getStock().size()));
                info.add(String.valueOf(consultarProductos(nombreSuper)));
                return info;
            }
        }
        throw new IllegalArgumentException("The supermarket doesn't exists");
    }

    /**
     * Consulta la información de un producto en un supermercado.
     * @param nombreSuper El nombre del supermercado.
     * @param name El nombre del producto.
     * @return Un ArrayList con la información del producto.
     */
    public ArrayList<String> consultarProducto(String nombreSuper, String name){
        for (Supermercado supermercado : Supermercados){
            if (supermercado.getNombre().equals(nombreSuper)){
                ArrayList<Producto> stock = supermercado.getStock();
                for (Producto prod : stock){
                    if (prod.getNombre().equals(name)){
                        ArrayList<String> info = new ArrayList<String>();
                        info.add(prod.getNombre());
                        info.add(String.valueOf(prod.getPrecio()));
                        return info;
                    }
                }
                throw new IllegalArgumentException("The product doesn't exists");
            }
        }
        throw new IllegalArgumentException("The supermarket doesn't exists");
    }

    /**
     * Consulta todos los productos de un supermercado.
     * @param nombreSuper El nombre del supermercado.
     * @return Un ArrayList con los nombres de los productos.
     */
    public ArrayList<String> consultarProductos(String nombreSuper){
        return consultaStock(nombreSuper);
    }

    /**
     * Verifica si un producto existe en un supermercado dado.
     * @param nombreSuper El nombre del supermercado donde se busca el producto.
     * @param name El nombre del producto a buscar.
     * @return true si el producto existe en el supermercado, false si no.
     * @throws IllegalArgumentException Si el supermercado no existe.
     */
    public boolean existsProducto (String nombreSuper, String name){
        for (Supermercado supermercado : Supermercados){
            if (supermercado.getNombre().equals(nombreSuper)){
                ArrayList<Producto> stock = supermercado.getStock();
                for (Producto prod : stock){
                    if (prod.getNombre().equals(name)) return true;
                }
                return false;
            }
        }
        throw new IllegalArgumentException("The supermarket doesn't exists");
    }

    /**
     * Verifica si un algoritmo es uno de los algoritmos predefinidos.
     * @param name El nombre del algoritmo a verificar.
     * @return true si el algoritmo es "Back Tracking", "Hill Climbing" o "2-Aproximación", false de lo contrario.
     */
    public boolean existsAlgoritmo(String name){
        if (name.equals("Back Tracking") || name.equals("Hill Climbing") || name.equals("2-Aproximación")) return true;
        else return false;
    }

    /**
     * Consulta la similitud entre dos productos en un supermercado.
     * @param nombreSuper El nombre del supermercado.
     * @param prod1 El nombre del primer producto.
     * @param prod2 El nombre del segundo producto.
     * @return El porcentaje de similitud entre los dos productos.
     * @throws IllegalArgumentException Si alguno de los productos no existe en el supermercado.
     */
    public int consultaSimilitudes(String nombreSuper, String prod1, String prod2){
        for (Supermercado supermercado : Supermercados){
            if (supermercado.getNombre().equals(nombreSuper)){
                ArrayList<Producto> stock = supermercado.getStock();
                Producto p1 = null;
                Producto p2 = null;
                for (Producto prod : stock){
                    if (prod.getNombre().equals(prod1)) p1 = prod;
                    if (prod.getNombre().equals(prod2)) p2 = prod;
                }
                if (p1 != null && p2 != null){
                    return Productos.consultarSimilitud(nombreSuper, prod1, prod2);
                }
                else throw new IllegalArgumentException("The product doesn't exists");
            }
        }
        throw new IllegalArgumentException("The supermarket doesn't exists");
    }

    /**
     * Consulta la similitud entre un producto y todos los productos de un supermercado.
     * @param nombreSuper El nombre del supermercado.
     * @param prod El nombre del producto para consultar las similitudes.
     * @return Una lista con los nombres de los productos similares.
     * @throws IllegalArgumentException Si el producto no existe en el supermercado.
     */
    public ArrayList<String> consultaSimilitudes(String nombreSuper, String prod){
        for (Supermercado supermercado : Supermercados){
            if (supermercado.getNombre().equals(nombreSuper)){
                ArrayList<Producto> stock = supermercado.getStock();
                Producto p = null;
                for (Producto prod1 : stock){
                    if (prod1.getNombre().equals(prod)){
                        p = prod1;
                        break;
                    }
                }
                if (p != null){
                    return Productos.consultarSimilitudes(nombreSuper, prod);
                }
                else throw new IllegalArgumentException("The product doesn't exists");
            }
        }
        throw new IllegalArgumentException("The supermarket doesn't exists");
    }

    /**
     * Consulta el stock de un supermercado, obteniendo los nombres y precios de los productos.
     * @param nombreSuper El nombre del supermercado.
     * @return Una lista con los nombres y precios de los productos.
     * @throws IllegalArgumentException Si el supermercado no existe.
     */
    public ArrayList<String> consultaStock(String nombreSuper){

        ArrayList<String> stock = new ArrayList<>();
        for (Supermercado supermercado : Supermercados){
            if (supermercado.getNombre().equals(nombreSuper)){
                ArrayList<Producto> infoSuper = supermercado.getStock();
                for (Producto prod : infoSuper){
                    if (prod != null) {
                        stock.add(prod.getNombre());
                        stock.add(String.valueOf(prod.getPrecio()));
                    }
                }
                return stock;
            }
        }
        throw new IllegalArgumentException("The supermarket doesn't exists");
    }

    /**
     * Obtiene una lista de los nombres de todos los supermercados registrados.
     * @return Una lista con los nombres de los supermercados.
     */
    public ArrayList<String> getNombres(){
        ArrayList<String> nombres = new ArrayList<>();
        for (Supermercado supermercado : Supermercados){
            nombres.add(supermercado.getNombre());
        }
        return nombres;
    }

    /**
     * Obtiene una lista de los identificadores de los productos en un supermercado.
     * @param nombreSuper El nombre del supermercado.
     * @return Una lista con los identificadores de los productos.
     * @throws IllegalArgumentException Si el supermercado no existe.
     */
    public ArrayList<Integer> getIdentificadores(String nombreSuper){
        for (Supermercado supermercado : Supermercados){
            if (supermercado.getNombre().equals(nombreSuper)){
                return supermercado.getIdentificadores();
            }
        }
        throw new IllegalArgumentException("The supermarket doesn't exists");
    }

    /**
     * Devuelve una matriz de similitudes entre productos en un supermercado.
     * @param nombreSuper El nombre del supermercado.
     * @param identificadores Una lista con los identificadores de los productos.
     * @return Una matriz de similitudes entre los productos especificados.
     * @throws IllegalArgumentException Si el supermercado no existe.
     */
    public ArrayList<ArrayList<Integer>> getSimilitudes(String nombreSuper, ArrayList<Integer> identificadores){


        for (Supermercado supermercado : Supermercados){
            if (supermercado.getNombre().equals(nombreSuper)){
                ArrayList<ArrayList<Integer>> similitudes = new ArrayList<ArrayList<Integer>>();

                // Crear una matriz nxn inicializada a 0
                for (int i = 0; i < identificadores.size(); i++) {
                    ArrayList<Integer> fila = new ArrayList<>();
                    for (int j = 0; j < identificadores.size(); j++) {
                        fila.add(0);
                    }
                    similitudes.add(fila);
                }
                ArrayList<Producto> stock = supermercado.getStock();

                for (int i = 0; i < identificadores.size(); i++){
                    Producto p1 = null;
                    Producto p2 = null;
                    for (Producto p : stock){
                        if (p.getId() == identificadores.get(i)){
                            p1 = p;
                            break;
                        }
                    }
                    for (int j = i + 1; j < identificadores.size(); j++){
                        for (Producto p : stock){
                            if (p.getId() == identificadores.get(j)){
                                p2 = p;
                                break;
                            }
                        }
                        if (supermercado.existSimilitud(p1, p2)){
                            //Integer similitud = Productos.consultarSimilitud(p1, p2);
                            Integer similitud = p1.consultarSimilitud(p2).getProcentaje_similitud(); //De moment faig això, crea acomplament
                            similitudes.get(i).set(j, similitud);
                            similitudes.get(j).set(i, similitud);
                        }
                    }
                }
                return similitudes;
            }
        }
        throw new IllegalArgumentException("The supermarket doesn't exists");
    }

    /**
     * Consulta la distribución de los productos en un supermercado.
     * @param nombreSuper El nombre del supermercado.
     * @return Una lista que describe cómo están distribuidos los productos en el supermercado.
     * @throws IllegalArgumentException Si el supermercado no existe.
     */
    public ArrayList<String> consultarDistribucion(String nombreSuper) {
        for (Supermercado supermercado : Supermercados){
            if (supermercado.getNombre().equals(nombreSuper)){
                return supermercado.consultarSupermercado();
            }
        }
        throw new IllegalArgumentException("The supermarket doesn't exists");
    }

    /**
     * Obtiene los datos relevantes de los supermercados, incluyendo el nombre, fecha,
     * número de estanterías y distribución.
     * @param usuario El nombre del usuario que consulta los datos.
     * @return Una lista de mapas con los datos de cada supermercado.
     */
    public ArrayList<Map<String, Object>> getDatosSuper(String usuario){
        ArrayList<Map<String, Object>> datos = new ArrayList<>();
        for(int i = 0; i < Supermercados.size(); i++){
            Map<String, Object> datosSupermercado = new LinkedHashMap<>();
            datosSupermercado.put("Nombre", Supermercados.get(i).getNombre());
            datosSupermercado.put("Fecha", Supermercados.get(i).getFecha());
            datosSupermercado.put("Numero Estanterías", Supermercados.get(i).getN_estanterias());
            ArrayList<ArrayList<Integer>> dist_aux = new ArrayList<>();
            ArrayList<Estanteria> dist = Supermercados.get(i).getDistribucionActual();
            //aqui hay error
            if (dist != null){
                for(int j = 0; j < dist.size(); ++j){
                    ArrayList<Integer> aux = new ArrayList<>();
                    ArrayList<Producto> est = dist.get(j).consultarEstanterias();
                    for(int k = 0; k < est.size(); ++k){
                        aux.add(est.get(k).getId());
                    }
                    dist_aux.add(aux);
                }
            } else dist = new ArrayList<>();

            datosSupermercado.put("Distribución", dist_aux);
            ArrayList<Integer> stock_aux = new ArrayList<>();
            ArrayList<Producto> stock = Supermercados.get(i).getStock();
            for(int j = 0; j < stock.size(); ++j){
                stock_aux.add(stock.get(j).getId());
            }
            datosSupermercado.put("Stock", stock_aux);
            datosSupermercado.put("Pertenece al Usuario", usuario);
            datosSupermercado.put("Algoritmo Utilizado", AlgoritmoSupers.get(Supermercados.get(i).getNombre()));
            datos.add(datosSupermercado);
        }
        return datos;
    }

    /**
     * Obtiene los datos de los productos en cada supermercado, agrupados por supermercado.
     * @param nameUser El nombre del usuario que consulta los datos.
     * @return Un mapa donde la clave es el nombre del supermercado y el valor es una lista de mapas con los datos de los productos.
     */
    public Map<String, ArrayList<Map<String, Object>>> getDatosSuperProd(String nameUser){
        Map<String, ArrayList<Map<String, Object>>> datosProductosSuper = new HashMap<>();
        for (Supermercado supermercado : Supermercados){
            ArrayList<Map<String, Object>> datosProductos = Productos.getDatosSuperProd(supermercado.getNombre(), nameUser);
            datosProductosSuper.put(supermercado.getNombre(), datosProductos);
        }

        return datosProductosSuper;
    }

    /**
     * Devuelve una lista con los nombres de todos los supermercados registrados.
     * @return Una lista con los nombres de los supermercados.
     */
    public ArrayList<String> getSupers(){
        ArrayList<String> supers = new ArrayList<>();
        for(int i = 0; i < Supermercados.size(); i++){
            supers.add(Supermercados.get(i).getNombre());
        }
        return supers;
    }

    /**
     * Obtiene los nombres de todos los supermercados registrados.
     * @return Una lista de los nombres de los supermercados.
     */
    public ArrayList<String> getNombresSuper() {
        ArrayList<String> nombres = new ArrayList<>();
        for (Supermercado supermercado : Supermercados){
            nombres.add(supermercado.getNombre());
        }
        return nombres;
    }

    /**
     * Duplica un supermercado con un nuevo nombre.
     * @param viejo El nombre del supermercado a duplicar.
     * @param nuevo El nombre del nuevo supermercado.
     * @throws IllegalArgumentException Si ya existe un supermercado con el nuevo nombre.
     */
    public void duplicarSupermercado(String viejo, String nuevo) {
        if(AlgoritmoSupers.get(nuevo) != null) throw new IllegalArgumentException("There is a super with this name");
        for (int i = 0; i < Supermercados.size(); i++) {
            if (Supermercados.get(i).getNombre().equals(viejo)) {
                Supermercado n = new Supermercado(nuevo, Supermercados.get(i).getN_estanterias());
                ArrayList<Producto> prods = Supermercados.get(i).getStock();
                for(int j = 0; j < prods.size(); ++j){
                    Productos.agregarProducto(nuevo, prods.get(j).getNombre(), ultimoId, prods.get(j).getPrecio());
                    Producto p = Productos.getProducto(nuevo, prods.get(j).getNombre());
                    n.agregarProducto(p);
                    ultimoId += 1;
                }
                for(int j = 0; j < prods.size(); ++j){
                    Producto p = Productos.getProducto(nuevo, prods.get(j).getNombre());
                    Producto original = Productos.getProducto(viejo, prods.get(j).getNombre());
                    ArrayList<Similitud> sims = original.getSimilitudes();
                    for(int k = 0; k < sims.size(); ++k){
                        Producto similar = Productos.getProducto(nuevo,sims.get(k).getProducto().getNombre());
                        p.anadirSimilitud(similar, sims.get(k).getProcentaje_similitud());
                    }
                }
                String algoritmo = AlgoritmoSupers.get(viejo);
                AlgoritmoSupers.put(nuevo, algoritmo);
                Supermercados.add(n);
                break;
            }
        }
    }

    /**
     * Elimina un supermercado registrado por su nombre.
     * @param supermercado El nombre del supermercado a eliminar.
     */
    public void eliminarSupermercado(String supermercado) {
        if (supermercado != null) {
            for (int i = 0; i < Supermercados.size(); i++) {
                if (Supermercados.get(i).getNombre().equals(supermercado)) {
                    Supermercados.remove(i);
                    break;
                }
            }
            AlgoritmoSupers.remove(supermercado);
        }
    }

    /**
     * Guarda los datos de los supermercados y productos en las estructuras correspondientes.
     * @param supermercadoMap La lista de datos de los supermercados.
     * @param PorductoMap El mapa con los datos de los productos.
     */
    public void guardarDatos(ArrayList<Map<String, Object>> supermercadoMap, Map<String, Map<Integer, Map<String, Object>>> PorductoMap) {

        for (int i = 0; i < supermercadoMap.size(); i++) {
            String nombreSuper = (String) supermercadoMap.get(i).get("Nombre");
            String nombreAlgoritmo = (String) supermercadoMap.get(i).get("Algoritmo Utilizado");
            Integer n_estanterias = ((Integer) supermercadoMap.get(i).get("Numero Estanterías")).intValue();
            AlgoritmoSupers.put(nombreSuper, nombreAlgoritmo);

            Supermercado nuevo = new Supermercado(nombreSuper, n_estanterias);
            Map<Integer, Map<String, Object>> prodsSuper = PorductoMap.get(nombreSuper);
            ArrayList<Integer> auxStock = (ArrayList<Integer>) supermercadoMap.get(i).get("Stock");
            for(int j = 0; j < auxStock.size(); ++j){
                String nombreProd = (String) prodsSuper.get(auxStock.get(j)).get("Nombre");
                double precioProd = (double) prodsSuper.get(auxStock.get(j)).get("Precio");
                int idProd = (int) prodsSuper.get(auxStock.get(j)).get("IdProducto");
                if (!Productos.existsProducto(nombreSuper, nombreProd)) {
                    Productos.agregarProducto(nombreSuper, nombreProd, idProd, precioProd);
                    Producto p = Productos.getProducto(nombreSuper, nombreProd);
                    nuevo.agregarProducto(p);
                }
            }
            for(int j = 0; j < auxStock.size(); ++j){
                String nombreProd = (String) prodsSuper.get(auxStock.get(j)).get("Nombre");
                if(Productos.existsProducto(nombreSuper, nombreProd)){
                    ArrayList<ArrayList<Integer>> sims = (ArrayList<ArrayList<Integer>>) prodsSuper.get(auxStock.get(j)).get("Similitudes");
                    for(int k = 0; k < sims.size(); ++k){
                        Producto p1 = Productos.getProducto(nombreSuper, nombreProd);
                        Producto p2 = Productos.getProducto(nombreSuper, sims.get(k).get(1));
                        p1.anadirSimilitud(p2, sims.get(k).get(0));
                    }
                }
            }

            int max = 0;
            for (int j = 0; j < auxStock.size(); ++j) {
                if (auxStock.get(j) > max) max = auxStock.get(j);
            }
            ultimoId = max + 1;
            Supermercados.add(nuevo);
        }
    }

    /**
     * Obtiene el algoritmo utilizado por un supermercado específico.
     * @param supermercado El nombre del supermercado.
     * @return El nombre del algoritmo utilizado por el supermercado.
     */
    public String getAlgoritmo(String supermercado){
        for(Map.Entry<String,String> algoritmo: AlgoritmoSupers.entrySet()) {
            if (algoritmo.getKey().equals(supermercado)) {
                return algoritmo.getValue();
            }
        }
        return null;
    }

    /**
     * Verifica si un supermercado existe en el sistema.
     * @param supermercado El nombre del supermercado.
     * @return true si el supermercado existe, false si no.
     */
    public boolean existsSupermercado(String supermercado){
        for(Map.Entry<String,String> algoritmo: AlgoritmoSupers.entrySet()) {
            if(AlgoritmoSupers.get(supermercado) != null) return true;
        }
        return false;
    }
}