package src.main.domain.controllers;

import java.util.*;
import src.main.domain.classes.Diccionario;

/**
 * El controlador de Diccionario gestiona todo el envio de datos para el controlador de dominio
 * @author Andres Lucian Laptes Costan (andres.lucian.laptes@estudiantat.upc.edu)
 * */
public class CtrlDiccionario {
    Diccionario diccionarioActual;
    ArrayList<String> IdiomasDisponibles;

    /**
     * Constructora del controlador de dicionario. Inicializa un nuevo diccionario y los idiomas disponibles.
     */
    public CtrlDiccionario() {
        diccionarioActual = new Diccionario();
        IdiomasDisponibles = diccionarioActual.getIdiomasDisponibles();
    }

    /**
     * Conuslta los idiomas disponibles.
     * @return Lista con todos los idiomas de los que dispone el programa.
     */
    public ArrayList<String> getIdiomasDisponibles() {
        return IdiomasDisponibles;
    }

    /**
     * Conuslta todas las frases de un idioma.
     * @param Idioma El idioma sobre el que queremos consultar las frases.
     * @return Lista con todas las frases de los que dispone un idioma del programa.
     */
    public Map<Integer, String> getFrases(String Idioma) {
        if (!IdiomasDisponibles.contains(Idioma)) throw new IllegalArgumentException("Language " + Idioma + " not exists");
        return diccionarioActual.getFrases();
    }

    /**
     * Conuslta una frase del dicionario de un idioma.
     * @param Idioma El idioma sobre el que queremos consultar la frase.
     * @param id El identificador que indica la frase especifica que queremos consultar.
     * @return Lista con todos los idiomas de los que dispone el programa.
     */
    public String getFrase(String Idioma, int id) {
        if (!IdiomasDisponibles.contains(Idioma)) throw new IllegalArgumentException("Language " + Idioma + " not exists");
        return diccionarioActual.getFrase(id);
    }

    /**
     * Seleciona el idioma actual que vamos a usar.
     * @param Idioma El idioma en el que queremos ver el programa.
     * @param idioma El mapa que contiene las frases.
     */
    public void setIdioma(String Idioma, Map<Integer, String> idioma) {
        diccionarioActual.setIdioma(Idioma,idioma);
    }
}
