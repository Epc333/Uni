package src.main.domain.classes.exceptions;

public class ExcepcionNoAlgoritmo extends Exception {

    public ExcepcionNoAlgoritmo() {
        super("The selected algorithm does not exist");
    }
}