package src.main.domain.classes.exceptions;

/**
 * Esta classe gestiona las excepciones generadas
 * al pasar una contraseña con una longitud menor de 12.
 * @author Andres Lucian Laptes Costan (andres.lucian.laptes@estudiantat.upc.edu)
 */
public class SizePasswordException extends Exception {
    private int size;

    public SizePasswordException(int tam) {
        super("Password Error! -> Your password has " + tam + " and the minimum length is 12");
        size = tam;
    }

    public String to_string() {
        return "Password Error! -> Your password has " + size + " and the minimum length is 12";
    }
}