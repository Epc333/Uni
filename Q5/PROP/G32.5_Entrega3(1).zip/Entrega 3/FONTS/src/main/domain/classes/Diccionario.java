package src.main.domain.classes;

import java.util.*;

/**
 * Esta clase representa un diccionario, que contiene frases en diferentes idiomas.
 * El sistema soporta la selección de un idioma actual y el almacenamiento de frases con un identificador
 * único por idioma.
 *
 * @author Andres Lucian Laptes Costan (andres.lucian.laptes@estudiantat.upc.edu)
 */
public class Diccionario {
    /**
     * Mapa que contiene el diccionario de frases, donde la clave es un identificador (id) y el valor es una frase.
     */
    private Map<Integer, String> diccionario;

    /** Variable que almacena el nombre del idioma actual del diccionario. */
    private String IdiomaActual;

    /**
     * Constructor por defecto.
     */
    public Diccionario() {
        diccionario = new HashMap<>();
    }

    /**
     * Establece el idioma actual y actualiza el mapa de frases (diccionario) para ese idioma.
     * Se recibe un mapa de frases como parámetro, donde las claves son los identificadores
     * y los valores las frases correspondientes.
     * @param Idioma  El nombre del idioma actual.
     * @param diccionario El mapa que contiene las frases.
     */
    public void setIdioma(String Idioma, Map<Integer, String> diccionario) {
        this.diccionario = new HashMap<>();
        for (Map.Entry<Integer, String> entry : diccionario.entrySet()) {
            int id = Integer.parseInt(entry.getKey().toString());
            this.diccionario.put(id, entry.getValue());
        }
        IdiomaActual = Idioma;
    }

    /**
     * Devuelve una lista con los idiomas disponibles que el sistema soporta actualmente.
     * @return Una lista con los nombres de los idiomas disponibles.
     */
    public ArrayList<String> getIdiomasDisponibles() {
        ArrayList<String> Idiomas = new ArrayList<>();
        Idiomas.add("Castellano");
        Idiomas.add("Catalan");
        Idiomas.add("Ingles");
        Idiomas.add("Rumano");
        return Idiomas;
    }

    /**
     * Devuelve el mapa actual de frases almacenadas en el diccionario.
     * @return Un mapa con las frases del idioma actual.
     */
    public Map<Integer, String> getFrases() {
        return diccionario;
    }

    /**
     * Devuelve la frase asociada a un identificador.
     * @param id El identificador de la frase a buscar.
     * @return La frase asociada al identificador.
     * @throws IllegalArgumentException Si no existe una frase con el identificador especificado.
     */
    public String getFrase(int id) {
        if (!diccionario.containsKey(id))
            throw new IllegalArgumentException("No existe una frase con el id: " + id);
        return diccionario.get(id);
    }

    /**
     * Devuelve el idioma actual del diccionario.
     * @return El nombre del idioma actual como String.
     */
    public String getIdiomaActual() {
        return IdiomaActual;
    }
}
