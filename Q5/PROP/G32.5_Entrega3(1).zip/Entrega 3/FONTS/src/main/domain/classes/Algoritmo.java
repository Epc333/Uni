package src.main.domain.classes;
import java.util.ArrayList;

/**
 * Algoritmo es una superclase abstracta para los tres algoritmos de ordenación de productos.
 * @author Asier García Elvira (asier.garcia@estudiantat.upc.edu)
 */

public abstract class Algoritmo {
    /**
     * Método abstracto que debe implementarse en las subclases para definir un algoritmo de ordenamiento
     */

    /** Busca la solucion de un supermercado aplicando un algoritmo
     * @param similitudes contiene todas las similitudes de todos los prodcutos
     * @param posiciones Contiene la posicion actual de cada producto en el supermercado
     * */
    public abstract ArrayList<Integer> buscarSolucion(ArrayList<ArrayList<Integer>> similitudes, ArrayList<Integer> posiciones);

}