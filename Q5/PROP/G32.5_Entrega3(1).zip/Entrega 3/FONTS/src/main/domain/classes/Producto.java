package src.main.domain.classes;

import java.util.ArrayList;

/**
 * Esta clase representa un producto y contiene métodos para administrarlo.
 * @author Vinyet Granda Planas (vinyet.granda@estudiantat.upc.edu)
 */
public class Producto {

    /** Identificador único del producto*/
    private int id;

    /** Nombre del producto */
    private String nombre;

    /** Precio del producto*/
    private double precio;

    /** Lista de similitudes del producto con otros productos*/
    private ArrayList<Similitud> similitudes;

    /**
     * Constructora de copia. Crea una copia del producto especificado.
     * @param a Producto del cual se realizará la copia.
     */
    public Producto(Producto a) {
        id = a.id;
        precio = a.precio;
        nombre = a.nombre;

        ArrayList<Similitud> similitudes1 = new ArrayList<>();
        for (int i = 0; i < a.getSimilitudes().size(); i++) {
            similitudes1.add(new Similitud(a.getSimilitudes().get(i)));
        }
        this.similitudes = similitudes1;
    }

    /**
     * Constructora que inicializa un producto con un id, nombre y precio específicos.
     * @param id Identificador único del producto.
     * @param nombre Nombre del producto.
     * @param precio Precio del producto.
     */
    public Producto(int id, String nombre, double precio) {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
        this.similitudes = new ArrayList<Similitud>();
    }

    /**
     * Devuelve el nombre del producto.
     * @return El nombre del producto.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Devuelve el precio del producto.
     * @return El precio del producto.
     */
    public double getPrecio() {
        return precio;
    }

    /**
     * Devuelve el identificador del producto.
     * @return El identificador del producto.
     */
    public int getId() {
        return id;
    }

    /**
     * Devuelve la lista de similitudes del producto con otros productos.
     * @return Una lista de similitudes del producto.
     */
    public ArrayList<Similitud> getSimilitudes() {
        return similitudes;
    }

    // Modificadoras

    /**
     * Modifica el nombre del producto.
     * @param name El nuevo nombre del producto.
     */
    public void modificarNombre(String name) {
        this.nombre = name;
    }

    /**
     * Modifica el precio del producto.
     * @param precio El nuevo precio del producto.
     */
    public void modificarPrecio(double precio) {
        this.precio = precio;
    }

    /**
     * Limpia todos los datos de similitudes del producto.
     */
    public void limpiarDatos() {
        similitudes.clear();
    }

    /**
     * Añade una nueva similitud entre este producto y otro producto.
     * @param prod El producto con el que se establece la similitud.
     * @param similitud El valor de la similitud (ej: un valor numérico que represente la cercanía entre productos).
     */
    public void anadirSimilitud(Producto prod, int similitud) {
        Similitud sim = new Similitud(prod, similitud);
        similitudes.add(sim);
    }

    /**
     * Elimina una similitud existente entre este producto y otro producto.
     * @param prod El producto cuya similitud será eliminada.
     */
    public void eliminaSimilitud(Producto prod) {
        for (int i = 0; i < similitudes.size(); i++) {
            if (similitudes.get(i).getProducto() == prod) {
                similitudes.remove(i);
            }
        }
    }

    /**
     * Verifica si existe una similitud entre este producto y otro producto.
     * @param prod El producto a verificar.
     * @return true si existe una similitud, false en caso contrario.
     */
    public boolean existSimilitud(Producto prod) {
        return consultarSimilitud(prod) != null;
    }

    /**
     * Modifica el valor de una similitud existente entre este producto y otro producto.
     * @param prod El producto con el que se desea modificar la similitud.
     * @param similitud El nuevo valor de la similitud.
     */
    public void modificarSimilitud(Producto prod, int similitud) {
        for (int i = 0; i < similitudes.size(); i++) {
            if (similitudes.get(i).getProducto() == prod) {
                similitudes.get(i).modificarSimilitud(similitud);
            }
        }
    }

    /**
     * Consulta la similitud entre este producto y otro producto.
     * @param prod El producto con el que se desea consultar la similitud.
     * @return La similitud entre los productos, o null si no existe.
     */
    public Similitud consultarSimilitud(Producto prod) {
        for (int i = 0; i < similitudes.size(); i++) {
            if (similitudes.get(i).getProducto() == prod) {
                return similitudes.get(i);
            }
        }
        return null;
    }
}

