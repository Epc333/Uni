package src.main.domain.controllers;

import java.util.*;
import src.main.domain.classes.Usuario;
import src.main.domain.classes.exceptions.ExcepcionNoAlgoritmo;
import src.main.domain.classes.exceptions.ExcepcionTamanyosDistintos;
import src.main.domain.classes.exceptions.SizePasswordException;

/**
 * El controlador de Usuario se encarga de gestionar el Usuario y gestiona los diversos metodos relacionados con un Usuario.
 * Controlador que gestiona las operaciones relacionadas con usuarios del sistema.
 * Maneja la creación, modificación y eliminación de perfiles de usuario,
 * así como la gestión de supermercados y productos asociados.
 * @author Andres Lucian Laptes Costan (andres.lucian.laptes@estudiantat.upc.edu)
 */
public class CtrlUsuario {
    private Usuario UsuarioActual;
    private ArrayList<String> IdiomasDisponibles;
    private CtrlSupermercado ctrlSupermercado;

    /**
     * Constructor por defecto que inicializa un nuevo controlador de usuario.
     * Crea una lista de idiomas disponibles y establece el usuario actual como null.
     */
    public CtrlUsuario() {
        ctrlSupermercado = new CtrlSupermercado();
        IdiomasDisponibles = new ArrayList<>();
        IdiomasDisponibles.add("Castellano");
        IdiomasDisponibles.add("Catalan");
        IdiomasDisponibles.add("Ingles");
        IdiomasDisponibles.add("Rumano");
        UsuarioActual = null;
    }


    /**
     * Configura un nuevo perfil de usuario con los datos proporcionados.
     *
     * @param name      Nombre de usuario
     * @param password  Contraseña del usuario (debe ser mayor a 12 caracteres)
     * @param idioma    Idioma seleccionado para el usuario
     * @param mail      Correo electrónico del usuario
     * @param disponibles Lista de idiomas disponibles en el sistema
     * @throws SizePasswordException Si la contraseña tiene 12 o menos caracteres
     * @throws IllegalArgumentException Si el idioma especificado no está en la lista de disponibles
     */
    public void crearPerfil(String name, String password, String idioma, String mail, ArrayList<String> disponibles) throws SizePasswordException {
        if (password.length() <= 12) throw new SizePasswordException(password.length());

        boolean validLanguage = false;
        IdiomasDisponibles = disponibles;
        int end = IdiomasDisponibles.size();
        for (int i = 0;  !validLanguage && i < end; ++i) {
            if (IdiomasDisponibles.get(i).equals(idioma)) validLanguage = true;
        }
        if (!validLanguage) throw new IllegalArgumentException("Invalid Language: " + idioma);


        UsuarioActual = new Usuario(name, password, mail, idioma);
    }

    /**
     * Obtiene los datos del usuario actual.
     *
     * @return Lista con los datos del usuario en el siguiente orden:
     *         nombre, contraseña, email, idioma y lista de supermercados asociados
     */
    public ArrayList<String> getDatos() {
        ArrayList<String> datos = new ArrayList<>();
        datos.add("Nombre");
        datos.add(UsuarioActual.getName());
        datos.add("Password");
        datos.add(UsuarioActual.getContraseña());
        datos.add("Email");
        datos.add(UsuarioActual.getEmail());
        datos.add("Idioma");
        datos.add(UsuarioActual.getIdiomaActual());
        datos.add("Supermercados");
        ArrayList<String> nombreSupers = ctrlSupermercado.getNombresSuper();
        for (int i = 0; i < nombreSupers.size(); ++i) {
            datos.add(nombreSupers.get(i));
        }

        return datos;
    }

    /**
     * Modifica los datos del perfil del usuario actual.
     * Si no se desea modificar algún campo, se debe pasar null como parámetro.
     *
     * @param name     Nuevo nombre de usuario o null
     * @param password Nueva contraseña o null
     * @param idioma   Nuevo idioma o null
     * @param mail     Nuevo email o null
     * @throws SizePasswordException Si la nueva contraseña tiene 12 o menos caracteres
     * @throws IllegalArgumentException Si el idioma no es válido o si existe un supermercado con el nuevo nombre
     */
    public void modificarPerfil(String name, String password, String idioma, String mail) throws SizePasswordException { //done
        if (name != null) {
            if(!ctrlSupermercado.existsAlgoritmo(name)) this.UsuarioActual.modificarNombre(name);
            else throw new IllegalArgumentException("There is a super with this name");
        }

        if (password != null) {
            if (password.length() <= 12) throw new SizePasswordException(password.length());
            this.UsuarioActual.modificarContraseña(password);
        }

        if (idioma != null) {
            boolean validLanguage = false;
            int end = IdiomasDisponibles.size();
            for (int i = 0;  !validLanguage && i < end; ++i) {
                if (IdiomasDisponibles.get(i).equals(idioma)) validLanguage = true;
            }

            if (!validLanguage) throw new IllegalArgumentException("Invalid Language: " + idioma);
            this.UsuarioActual.modificarIdioma(idioma);
        }

        if (mail != null) this.UsuarioActual.modificarEmail(mail);
    }


    /**
     * Cambia el idioma del usuario actual.
     * @param idioma Nuevo idioma a establecer
     * @throws IllegalArgumentException Si el idioma especificado no está disponible
     */
    public void seleccionaIdioma(String idioma) {
        boolean validLanguage = true;
        int end = IdiomasDisponibles.size();
        for (int i = 0;  validLanguage && i < end; ++i) {
            if (IdiomasDisponibles.get(i).equals(idioma)) validLanguage = false;
        }

        if (!validLanguage) throw new IllegalArgumentException("Invalid Language: " + idioma);
        this.UsuarioActual.modificarIdioma(idioma);
    }

    /**
     * Elimina el perfil del usuario actual y limpia todos los datos asociados.
     */
    public void eliminarPerfil() {
        IdiomasDisponibles.clear();
        IdiomasDisponibles = null;
        UsuarioActual = null;
        ctrlSupermercado.limpiarDatos();
        ctrlSupermercado = null;
    }

    /**
     * Genera un nuevo supermercado.
     *
     * @param name Nombre del nuevo supermercado
     * @param numero_estante Número de estanterías del supermercado
     * @throws ExcepcionNoAlgoritmo Si no se puede asignar un algoritmo al supermercado
     */
    public void generarSupermercado(String name, int numero_estante) throws ExcepcionNoAlgoritmo {
        ctrlSupermercado.generarSuper(name, numero_estante);
    }

    /**
     * Consulta los datos de un supermercado específico.
     *
     * @param supermercado Nombre del supermercado a consultar
     * @return Lista con el nombre del supermercado, número de estanterías y número total de productos
     */
    public ArrayList<String> consultarSupermercado(String supermercado) {
        return ctrlSupermercado.consultarSupermercado(supermercado);
    }

    /**
     * Modifica el nombre de un supermercado existente.
     *
     * @param supermercado Nombre actual del supermercado
     * @param supermercado2 Nuevo nombre para el supermercado
     */
    public void modificarNombreSupermercado(String supermercado, String supermercado2) {
        ctrlSupermercado.modificarNombre(supermercado, supermercado2);
    }

    /**
     * Elimina todos los supermercados del sistema.
     */
    public void borrarSupermercados() {
        ctrlSupermercado.limpiarDatos();
        ctrlSupermercado = null;
    }

    /**
     * Elimina un supermercado específico.
     *
     * @param supermercado Nombre del supermercado a eliminar
     */
    public void eliminarSupermercado(String supermercado) {
        ctrlSupermercado.eliminarSupermercado(supermercado);
    }

    /**
     * Duplica un supermercado existente con un nuevo nombre.
     *
     * @param name Nombre del supermercado a duplicar
     * @param nuevo Nombre para el nuevo supermercado
     * @throws ExcepcionNoAlgoritmo Si no se puede asignar un algoritmo al nuevo supermercado
     */
    public void duplicarSupermercado(String name, String nuevo) throws ExcepcionNoAlgoritmo { //aqui
        ctrlSupermercado.duplicarSupermercado(name, nuevo);
    }


    /**
     * Añade un nuevo producto a un supermercado.
     *
     * @param supermercado Nombre del supermercado
     * @param nameP Nombre del nuevo producto
     * @param precio Precio del producto
     * @throws IllegalArgumentException Si el producto ya existe o el precio es inválido
     */
    public void anadirProducto(String supermercado, String nameP, double precio) {
        boolean cond = ctrlSupermercado.existsProducto(supermercado, nameP);
        if (cond) throw new IllegalArgumentException("Product already exists");
        if (precio <= 0) throw new IllegalArgumentException("Invalid price");

        ctrlSupermercado.agregarProducto(supermercado, nameP, precio);
    }

    /**
     * Modifica un producto existente en un supermercado.
     *
     * @param supermercado Nombre del supermercado
     * @param name Nombre actual del producto
     * @param nameP Nuevo nombre del producto
     * @param precio Nuevo precio del producto
     * @throws IllegalArgumentException Si el nuevo nombre ya existe o el precio es inválido
     */
    public void modificarProducto(String supermercado, String name ,String nameP, double precio) { //di
        boolean cond = false;
        if(!name.equals(nameP)) cond = ctrlSupermercado.existsProducto(supermercado, nameP);
        if (cond) throw new IllegalArgumentException("Product already exists");
        if (precio <= 0) throw new IllegalArgumentException("Invalid price");

        ctrlSupermercado.modificarProducto(supermercado, name, nameP, precio);
    }

    /**
     * Elimina un producto de un supermercado.
     *
     * @param supermercado Nombre del supermercado
     * @param nameP Nombre del producto a eliminar
     * @throws IllegalArgumentException Si el producto no existe
     */
    public void eliminarProducto(String supermercado, String nameP) {
        boolean cond = ctrlSupermercado.existsProducto(supermercado, nameP);
        if (!cond)
            new IllegalArgumentException("Product with name " + nameP + " not exists");

        ctrlSupermercado.eliminarProducto(supermercado, nameP);
    }

    /**
     * Cambia el algoritmo de ordenación de un supermercado.
     *
     * @param supermercado Nombre del supermercado
     * @param Algoritmo Nombre del nuevo algoritmo
     * @throws ExcepcionTamanyosDistintos Si hay incompatibilidad de tamaños
     * @throws ExcepcionNoAlgoritmo Si el algoritmo no es válido
     */
    public void cambiarAlgoritmo(String supermercado, String Algoritmo) throws ExcepcionTamanyosDistintos, ExcepcionNoAlgoritmo {
        boolean cond = ctrlSupermercado.existsAlgoritmo(Algoritmo);
        if(!cond) throw new IllegalArgumentException("Algoritm with name " + Algoritmo + " invalid");

        ctrlSupermercado.cambiarAlgoritmo(supermercado, Algoritmo);
    }

    /**
     * Intercambia la posición de dos productos en un supermercado.
     *
     * @param supermercado Nombre del supermercado
     * @param Producto1 Nombre del primer producto
     * @param Producto2 Nombre del segundo producto
     * @throws IllegalArgumentException Si alguno de los productos no existe
     */
    public void intercambiarProductos(String supermercado, String Producto1, String Producto2) {
        boolean cond = ctrlSupermercado.existsProducto(supermercado, Producto1);
        if(!cond) throw new IllegalArgumentException("Product with name" + Producto1 + "not exists");
        cond = ctrlSupermercado.existsProducto(supermercado, Producto2);
        if (!cond) throw new IllegalArgumentException("Product with name" + Producto2 + "not exists");

        ctrlSupermercado.intercambiarProductos(supermercado, Producto1, Producto2);
    }

    /**
     * Consulta el stock completo de un supermercado.
     *
     * @param supermercado Nombre del supermercado
     * @return Lista con los datos de todos los productos
     */
    public ArrayList<String> consultaStock(String supermercado) {
        return ctrlSupermercado.consultaStock(supermercado);
    }

    /**
     * Consulta los datos de un producto específico.
     *
     * @param supermercado Nombre del supermercado
     * @param producto Nombre del producto
     * @return Lista con los datos del producto
     * @throws IllegalArgumentException Si el producto no existe
     */
    public ArrayList<String> consultaProducto(String supermercado, String producto) {
        boolean cond = ctrlSupermercado.existsProducto(supermercado, producto);
        if (!cond) throw new IllegalArgumentException("Product with name" + producto + "not exists");
        return ctrlSupermercado.consultarProducto(supermercado, producto);
    }


    /**
     * Crea una relación de similitud entre dos productos.
     *
     * @param supermercado Nombre del supermercado
     * @param prod1 Nombre del primer producto
     * @param prod2 Nombre del segundo producto
     * @param similitud Porcentaje de similitud entre los productos
     * @throws IllegalArgumentException Si algún producto no existe o el valor de similitud es inválido
     */
    public void crearSimilitud(String supermercado, String prod1, String prod2, int similitud) {
        if (!ctrlSupermercado.existsProducto(supermercado, prod1)) throw new IllegalArgumentException("Product with invalid name: " + prod1);
        if (!ctrlSupermercado.existsProducto(supermercado, prod2)) throw new IllegalArgumentException("Product with invalid name: " + prod2);
        if (similitud < 0) throw new IllegalArgumentException("Invalid value of similarity: ");

        ctrlSupermercado.crearSimilitud(supermercado, prod1, prod2, similitud);
    }

    /**
     * Modifica una similitud existente entre dos productos.
     *
     * @param supermercado Nombre del supermercado
     * @param producuto1 Nombre del primer producto
     * @param producuto2 Nombre del segundo producto
     * @param similitud Nuevo porcentaje de similitud
     * @throws IllegalArgumentException Si algún producto no existe o el valor de similitud es inválido
     */
    public void modificarSimilitud(String supermercado,String producuto1, String producuto2, int similitud) {
        boolean cond = ctrlSupermercado.existsProducto(supermercado, producuto1);
        if (!cond) throw new IllegalArgumentException("Product with invalid name: " + producuto1);
        cond = ctrlSupermercado.existsProducto(supermercado, producuto2);
        if (!cond) throw new IllegalArgumentException("Product with invalid name: " + producuto2);
        if (similitud < 0 ) throw new IllegalArgumentException("Invalid value of similirity: " + similitud);
        ctrlSupermercado.modificarSimilitud(supermercado, producuto1, producuto2, similitud);
    }

    /**
     * Elimina la similitud entre dos productos.
     *
     * @param supermercado Nombre del supermercado
     * @param producto1 Nombre del primer producto
     * @param producto2 Nombre del segundo producto
     * @throws IllegalArgumentException Si alguno de los productos no existe
     */
    public void eliminarSimilitud(String supermercado, String producto1, String producto2) {
        boolean cond = ctrlSupermercado.existsProducto(supermercado, producto1);
        if (!cond) throw new IllegalArgumentException("Product with invalid name: " + producto1);
        cond = ctrlSupermercado.existsProducto(supermercado, producto2);
        if (!cond) throw new IllegalArgumentException("Product with invalid name: " + producto2);
        ctrlSupermercado.eliminarSimilitud(supermercado, producto1, producto2);
    }

    /**
     * Consulta el valor de similitud entre dos productos.
     *
     * @param supermercado Nombre del supermercado
     * @param producto1 Nombre del primer producto
     * @param producto2 Nombre del segundo producto
     * @return Porcentaje de similitud entre los productos
     * @throws IllegalArgumentException Si alguno de los productos no existe
     */
    public int consultaSimilitud(String supermercado, String producto1, String producto2) {
        boolean cond = ctrlSupermercado.existsProducto(supermercado, producto1);
        if (!cond) throw new IllegalArgumentException("Product with invalid name: " + producto1);
        cond = ctrlSupermercado.existsProducto(supermercado, producto2);
        if (!cond) throw new IllegalArgumentException("Product with invalid name: " + producto2);
        return ctrlSupermercado.consultaSimilitudes(supermercado, producto1, producto2);
    }

    /**
     * Consulta todas las similitudes de un producto.
     *
     * @param supermercado Nombre del supermercado
     * @param producto1 Nombre del producto
     * @return Lista con los nombres de los productos similares
     * @throws IllegalArgumentException Si el producto no existe
     */
    public ArrayList<String> consultaSimilitudes(String supermercado, String producto1) {
        boolean cond = ctrlSupermercado.existsProducto(supermercado, producto1);
        if (!cond) throw new IllegalArgumentException("Product with invalid name: " + producto1);

        return ctrlSupermercado.consultaSimilitudes(supermercado, producto1);
    }

    /**
     * Consulta la distribución de un supermercado.
     *
     * @param supermercado Nombre del supermercado
     * @return Lista con la información de la distribución
     */
    public ArrayList<String> consultarDistribucion(String supermercado) {
        return ctrlSupermercado.consultarDistribucion(supermercado);
    }

    /**
     * Guarda los datos del usuario y sus supermercados asociados.
     *
     * @param datos Lista con los datos del usuario
     * @param supermercado Lista de mapas con las propiedades de los supermercados
     * @param productos Mapa con las propiedades de los productos
     * @throws SizePasswordException Si la contraseña es demasiado corta
     * @throws ExcepcionNoAlgoritmo Si hay un error con el algoritmo de ordenación
     */
    public void guardarDatos(ArrayList<String> datos, ArrayList<Map<String, Object>> supermercado, Map<String, Map<Integer, Map<String, Object>>> productos) throws SizePasswordException, ExcepcionNoAlgoritmo {
        UsuarioActual = new Usuario(datos.get(1), datos.get(3), datos.get(5), datos.get(7));
        int tratandoSup = -1;
        for (int i = 0; i < datos.size(); i++) {
            if (datos.get(i).equals("Nombre")) {
                String nombre = datos.get(i + 1);
                UsuarioActual.modificarNombre(nombre);
            } else if (datos.get(i).equals("Password")) {
                String password = datos.get(i + 1);
                if (password.length() < 12) throw new SizePasswordException(password.length());
                else UsuarioActual.modificarContraseña(password);
            } else if (datos.get(i).equals("Email")) {
                String email = datos.get(i + 1);
                UsuarioActual.modificarEmail(email);
            } else if (datos.get(i).equals("Idioma")) {
                String idioma = datos.get(i + 1);
                UsuarioActual.modificarIdioma(idioma);
            } else if (datos.get(i).equals("Supermercados")) {
                tratandoSup = i;
                if(ctrlSupermercado != null) ctrlSupermercado.limpiarDatos();
                ctrlSupermercado = new CtrlSupermercado();
            } else if (tratandoSup != -1) {
                ctrlSupermercado.guardarDatos(supermercado, productos);
                break;
            }
        }
    }

    /**
     * Obtiene la lista de supermercados asociados al usuario.
     *
     * @return Lista con los nombres de los supermercados
     */
    public ArrayList<String> supermercadosAsociados() {
        return ctrlSupermercado.getNombres();
    }

    //Getters
    /**
     * Obtiene el nombre del usuario actual.
     *
     * @return Nombre del usuario
     */
    public String getName() {
        return UsuarioActual.getName();
    }

    /**
     * Obtiene el email del usuario actual.
     *
     * @return Email del usuario
     */
    public String getEmail() {
        return UsuarioActual.getEmail();
    }

    /**
     * Obtiene la contraseña del usuario actual.
     *
     * @return Contraseña del usuario
     */
    public String getPassword() {
        return  UsuarioActual.getContraseña();
    }

    /**
     * Obtiene el idioma actual del usuario.
     *
     * @return Idioma actual
     */
    public String getIdiomaActual() {
        return UsuarioActual.getIdiomaActual();
    }

    /**
     * Obtiene los datos de los supermercados del usuario.
     *
     * @return Lista con mapas de datos de los supermercados
     */
    public ArrayList<Map<String, Object>> getDatosSuper(){
        return ctrlSupermercado.getDatosSuper(UsuarioActual.getName());
    }

    /**
     * Obtiene los datos de productos por supermercado.
     *
     * @return Mapa con los datos de productos organizados por supermercado
     */
    public Map<String,ArrayList<Map<String, Object>>> getDatosSuperProd(){
        return ctrlSupermercado.getDatosSuperProd(UsuarioActual.getName());
    }

    /**
     * Obtiene la lista de supermercados.
     *
     * @return Lista con los nombres de los supermercados
     */
    public ArrayList<String> getSupers(){
        return ctrlSupermercado.getSupers();
    }

    /**
     * Obtiene el algoritmo usado por un supermercado.
     *
     * @param supermercado Nombre del supermercado
     * @return Nombre del algoritmo utilizado
     */
    public String getAlgoritmo(String supermercado){
        return ctrlSupermercado.getAlgoritmo(supermercado);
    }

    /**
     * Verifica si existe un supermercado.
     *
     * @param supermercado Nombre del supermercado a verificar
     * @return true si existe el supermercado, false en caso contrario
     */
    public boolean existsSupermercado(String supermercado){
        return ctrlSupermercado.existsSupermercado(supermercado);
    }
}
