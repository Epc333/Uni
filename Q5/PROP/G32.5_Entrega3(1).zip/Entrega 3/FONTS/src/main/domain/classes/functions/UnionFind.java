package src.main.domain.classes.functions;

/**
 * UnionFind representa una estructura de datos tipo Union Find
 * @author Asier García Elvira (asier.garcia@estudiantat.upc.edu)
 */
public class UnionFind {
    private int[] padre, rango;

    //Constructora
    public UnionFind(int n) {
        padre = new int[n];
        rango = new int[n];
        for (int i = 0; i < n; i++) padre[i] = i;
    }

    //Find
    public int encontrar(int x) {
        if (padre[x] != x) {
            padre[x] = encontrar(padre[x]); // Compresión de ruta
        }
        return padre[x];
    }

    //Union
    public boolean unir(int x, int y) {
        int raizX = encontrar(x);
        int raizY = encontrar(y);

        if (raizX != raizY) {
            if (rango[raizX] > rango[raizY]) {
                padre[raizY] = raizX;
            } else if (rango[raizX] < rango[raizY]) {
                padre[raizX] = raizY;
            } else {
                padre[raizY] = raizX;
                rango[raizX]++;
            }
            return true;
        }
        return false;
    }
}
