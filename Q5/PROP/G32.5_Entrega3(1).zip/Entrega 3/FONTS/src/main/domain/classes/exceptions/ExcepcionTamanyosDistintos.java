package src.main.domain.classes.exceptions;

public class ExcepcionTamanyosDistintos extends Exception {

    public ExcepcionTamanyosDistintos() {
        super("The size of the similarities matrix is different to the positions one");
    }
}