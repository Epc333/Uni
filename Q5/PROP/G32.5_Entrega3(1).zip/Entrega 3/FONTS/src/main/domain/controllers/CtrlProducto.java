package src.main.domain.controllers;

import src.main.domain.classes.Producto;
import src.main.domain.classes.Similitud;

import java.util.*;

/**
 * Esta clase controla la gestión de productos en un supermercado.
 * Proporciona funciones para agregar, modificar, eliminar productos y gestionar sus similitudes.
 * @author Vinyet Granda Planas (vinyet.granda@estudiantat.upc.edu)
 */
public class CtrlProducto {
    private Map<String, ArrayList<Producto>> productos;

    /**
     * Constructora por defecto que inicializa el controlador con un mapa vacío de productos.
     */
    public CtrlProducto() {
        productos = new HashMap<>();
    }

    /**
     * Constructora que inicializa el controlador con un producto específico y lo añade a un supermercado.
     * @param name   Nombre del producto.
     * @param id     Identificador del producto.
     * @param precio Precio del producto.
     * @param Super  Nombre del supermercado donde se añadirá el producto.
     */
    public CtrlProducto(String name, int id, double precio, String Super) {
        ArrayList<Producto> productos = new ArrayList<>();
        productos.add(new Producto(id, name, precio));
        this.productos.put(Super, productos);
    }

    /**
     * Constructora que crea una copia profunda de otro controlador de productos.
     * @param a Controlador a copiar.
     */
    public CtrlProducto(CtrlProducto a) {
        Map<String, ArrayList<Producto>> productos = new HashMap<>();

        for (Map.Entry<String, ArrayList<Producto>> entry : productos.entrySet()) {
            ArrayList<Producto> nuevo = new ArrayList<>();
            for (Producto producto : entry.getValue()) {
                Producto p = new Producto(producto);
                nuevo.add(p);
            }
            this.productos.put(entry.getKey(), nuevo);
        }
    }

    /**
     * Obtiene un producto por su nombre dentro de un supermercado.
     * @param superName Nombre del supermercado.
     * @param nameProd  Nombre del producto.
     * @return El producto si se encuentra, o null si no existe.
     */
    public Producto getProducto(String superName, String nameProd) {
        for (Producto producto : productos.get(superName)) {
            if (producto.getNombre().equals(nameProd)) {
                return producto;
            }
        }
        return null;
    }

    /**
     * Modifica el nombre y precio de un producto existente en un supermercado.
     * @param viejoName Nombre actual del producto.
     * @param nombre    Nuevo nombre del producto.
     * @param precio    Nuevo precio del producto.
     * @param superName Nombre del supermercado.
     * @throws IllegalArgumentException si el nuevo nombre ya existe o si los valores proporcionados son inválidos.
     */
    public void modificarProducto(String viejoName, String nombre, double precio, String superName) {
        boolean existe = false;
        Producto p = null;
        for(Producto producto : productos.get(superName)) {
            if (producto.getNombre().equals(nombre)) {existe = true;}
            if (producto.getNombre().equals(viejoName)) {p = producto;}
        }

        if (existe) {throw new IllegalArgumentException("Product already exists");}
        if (nombre == null || precio < 0) throw new IllegalArgumentException("There is no values to modify");

        if (p != null) {
            p.modificarNombre(nombre);
            p.modificarPrecio(precio);
        }
    }

    /**
     * Crea una similitud entre dos productos en el mismo supermercado.
     * @param nameSuper  Nombre del supermercado.
     * @param nameProd   Nombre del primer producto.
     * @param nameProd2  Nombre del segundo producto.
     * @param similitud  Porcentaje de similitud entre los productos.
     * @throws IllegalArgumentException si la similitud ya existe o si los productos no existen.
     */
    public void crearSimilitud(String nameSuper, String nameProd, String nameProd2, int similitud) {
        ArrayList<Producto> aux = productos.get(nameSuper);
        Producto primero = null;
        Producto segundo = null;
        for (Producto producto : aux) {
            if (producto.getNombre().equals(nameProd)) {
                ArrayList<Similitud> sim = producto.getSimilitudes();
                for (int i = 0; i < sim.size(); i++) {
                    if (sim.get(i).getProducto().getNombre().equals(nameProd2))
                        throw new IllegalArgumentException("The Similarity already exists");
                }
                primero = producto;
            } else if (producto.getNombre().equals(nameProd2)) {
                segundo = producto;
            }
        }

        if (primero != null && segundo != null) {
            primero.anadirSimilitud(segundo, similitud);
        } else throw new IllegalArgumentException("Products not exists in supermarket");
    }

    /**
     * Modifica una similitud existente entre dos productos en el mismo supermercado.
     * @param nameSuper   Nombre del supermercado.
     * @param nameProd1   Nombre del primer producto.
     * @param nameProd2   Nombre del segundo producto.
     * @param similitud   Nuevo porcentaje de similitud.
     * @throws IllegalArgumentException si la similitud no existe.
     */
    public void modificarSimilitud(String nameSuper, String nameProd1, String nameProd2, int similitud) {
        ArrayList<Producto> aux = productos.get(nameSuper);
        boolean found = false;
        Producto primero = null;
        Producto segundo = null;
        for (Producto producto : aux) {
            if (producto.getNombre().equals(nameProd1)) {
                ArrayList<Similitud> sim = producto.getSimilitudes();
                for (int i = 0; i < sim.size(); i++) {
                    if (sim.get(i).getProducto().getNombre().equals(nameProd2)) found = true;
                }
                primero = producto;
            } else if (producto.getNombre().equals(nameProd2)) {
                segundo = producto;
            }
        }

        if (primero != null && segundo != null) {
            if (found) {
                primero.modificarSimilitud(segundo, similitud);
            } else throw new IllegalArgumentException("Similarity not exists");
        }
    }

    /**
     * Elimina una similitud existente entre dos productos en el mismo supermercado.
     * @param nameSuper   Nombre del supermercado.
     * @param nameProd1   Nombre del primer producto.
     * @param nameProd2   Nombre del segundo producto.
     * @throws IllegalArgumentException si la similitud no existe.
     */
    public void eliminarSimilitud(String nameSuper, String nameProd1, String nameProd2) {
        ArrayList<Producto> aux = productos.get(nameSuper);
        boolean found = false;
        Producto primero = null;
        Producto segundo = null;
        for (Producto producto : aux) {
            if (producto.getNombre().equals(nameProd1)) {
                ArrayList<Similitud> sim = producto.getSimilitudes();
                for (int i = 0; i < sim.size(); i++) {
                    if (sim.get(i).getProducto().getNombre().equals(nameProd2)) found = true;
                }
                primero = producto;
            } else if (producto.getNombre().equals(nameProd2)) {
                segundo = producto;
            }
        }

        if (primero != null && segundo != null) {
            if (found) {
                primero.eliminaSimilitud(segundo);
            } else throw new IllegalArgumentException("Similarity not exists");
        }
    }

    /**
     * Consulta el porcentaje de similitud entre dos productos en el mismo supermercado.
     * @param nameSuper   Nombre del supermercado.
     * @param nameProd1   Nombre del primer producto.
     * @param nameProd2   Nombre del segundo producto.
     * @return El porcentaje de similitud entre los productos.
     * @throws IllegalArgumentException si la similitud no existe.
     */
    public int consultarSimilitud(String nameSuper, String nameProd1, String nameProd2) {
        ArrayList<Producto> aux = productos.get(nameSuper);
        boolean found = false;
        Producto primero = null;
        Producto segundo = null;
        for (Producto producto : aux) {
            if (producto.getNombre().equals(nameProd1)) {
                ArrayList<Similitud> sim = producto.getSimilitudes();
                for (int i = 0; i < sim.size(); i++) {
                    if (sim.get(i).getProducto().getNombre().equals(nameProd2)) found = true;
                }
                primero = producto;
            } else if (producto.getNombre().equals(nameProd2)) {
                segundo = producto;
            }
        }

        if (primero != null && segundo != null) {
            if (found) {
                return primero.consultarSimilitud(segundo).getProcentaje_similitud();
            } else throw new IllegalArgumentException("Similarity not exists");
        }
        return 0;
    }

    /**
     * Consulta todas las similitudes de un producto con otros productos en el mismo supermercado.
     * @param nameSuper   Nombre del supermercado.
     * @param nameProd1   Nombre del producto.
     * @return Una lista de nombres de productos similares y su porcentaje de similitud.
     */
    public ArrayList<String> consultarSimilitudes(String nameSuper, String nameProd1) {
        ArrayList<Producto> aux = productos.get(nameSuper);
        ArrayList<String> lista = new ArrayList<>();
        for (Producto producto : aux) {
            if (producto.getNombre().equals(nameProd1)) {
                ArrayList<Similitud> sim = producto.getSimilitudes();
                for (int i = 0; i < sim.size(); i++) {
                    lista.add(sim.get(i).getProducto().getNombre());
                    lista.add(String.valueOf(sim.get(i).getProcentaje_similitud()));
                }
            }
        }
        return lista;
    }

    /**
     * Comprueba si un producto existe en un supermercado específico.
     * @param nombreSuper Nombre del supermercado.
     * @param nombreProd  Nombre del producto.
     * @return True si el producto existe, false en caso contrario.
     */
    public boolean existsProducto(String nombreSuper, String nombreProd) {
        if (productos.isEmpty()) return false;
        ArrayList<Producto> aux = productos.get(nombreSuper);
        if(aux == null) return false;
        for (Producto producto : aux) {
            if (producto.getNombre().equals(nombreProd)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Agrega un nuevo producto a un supermercado.
     * @param nombreSuper Nombre del supermercado.
     * @param nombreProd  Nombre del producto.
     * @param ultimoId    Identificador del producto.
     * @param precio      Precio del producto.
     */
    public void agregarProducto(String nombreSuper, String nombreProd, int ultimoId, double precio) {
        ArrayList<Producto> aux = productos.get(nombreSuper);
        boolean found = false;
        if (aux != null) {
            for (Producto producto : aux) {
                if (producto.getNombre().equals(nombreProd) && producto.getId() != ultimoId) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                Producto p = new Producto(ultimoId, nombreProd, precio);
                aux.add(p);
                productos.put(nombreSuper, aux);
            }
        } else {
            Producto p = new Producto(ultimoId, nombreProd, precio);
            aux = new ArrayList();
            aux.add(p);
            productos.put(nombreSuper, aux);
        }
    }

    /**
     * Elimina un producto de un supermercado y elimina sus similitudes asociadas.
     * @param nombreSuper Nombre del supermercado.
     * @param nombreProd  Nombre del producto a eliminar.
     */
    public void eliminarProducto(String nombreSuper, String nombreProd) {
        ArrayList<Producto> aux = productos.get(nombreSuper);
        for (int i = 0; i < aux.size(); i++) {
            if (aux.get(i).getNombre().equals(nombreProd)) {
                ArrayList<Similitud> sim = aux.get(i).getSimilitudes();
                for(int j = 0; j < sim.size(); j++) {
                    sim.get(j).getProducto().eliminaSimilitud(aux.get(i));
                }
                aux.get(i).limpiarDatos();
                aux.remove(i);
                productos.put(nombreSuper, aux);
                break;
            }
        }
    }

    /**
     * Devuelve la lista de productos de un supermercado.
     * @param nombreSuper Nombre del supermercado.
     * @return Lista de productos en el supermercado.
     */
    public ArrayList<Producto> getProductos(String nombreSuper) {
        return productos.get(nombreSuper);
    }

    /**
     * Obtiene los datos de los productos de un supermercado en forma de lista de mapas.
     * @param nameSuper Nombre del supermercado.
     * @param nameUser  Nombre del usuario.
     * @return Lista de mapas que contienen los datos de los productos.
     */
    public ArrayList<Map<String, Object>> getDatosSuperProd(String nameSuper, String nameUser) {
        ArrayList<Map<String, Object>> datosProducto = new ArrayList<>();
        ArrayList<Producto> prods = productos.get(nameSuper);
        if (prods != null) {
            for (Producto producto : prods) {
                Map<String, Object> aux = new LinkedHashMap<>();
                aux.put("IdProducto", producto.getId());
                aux.put("Nombre", producto.getNombre());
                aux.put("Precio", producto.getPrecio());
                ArrayList<Similitud> sim = producto.getSimilitudes();
                ArrayList<ArrayList<Integer>> aux2 = new ArrayList<>();
                for (int i = 0; i < sim.size(); i++) {
                    ArrayList<Integer> pair = new ArrayList<>();
                    pair.add(sim.get(i).getProcentaje_similitud());
                    pair.add(sim.get(i).getProducto().getId());
                    aux2.add(pair);
                }
                aux.put("Similitudes", aux2);
                aux.put("Supermercado", nameSuper);
                aux.put("Usuario", nameUser);
                datosProducto.add(aux);
            }
        } else prods = new ArrayList();

        return datosProducto;
    }

    /**
     * Modifica el nombre de un supermercado.
     * @param viejo Nombre antiguo del supermercado.
     * @param nuevo Nuevo nombre del supermercado.
     */
    public void modificarNombreSuper(String viejo, String nuevo){
        ArrayList<Producto> aux = productos.get(viejo);
        productos.remove(viejo);
        productos.put(nuevo, aux);
    }

    /**
     * Obtiene un producto por su identificador dentro de un supermercado.
     * @param supermercado Nombre del supermercado.
     * @param id           Identificador del producto.
     * @return El producto si se encuentra, o null si no existe.
     */
    public Producto getProducto(String supermercado, int id){
        for (Producto producto : productos.get(supermercado)) {
            if (producto.getId() == id) {
                return producto;
            }
        }
        return null;
    }
}
