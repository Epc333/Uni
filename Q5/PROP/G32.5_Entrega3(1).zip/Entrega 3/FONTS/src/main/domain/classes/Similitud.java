package src.main.domain.classes;

/**
 * Esta clase representa la similitud entre productos, con métodos para administrar y consultar
 * la similitud entre ellos.
 * @author Eudald Pizarro Cami (eudald.pizarro@estudiant.upc.edu)
 */
public class Similitud {

    /** Porcentaje de similitud entre productos*/
    private Integer porcentaje_similitud;

    /** Producto relacionado con esta similitud */
    private Producto product;

    /**
     * Constructora por defecto. Inicializa los valores de la similitud y el producto como null.
     */
    public Similitud() {
        this.porcentaje_similitud = null;
        this.product = null;
    }

    /**
     * Constructora que inicializa una similitud con un producto y un porcentaje de similitud.
     * @param product El producto con el que se está midiendo la similitud.
     * @param porcentaje El porcentaje de similitud entre los productos.
     */
    public Similitud(Producto product, int porcentaje) {
        this.porcentaje_similitud = porcentaje;
        this.product = product;
    }

    /**
     * Constructora de copia. Crea una nueva instancia copiando los valores de otra similitud.
     * @param similitud La similitud a copiar.
     */
    public Similitud(Similitud similitud) {
        this.porcentaje_similitud = similitud.getProcentaje_similitud();
        this.product = similitud.getProducto();
    }

    // MODIFICADORAS

    /**
     * Modifica el porcentaje de similitud.
     * @param similitud El nuevo porcentaje de similitud.
     */
    public void modificarSimilitud(Integer similitud) {
        this.porcentaje_similitud = similitud;
    }

    /**
     * Elimina la similitud.
     */
    public void eliminarSimilitud() {
        this.porcentaje_similitud = null;
        this.product = null;
    }

    /**
     * Devuelve el porcentaje de similitud entre productos.
     * @return El porcentaje de similitud.
     */
    public Integer getProcentaje_similitud() {
        return porcentaje_similitud;
    }

    /**
     * Devuelve el producto relacionado con esta similitud.
     * @return El producto relacionado.
     */
    public Producto getProducto() {
        return product;
    }

}
