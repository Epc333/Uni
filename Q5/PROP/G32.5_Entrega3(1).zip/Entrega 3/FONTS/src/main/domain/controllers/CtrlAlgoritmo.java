package src.main.domain.controllers;

import src.main.domain.classes.Algoritmo;
import src.main.domain.classes.functions.Aproximacion;
import src.main.domain.classes.functions.HillClimbing;
import src.main.domain.classes.exceptions.ExcepcionNoAlgoritmo;
import src.main.domain.classes.exceptions.ExcepcionTamanyosDistintos;
import src.main.domain.classes.functions.BackTracking;

import java.util.ArrayList;
import java.util.Collections;

/**
 * Controlador que gestiona los algoritmos utilizados para resolver problemas.
 * El controlador selecciona y utiliza un algoritmo específico basado en el nombre proporcionado.
 * @author Asier García Elvira (asier.garcia@estudiantat.upc.edu)
 */
public class CtrlAlgoritmo {

    /** Algoritmo actual que se está utilizando */
    private Algoritmo algoritmoActual;

    /**
     * Constructora que inicializa el controlador con un algoritmo específico.
     * @param algoritmo El nombre del algoritmo que se utilizará. Puede ser:
     *                  - "Back Tracking"
     *                  - "Hill Climbing"
     *                  - "2-Aproximación"
     * @throws ExcepcionNoAlgoritmo Si el algoritmo proporcionado no es válido.
     */
    public CtrlAlgoritmo(String algoritmo) throws ExcepcionNoAlgoritmo {
        switch (algoritmo) {
            case "Back Tracking" -> algoritmoActual = new BackTracking();
            case "Hill Climbing" -> algoritmoActual = new HillClimbing();
            case "2-Aproximación" -> algoritmoActual = new Aproximacion();
            default -> {
                throw new ExcepcionNoAlgoritmo();
            }
        }
    }

    /**
     * Constructora de copia que crea un nuevo controlador de algoritmo basado en otro controlador existente.
     * @param a El controlador de algoritmo a copiar.
     */
    public CtrlAlgoritmo(CtrlAlgoritmo a) {
        if (a.algoritmoActual instanceof HillClimbing) {
            this.algoritmoActual = new HillClimbing();
        } else if (a.algoritmoActual instanceof Aproximacion) {
            this.algoritmoActual = new Aproximacion();
        } else if (a.algoritmoActual instanceof BackTracking) {
            this.algoritmoActual = new BackTracking();
        }
    }

    /**
     * Método que devuelve una solución en relación a la ordenación de productos utilizando el algoritmo actual.
     * @param similitudes Matriz de similitudes entre productos
     * @param posiciones Lista de posiciones que corresponde a los identificadores de productos.
     * @return Lista con los identificadores de los productos ordenados según la solución encontrada por el algoritmo.
     * @throws ExcepcionTamanyosDistintos Si las listas de similitudes y posiciones tienen tamaños diferentes.
     */
    public ArrayList<Integer> getSolucion(ArrayList<ArrayList<Integer>> similitudes, ArrayList<Integer> posiciones) throws ExcepcionTamanyosDistintos {
        if (similitudes.size() != posiciones.size()) {
            throw new ExcepcionTamanyosDistintos();
        } else {
            generarEstadoInicial(similitudes, posiciones);
            return algoritmoActual.buscarSolucion(similitudes, posiciones);
        }
    }

    /**
     * Método que genera un estado inicial aleatorio para los productos, es decir, ordena aleatoriamente
     * las posiciones de los productos y ajusta la matriz de similitudes de acuerdo con este nuevo orden.
     * @param similitudes Matriz de similitudes con índices representando las posiciones de los productos.
     * @param posiciones Lista de posiciones de los productos.
     */
    public void generarEstadoInicial(ArrayList<ArrayList<Integer>> similitudes, ArrayList<Integer> posiciones) {
        // Clonar la lista de posiciones para crear un mapeo aleatorio
        ArrayList<Integer> original = new ArrayList<>(posiciones);
        Collections.shuffle(posiciones);

        // Crear un nuevo orden para la matriz de similitudes basado en la mezcla de posiciones
        ArrayList<ArrayList<Integer>> nuevaMatriz = new ArrayList<>();
        for (int i = 0; i < posiciones.size(); i++) {
            nuevaMatriz.add(new ArrayList<>());
            for (int j = 0; j < posiciones.size(); j++) {
                nuevaMatriz.get(i).add(similitudes.get(original.indexOf(posiciones.get(i)))
                        .get(original.indexOf(posiciones.get(j))));
            }
        }

        // Actualizar la matriz de similitudes con la nueva permutación
        similitudes.clear();
        similitudes.addAll(nuevaMatriz);
    }
}
