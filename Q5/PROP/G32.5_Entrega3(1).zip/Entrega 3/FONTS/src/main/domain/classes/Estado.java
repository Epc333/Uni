package src.main.domain.classes;

import java.util.*;

/**
 * Esta clase representa el estado actual de una distribución de productos.
 * El estado se define por la posición de los productos y su similitud entre ellos.
 * @author Andres Lucian Laptes Costan (andres.lucian.laptes@estudiantat.upc.edu)
 */
public class Estado {
    /**
     * Lista que contiene los identificadores (id) de los productos.
     */
    private ArrayList<Integer> estadoActual;

    /**
     * Matriz de similitudes entre los productos.
     */
    private ArrayList<ArrayList<Integer>> SimilitudActual;

    /**
     * Constructora que inicializa el estado con una distribución inicial de productos y la matriz de similitud.
     * @param ini Lista de identificadores de productos que representa la distribución inicial.
     * @param sim Matriz de similitud entre productos.
     */
    public Estado(ArrayList<Integer> ini, ArrayList<ArrayList<Integer>> sim) {
        estadoActual = new ArrayList<>();
        estadoActual.addAll(ini);

        SimilitudActual = new ArrayList<>();
        for (int i = 0; i < sim.size(); i++) {
            ArrayList<Integer> aux = new ArrayList<>();
            for (int j = 0; j < sim.get(i).size(); j++) {
                aux.add(j, sim.get(i).get(j));
            }
            SimilitudActual.add(i, aux);
        }
    }

    /**
     * Constructor de copia que crea un nuevo estado a partir de otro estado existente.
     * @param e El estado a copiar.
     */
    public Estado(Estado e) {
        estadoActual = new ArrayList<>();
        estadoActual.addAll(e.estadoActual);

        SimilitudActual = new ArrayList<>();
        for (int i = 0; i < e.SimilitudActual.size(); i++) {
            ArrayList<Integer> aux = new ArrayList<>();
            for (int j = 0; j < e.SimilitudActual.get(i).size(); j++) {
                aux.add(j, e.SimilitudActual.get(i).get(j));
            }
            SimilitudActual.add(i, aux);
        }
    }

    /**
     * Intercambia las posiciones de dos productos en la distribución actual.
     * @param i Índice del primer producto a intercambiar.
     * @param x Índice del segundo producto a intercambiar.
     */
    public void swap(int i, int x) {
        // Intercambia los productos en la lista de distribución
        int id1 = estadoActual.get(i);
        estadoActual.set(i, estadoActual.get(x));
        estadoActual.set(x, id1);

        // Intercambia las filas correspondientes en la matriz de similitud
        ArrayList<Integer> aux = SimilitudActual.get(i);
        SimilitudActual.set(i, SimilitudActual.get(x));
        SimilitudActual.set(x, aux);

        // Intercambia los valores en las columnas correspondientes
        for (int k = 0; k < SimilitudActual.size(); ++k) {
            Integer tmp = SimilitudActual.get(k).get(i);
            SimilitudActual.get(k).set(i, SimilitudActual.get(k).get(x));
            SimilitudActual.get(k).set(x, tmp);
        }
    }

    /**
     * Devuelve la distribución actual de productos.
     * @return Una lista de identificadores de productos.
     */
    public ArrayList<Integer> getDistribucion() {
        return estadoActual;
    }

    /**
     * Devuelve la matriz de similitud actual entre los productos.
     * @return Una matriz de similitud representada como una lista de listas de enteros.
     */
    public ArrayList<ArrayList<Integer>> getSimilitudActual() {
        return SimilitudActual;
    }

    /**
     * Devuelve el identificador de un producto en una posición específica en la distribución.
     * @param i Índice de la posición del producto.
     * @return El identificador del producto en la posición especificada.
     */
    public int getIDProducto(int i) {
        return estadoActual.get(i);
    }

    /**
     * Devuelve el número total de productos en la distribución.
     * @return El número de productos.
     */
    public int getNumeroProductos() {
        return estadoActual.size();
    }

    /**
     * Devuelve la similitud entre dos productos especificados por sus identificadores.
     * @param id1 El identificador del primer producto.
     * @param id2 El identificador del segundo producto.
     * @return El valor de la similitud entre los dos productos.
     */
    public int getSimilitudProductos(int id1, int id2) {
        return SimilitudActual.get(id1).get(id2);
    }
}
