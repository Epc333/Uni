
package src.main.domain.classes.functions;

import java.util.ArrayList;

import src.main.domain.classes.Algoritmo;

/**
 * Esta clase contiene los metodos de un algoritmo de backtracking, para
 * encontrar la mejor organizacion de productos.
 * 
 * @author Eudald Pizarro Cami (eudald.pizarro@estudiantat.upc.edu)
 */


public class BackTracking extends Algoritmo {
    private boolean[] visitados;
    private Integer[] mejorOrganizacion;
    private Integer valorMinimo;
    private ArrayList<Integer> identificadores;


    //CONSTRUCTORA
    public BackTracking() {
        this.visitados = new boolean[0];
        this.mejorOrganizacion = new Integer[0];
        this.valorMinimo = 0;
        this.identificadores = new ArrayList<>();
    }

    //MODIFICADORAS
    public void assignarAtributos(ArrayList<Integer> identificadores) {
        this.visitados = new boolean[identificadores.size()];
        this.mejorOrganizacion = new Integer[identificadores.size()];
        this.valorMinimo = Integer.MAX_VALUE;
        this.identificadores = identificadores;
    }

    //CONSULTORAS

    public Integer getValorMinimo() {
        return valorMinimo;
    }
    
    public boolean isEmpty() {
        return visitados.length == 0;
    }

    public ArrayList<Integer> getMejorOrganizacion() {
        ArrayList<Integer> mejorOrg = new ArrayList<>();
        for (Integer i : mejorOrganizacion) {
            mejorOrg.add(identificadores.get(i));
        }
        return mejorOrg;
    }

    //FUNCIONES
    @Override
    public ArrayList<Integer> buscarSolucion(ArrayList<ArrayList<Integer>> similitudes, ArrayList<Integer> posiciones) {
        if(similitudes.isEmpty()) return new ArrayList<>();
        assignarAtributos(posiciones);
        Integer[] distribucioAct = new Integer[posiciones.size()];
        distribucioAct[0] = 0;
        visitados[0] = true;
        backtrack(similitudes, distribucioAct, 1, 0);
        return getMejorOrganizacion();
    }

    private void backtrack(ArrayList<ArrayList<Integer>> similitudes, Integer[] distribucioAct, int indx, int sumaAct) {
        if (sumaAct >= valorMinimo) return;
        if (indx == distribucioAct.length) {
            sumaAct += 100 - similitudes.get(distribucioAct[indx - 1]).get(distribucioAct[0]);
            if (sumaAct < valorMinimo) {
                valorMinimo = sumaAct;
                mejorOrganizacion = distribucioAct.clone();
            }
            sumaAct -= 100 - similitudes.get(distribucioAct[indx - 1]).get(distribucioAct[0]);
            return;
        }

        for (int i = 1; i < distribucioAct.length; i++) {
            if (!visitados[i]) {
                sumaAct += 100 - similitudes.get(distribucioAct[indx - 1]).get(i);
                visitados[i] = true;
                distribucioAct[indx] = i;
                backtrack(similitudes, distribucioAct, indx + 1, sumaAct);
                visitados[i] = false;
                sumaAct -= 100 - similitudes.get(distribucioAct[indx - 1]).get(i);
            }
        }
    }
}
