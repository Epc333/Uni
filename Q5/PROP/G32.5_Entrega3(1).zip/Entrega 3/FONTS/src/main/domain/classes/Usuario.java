package src.main.domain.classes;

/**
 * Esta clase representa a un usuario con atributos como nombre, contraseña,
 * correo electrónico e idioma preferido.
 * Proporciona métodos para acceder y modificar estos atributos.
 * @author Andres Lucian Laptes Costan (andres.lucian.laptes@estudiantat.upc.edu)
 */
public class Usuario {

    /** Nombre del usuario */
    private String nombre;

    /** Contraseña del usuario */
    private String contraseña;

    /** Correo electrónico del usuario */
    private String email;

    /** Idioma preferido por el usuario */
    private String idiomaActual;

    /**
     * Constructor para crear un nuevo usuario con los datos proporcionados.
     * @param name El nombre del usuario.
     * @param password La contraseña del usuario.
     * @param mail El correo electrónico del usuario.
     * @param idioma El idioma preferido del usuario.
     */
    public Usuario(String name, String password, String mail, String idioma) {
        this.nombre = name;
        this.contraseña = password;
        this.email = mail;
        this.idiomaActual = idioma;
    }

    /**
     * Constructor de copia que crea un nuevo usuario a partir de otro usuario existente.
     * @param b El usuario del cual se copiarán los datos.
     */
    public Usuario(Usuario b) {
        this.nombre = b.nombre;
        this.contraseña = b.contraseña;
        this.email = b.email;
        this.idiomaActual = b.idiomaActual;
    }

    /**
     * Obtiene la contraseña del usuario.
     * @return La contraseña del usuario.
     */
    public String getContraseña() {
        return contraseña;
    }

    /**
     * Obtiene el nombre del usuario.
     * @return El nombre del usuario.
     */
    public String getName() {
        return nombre;
    }

    /**
     * Obtiene el correo electrónico del usuario.
     * @return El correo electrónico del usuario.
     */
    public String getEmail() {
        return email;
    }

    /**
     * Obtiene el idioma actual del usuario.
     * @return El idioma preferido por el usuario.
     */
    public String getIdiomaActual() {
        return idiomaActual;
    }

    /**
     * Modifica el nombre del usuario.
     * @param name El nuevo nombre para el usuario.
     */
    public void modificarNombre(String name) {
        this.nombre = name;
    }

    /**
     * Modifica la contraseña del usuario.
     * @param password La nueva contraseña para el usuario.
     */
    public void modificarContraseña(String password) {
        this.contraseña = password;
    }

    /**
     * Modifica el correo electrónico del usuario.
     * @param mail El nuevo correo electrónico para el usuario.
     */
    public void modificarEmail(String mail) {
        this.email = mail;
    }

    /**
     * Modifica el idioma preferido del usuario.
     * @param name El nuevo idioma preferido por el usuario.
     */
    public void modificarIdioma(String name) {
        this.idiomaActual = name;
    }
}
