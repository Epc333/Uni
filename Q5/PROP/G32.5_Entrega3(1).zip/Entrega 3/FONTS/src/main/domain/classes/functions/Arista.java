package src.main.domain.classes.functions;

import java.util.*;

/**
 * Arista representa una arista de un grafo.
 * @author Asier García Elvira (asier.garcia@estudiantat.upc.edu)
 */
public class Arista {

    private int desde;
    private int hasta;
    private int peso;

    // Constructora

    public Arista(int desde, int hasta, int peso) {
        this.desde = desde;
        this.hasta = hasta;
        this.peso = peso;
    }

    // Getters
    public int getDesde() {
        return desde;
    }

    public int getHasta() {
        return hasta;
    }

    public int getPeso() {
        return peso;
    }
}