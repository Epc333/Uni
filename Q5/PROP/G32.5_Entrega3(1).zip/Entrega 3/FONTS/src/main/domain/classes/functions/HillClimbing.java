package src.main.domain.classes.functions;

import src.main.domain.classes.Algoritmo;
import src.main.domain.classes.Estado;

import java.util.ArrayList;


/**
 * Esta clase representa el algoritmo que implementa el metodo de ordenacion/distribucion de
 * productos en una estanteria utilizando el alggoritmo Hill-climbing
 * @author Andres Lucian Laptes Costan (andres.lucian.laptes@estudiantat.upc.edu)
 * */
public class HillClimbing extends Algoritmo {
    private Estado estadoInicial;
    private Heuristico MejorHeurisitico;
    private Estado mejorEstado;

    public HillClimbing() {//Esto lo cambio        estadoInicial = new Estado(ini);
        estadoInicial = null;
        MejorHeurisitico = null;
        mejorEstado = null;
    }

    @Override
    public ArrayList<Integer> buscarSolucion(ArrayList<ArrayList<Integer>> Similitudes, ArrayList<Integer> idProductos) {
        BuscarSolucion(idProductos, Similitudes);
        return getMejorEstado();
    }

    public void BuscarSolucion(ArrayList<Integer> idProductos, ArrayList<ArrayList<Integer>> Similitudes) {
        estadoInicial = new Estado(idProductos, Similitudes);
        MejorHeurisitico = new Heuristico(estadoInicial);
        mejorEstado = estadoInicial;

        Estado estadoActual = new Estado(estadoInicial);

        boolean mejorado;

        do {
            mejorado = false;
            ArrayList<Estado> succesoresActuales = new ArrayList<>();

            for (int i = 0; i < estadoActual.getNumeroProductos(); ++i) {
                for (int j = i + 1; j < estadoActual.getNumeroProductos(); ++j) {
                    Estado nuevo = new Estado(estadoActual);
                    nuevo.swap(i, j);
                    succesoresActuales.add(nuevo);
                }
            }

            for (Estado aux : succesoresActuales) {
                Heuristico act = new Heuristico(aux);
                if (MejorHeurisitico.isLower(act)) {
                    MejorHeurisitico = act;
                    mejorEstado = aux;
                    mejorado = true;
                }
            }

            if (mejorado) estadoActual = mejorEstado;
        } while (mejorado);
    }

    public ArrayList<Integer> getMejorEstado() {
        return mejorEstado.getDistribucion();
    }

    public ArrayList<Integer> getEstadoInicial() {
        return estadoInicial.getDistribucion();
    }

    public int getMejorHeurisitico() {
        return MejorHeurisitico.getValue();
    }
}
