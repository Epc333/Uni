package src.main.domain.classes;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

/**
 * Esta clase representa un supermercado con estanterías y productos.
 * Permite gestionar la distribución de productos en las estanterías y
 * realizar diversas operaciones sobre el stock.
 * @author Vinyet Granda Planas (vinyet.granda@estudiantat.upc.edu)
 */
public class Supermercado {

    /** Nombre del supermercado */
    private String nombre;

    /** Fecha de creación del supermercado */
    private Date Fecha;

    /** Número total de estanterías del supermercado */
    private int n_estanterias;

    /** Distribución actual de productos en las estanterías */
    private ArrayList<Estanteria> distribucionActual;

    /** Stock de productos disponibles en el supermercado */
    private ArrayList<Producto> Stock;

    /**
     * Constructora que inicializa un supermercado con nombre y un número
     * de estanterías.
     * @param nombre El nombre del supermercado
     * @param n_estanterias Número de estanterías disponibles
     */
    public Supermercado(String nombre, int n_estanterias) {
        this.nombre = nombre;
        this.Fecha = new Date();
        this.n_estanterias = n_estanterias;
        this.distribucionActual = new ArrayList<>();
        this.Stock = new ArrayList<>();
    }

    /**
     * Constructora de copia. Crea un nuevo supermercado a partir de otro.
     * @param a El supermercado del cual se realizará la copia
     */
    public Supermercado(Supermercado a) {
        this.nombre = a.getNombre();
        this.Fecha = a.getFecha();
        this.n_estanterias = a.getN_estanterias();

        ArrayList<Estanteria> estanterias = new ArrayList<>();
        if (a.getDistribucionActual() != null) {
            for (int i = 0; i < a.getDistribucionActual().size(); i++) {
                Estanteria est = new Estanteria(a.getDistribucionActual().get(i));
                estanterias.add(est);
            }
        }
        this.distribucionActual = estanterias;

        ArrayList<Producto> productos = new ArrayList<>();
        if (a.getStock() != null) {
            for (int i = 0; i < a.getStock().size(); i++) {
                Producto aux = new Producto(a.getStock().get(i));
                productos.add(aux);
            }
        }
        this.Stock = productos;
    }

    /**
     * Obtiene el nombre del supermercado.
     * @return El nombre del supermercado
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Obtiene la fecha de creación del supermercado.
     * @return La fecha de creación
     */
    public Date getFecha() {
        return Fecha;
    }

    /**
     * Obtiene el número de estanterías en el supermercado.
     * @return Número de estanterías
     */
    public int getN_estanterias() {
        return n_estanterias;
    }

    /**
     * Obtiene la distribución actual de productos en las estanterías.
     * @return Lista de estanterías con su distribución actual
     */
    public ArrayList<Estanteria> getDistribucionActual() {
        return distribucionActual;
    }

    /**
     * Devuelve una lista de los identificadores de los productos que están
     * en el supermercado.
     * @return Lista de identificadores de productos
     */
    public ArrayList<Integer> getIdentificadores() {
        ArrayList<Integer> identificadores = new ArrayList<>();
        for (Estanteria est : distribucionActual) {
            ArrayList<Integer> ids = est.getIdentificadores();
            identificadores.addAll(ids);
        }
        return identificadores;
    }

    /**
     * Comprueba si existe una similitud entre dos productos.
     * @param prod1 Primer producto
     * @param prod2 Segundo producto
     * @return true si los productos son similares, false en caso contrario
     */
    public boolean existSimilitud(Producto prod1, Producto prod2) {
        return prod1.existSimilitud(prod2);
    }

    /**
     * Obtiene el número de la estantería donde se encuentra un producto,
     * @param nombre El nombre del producto
     * @return Número de estantería donde se encuentra el producto, o null si no se encuentra
     */
    public Integer getEstanteria(String nombre) {
        for (int i = 0; i < distribucionActual.size(); i++) {
            if (distribucionActual.get(i).existsProducto(nombre)) return i + 1;
        }
        return null;
    }

    /**
     * Obtiene la posición de un producto dentro de su estantería, dado su nombre.
     * @param nombre El nombre del producto
     * @return La posición del producto dentro de la estantería, o null si no se encuentra
     */
    public Integer getPosicionEstanteria(String nombre) {
        for (int i = 0; i < distribucionActual.size(); i++) {
            if (distribucionActual.get(i).existsProducto(nombre)) return distribucionActual.get(i).getPosicion(nombre);
        }
        return null;
    }

    /**
     * Modifica el nombre del supermercado.
     * @param nombre El nuevo nombre del supermercado
     */
    public void modificarNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Agrega un nuevo producto al stock del supermercado y recalcula la distribución de productos en las estanterías.
     * @param producto El producto que se desea agregar
     */
    public void agregarProducto(Producto producto) {
        Stock.add(producto);
        recalcularEstanterias();
    }

    /**
     * Elimina un producto del stock del supermercado, dado su nombre, y recalcula la distribución de las estanterías.
     * @param nombre El nombre del producto a eliminar
     */
    public void eliminarProducto(String nombre) {
        for (int i = 0; i < Stock.size(); i++) {
            if (Stock.get(i).getNombre().equals(nombre)) {
                Stock.remove(i);
                break;
            }
        }
        recalcularEstanterias();
    }

    /**
     * Modifica el stock completo del supermercado reemplazando la lista de productos.
     * @param productos Lista de nuevos productos
     */
    public void modificarStock(ArrayList<Producto> productos) {
        Stock.clear();
        Stock = productos;
    }

    /**
     * Recalcula la distribución de productos en las estanterías de acuerdo al stock.
     * El cálculo distribuye los productos de manera equitativa entre las estanterías.
     */
    public void recalcularEstanterias() {
        distribucionActual.clear();

        int productos = Stock.size();
        int estanteriasSobrantes = n_estanterias;
        double estantes_aux = (double) productos / estanteriasSobrantes;
        int estantes = (int) Math.ceil(estantes_aux);
        int j = 0;
        boolean reves = false;
        ArrayList<Producto> aux = new ArrayList<>();
        for (int i = 1; i <= Stock.size(); i++) {
            if (j == estantes) {
                if (reves) {
                    Collections.reverse(aux);
                    reves = false;
                } else reves = true;
                distribucionActual.add(new Estanteria(aux));
                j = 0;
                aux.clear();
                productos = Stock.size() - i;
                estanteriasSobrantes -= 1;
                estantes_aux = (double) productos / estanteriasSobrantes;
                estantes = (int) Math.ceil(estantes_aux);
            }
            aux.add(Stock.get(i - 1));
            j++;
        }
        if (reves) Collections.reverse(aux);
        distribucionActual.add(new Estanteria(aux));
    }

    /**
     * Limpia todos los datos del supermercado, eliminando productos y vaciando las estanterías.
     */
    public void limpiarDatos() {
        for (int i = 0; i < distribucionActual.size(); i++) {
            distribucionActual.get(i).limpiarDatos();
        }
        for (int i = 0; i < Stock.size(); i++) {
            Stock.get(i).limpiarDatos();
        }
        distribucionActual.clear();
        Stock.clear();
    }

    /**
     * Comprueba si un índice corresponde a una estantería válida.
     * @param i Índice de la estantería
     * @return true si el índice es válido, false en caso contrario
     */
    public boolean validEstanteria(int i) {
        return i >= 0 && i < distribucionActual.size();
    }

    /**
     * Devuelve una lista con la información detallada de los productos en el supermercado.
     * @return Lista con la descripción de los productos en el supermercado
     */
    public ArrayList<String> consultarSupermercado() {
        ArrayList<String> sup = new ArrayList<>();
        for (int i = 0; i < distribucionActual.size(); i++) {
            ArrayList<Producto> act = distribucionActual.get(i).consultarEstanterias();
            for (int j = 0; j < act.size(); j++) {
                sup.add("Nombre: " + act.get(j).getNombre());
                sup.add(" Precio: " + act.get(j).getPrecio());
                sup.add(" En la estantería: " + i);
                sup.add(" En la posición: " + j + "\n");
            }
        }
        return sup;
    }

    /**
     * Obtiene el stock actual de productos en el supermercado.
     * @return Una lista de productos disponibles en el supermercado.
     */
    public ArrayList<Producto> getStock() {
        return Stock;
    }

    /**
     * Intercambia la posición de dos productos dentro del stock del supermercado.
     * Después del intercambio, recalcula la distribución de los productos en las estanterías.
     * @param nameProd1 Nombre del primer producto a intercambiar.
     * @param nameProd2 Nombre del segundo producto a intercambiar.
     */
    public void intercambiarProductos(String nameProd1, String nameProd2) {
        Producto prod1 = null;
        Producto prod2 = null;
        for (Estanteria est : distribucionActual) {
            if (est.existsProducto(nameProd1)) {
                prod1 = est.getProducto(nameProd1);
            }
            if (est.existsProducto(nameProd2)) {
                prod2 = est.getProducto(nameProd2);
            }
        }
        ArrayList<Producto> productosIntercambiados = new ArrayList<>();
        for (int i = 0; i < Stock.size(); ++i) {
            if (Stock.get(i) == prod1) {
                productosIntercambiados.add(prod2);
            } else if (Stock.get(i) == prod2) {
                productosIntercambiados.add(prod1);
            } else productosIntercambiados.add(Stock.get(i));
        }
        Stock = productosIntercambiados;
        recalcularEstanterias();
    }
}