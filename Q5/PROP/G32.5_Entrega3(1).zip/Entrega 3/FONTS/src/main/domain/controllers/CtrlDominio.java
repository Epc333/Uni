package src.main.domain.controllers;

import java.io.FileNotFoundException;
import java.io.InvalidClassException;
import java.util.*;
import src.main.domain.classes.exceptions.ExcepcionNoAlgoritmo;
import src.main.domain.classes.exceptions.ExcepcionTamanyosDistintos;
import src.main.domain.classes.exceptions.SizePasswordException;
import src.main.persistence.controllers.CtrlPersistencia;

/**
 * Controlador principal del dominio que maneja las operaciones sobre los usuarios, supermercados y productos.
 * Esta clase interactúa con el controlador de persistencia, el diccionario y los controladores de usuarios y supermercados.
 * @author Vinyet Granda Planas (vinyet.granda@estudiantat.upc.edu)
 */
public class CtrlDominio {

    /** Controlador de Usuario*/
    private CtrlUsuario Usuario;

    /** Controlador de persistencia */
    private CtrlPersistencia persistencia;

    /** Controlador de Diccionario */
    private CtrlDiccionario Diccionario;

    /**
     * Constructora de la clase CtrlDominio. Inicializa los controladores de usuario, persistencia y diccionario, y
     * carga el diccionario por defecto ("Castellano").
     */
    public CtrlDominio() {
        Usuario = new CtrlUsuario();
        persistencia = new CtrlPersistencia();
        Diccionario = new CtrlDiccionario();
        try {
            Map<Integer, String> diccionario = persistencia.cargarDiccionario("Castellano");
            Diccionario.setIdioma("Castellano", diccionario);
        }
        catch (Exception e){
            System.out.println("Error: " + e.getMessage());
        }
    }

    /**
     * Crea un perfil de usuario en el sistema, registrando sus datos.
     * Verifica que el nombre de usuario y el correo electrónico no estén ya registrados.
     * @param name Nombre de usuario.
     * @param password Contraseña del usuario.
     * @param idioma Idioma preferido del usuario.
     * @param email Correo electrónico del usuario.
     * @throws IllegalArgumentException Si el nombre de usuario o el correo electrónico ya están registrados.
     */
    public void crearPerfil(String name, String password, String idioma, String email){
        try {
            if (persistencia.existsUsuario(name)) {
                ArrayList<String> datos = persistencia.cargarUsuario(name);
                for (int i = 0; i < datos.size(); i++) {
                    if (datos.get(i).equals("Email")) {
                        if (datos.get(i + 1).equals(email)) throw new IllegalArgumentException("Este correo ya está registrado");
                    }
                }
                throw new IllegalArgumentException("Este nombre de usuario ya está registrado");
            }

            ArrayList<String> idiomasDisponibles = Diccionario.getIdiomasDisponibles();
            CtrlUsuario Usuario = new CtrlUsuario();

            if (!idiomasDisponibles.contains(idioma)) throw new IllegalArgumentException(idioma + " no es un idioma válido");
            Usuario.crearPerfil(name, password, idioma, email, idiomasDisponibles);

            Map<Integer, String> lengua = persistencia.cargarDiccionario(idioma);
            Diccionario.setIdioma(idioma, lengua);
            ArrayList<String> datos = Usuario.getDatos();
            persistencia.guardarUsuario(datos);
        }
        catch (Exception e) {
            throw new IllegalArgumentException("Error: " + e.getMessage());
        }
    }

    /**
     * Modifica el perfil de un usuario existente, permitiendo cambiar sus datos.
     * Si se modifica el idioma, también se actualiza el diccionario correspondiente.
     * @param name2 Nuevo nombre de usuario.
     * @param password Nueva contraseña.
     * @param idioma Nuevo idioma.
     * @param mail Nuevo correo electrónico.
     */
    public void modificarPerfil(String name2, String password, String idioma, String mail) {
        if(name2 != null) {
            if (persistencia.existsUsuario(name2)) throw new IllegalArgumentException("El nombre de usuario ya existe");
            try {
                try {
                    String nombre = Usuario.getName();
                    ArrayList<String> supers = Usuario.supermercadosAsociados();
                    for (int i = 0; i < supers.size(); i++) {
                        ArrayList<String> productos = Usuario.consultaStock(supers.get(i));
                        for (int j = 0; j < productos.size(); j+=2) {
                            persistencia.eliminarProd(nombre, supers.get(i), productos.get(j));
                        }
                        persistencia.eliminarSupermercado(supers.get(i), nombre);
                    }
                    persistencia.eliminarUsuario(Usuario.getName());
                } catch (IllegalArgumentException e) {
                    throw new IllegalArgumentException("Error: " + e.getMessage());
                }
                Usuario.modificarPerfil(name2, password, idioma, mail);
                if(idioma != null) Diccionario.setIdioma(idioma, persistencia.cargarDiccionario(idioma));
                this.guardarUsuarioMemoria();

            } catch (Exception e) {
                throw new IllegalArgumentException("Error: " + e.getMessage());
            }
        }
        else {
            try {
                Usuario.modificarPerfil(name2, password, idioma, mail);
                if(idioma != null) Diccionario.setIdioma(idioma, persistencia.cargarDiccionario(idioma));
                persistencia.guardarUsuario(Usuario.getDatos());

            } catch (Exception e) {
                throw new IllegalArgumentException("Error: " + e.getMessage());
            }
        }
    }

    /**
     * Elimina el perfil de un usuario y todos sus supermercados asociados.
     * También elimina todos los productos asociados a esos supermercados.
     */
    public void eliminarPerfil(){
        try {
            String nombre = Usuario.getName();
            ArrayList<String> supers = Usuario.supermercadosAsociados();
            for (int i = 0; i < supers.size(); i++) {
                ArrayList<String> productos = Usuario.consultaStock(supers.get(i));
                for (int j = 0; j < productos.size(); j+=2) {
                    persistencia.eliminarProd(nombre, supers.get(i), productos.get(j));
                }
                persistencia.eliminarSupermercado(supers.get(i), nombre);
            }
            persistencia.eliminarUsuario(Usuario.getName());
            Usuario.eliminarPerfil();
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Error: " + e.getMessage());
        }
    }

    /**
     * Genera un supermercado para el usuario con un nombre y un número de estanterías.
     * @param supermercado Nombre del supermercado.
     * @param n_estanterias Número de estanterías en el supermercado.
     */
    public void generarSupermercado(String supermercado, int n_estanterias){
        try {
            Usuario.generarSupermercado(supermercado, n_estanterias);
        } catch (IllegalArgumentException | ExcepcionNoAlgoritmo e) {
            throw new IllegalArgumentException("Error: " + e.getMessage());
        }
    }

    /**
     * Modifica el nombre de un supermercado del usuario.
     * Si el nuevo nombre ya existe, lanza una excepción.
     * @param supermercado Nombre actual del supermercado.
     * @param supermercado2 Nuevo nombre del supermercado.
     * @throws IllegalArgumentException Si ya existe un supermercado con el nombre elegido
     */
    public void modificarSupermercado(String supermercado, String supermercado2){
        try {
            if(!Usuario.existsSupermercado(supermercado2)) {
                ArrayList<String> supers = Usuario.supermercadosAsociados();
                for (int i = 0; i < supers.size(); i++) {
                    ArrayList<String> productos = Usuario.consultaStock(supers.get(i));
                    for (int j = 0; j < productos.size(); j += 2) {
                        persistencia.eliminarProd(Usuario.getName(), supers.get(i), productos.get(j));
                    }
                    persistencia.eliminarSupermercado(supers.get(i), Usuario.getName());
                }
                persistencia.eliminarSupermercado(supermercado, Usuario.getName());
                Usuario.modificarNombreSupermercado(supermercado, supermercado2);
                this.guardarUsuarioMemoria();
            }
            else throw new IllegalArgumentException("Ya existe un supermercado con ese nombre");
        } catch (IllegalArgumentException e){
            throw new IllegalArgumentException("Error: " + e.getMessage());
        }
    }

    /**
     * Consulta los datos del usuario, como nombre, correo electrónico e idioma.
     * @return Lista de datos del usuario.
     */
    public ArrayList<String> getDatosUsuarios() {
        try {
            return Usuario.getDatos();
        } catch (Exception e){
            throw new IllegalArgumentException("Error: " + e.getMessage());
        }
    }

    /**
     * Elimina todos los supermercados asociados al usuario y sus productos.
     */
    public void borrarSupermercados(){
        try {
            ArrayList<String> aux = Usuario.supermercadosAsociados();
            for (int i = 0; i < aux.size(); i++) {
                ArrayList<String> productos = Usuario.consultaStock(aux.get(i));
                for (int j = 0; j < productos.size(); j++) {
                    if (j % 2 == 0) persistencia.eliminarProd(Usuario.getName(), aux.get(i), productos.get(j));
                }
                persistencia.eliminarSupermercado(aux.get(i), Usuario.getName());
                Usuario.eliminarSupermercado(aux.get(i));
            }
            persistencia.guardarUsuario(Usuario.getDatos());
        } catch (IllegalArgumentException e){
            throw new IllegalArgumentException("Error: " + e.getMessage());
        }
    }

    /**
     * Elimina un supermercado del usuario.
     * @param supermercado El nombre del supermercado a eliminar.
     * @throws IllegalArgumentException Si ocurre un error al eliminar el supermercado.
     */
    public void eliminarSupermercado(String supermercado) {
        try {
            ArrayList<String> aux = Usuario.consultaStock(supermercado);
            if (aux != null) {
                for (int i = 0; i < aux.size(); i+=2) {
                    persistencia.eliminarProd(Usuario.getName(), supermercado, aux.get(i));
                }
                persistencia.eliminarSupermercado(supermercado, Usuario.getName());
            }
            Usuario.eliminarSupermercado(supermercado);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Error: " + e.getMessage());
        }
    }

    /**
     * Duplica un supermercado del usuario.
     * @param supermercadoOriginal El nombre del supermercado original.
     * @param newSupermercado El nuevo nombre para el supermercado duplicado.
     * @throws IllegalArgumentException Si ocurre un error al duplicar el supermercado.
     */
    public void duplicarSupermercado(String supermercadoOriginal, String newSupermercado) {
        try {
            Usuario.duplicarSupermercado(supermercadoOriginal, newSupermercado);
        } catch (IllegalArgumentException | ExcepcionNoAlgoritmo e) {
            throw new IllegalArgumentException("Error: " + e.getMessage());
        }
    }

    /**
     * Cambia el idioma del usuario.
     * @param idioma El nuevo idioma que se seleccionará.
     * @throws IllegalArgumentException Si el idioma no es válido.
     */
    public void seleccionaIdioma(String idioma) {
        try {
            Usuario.seleccionaIdioma(idioma);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Error: " + e.getMessage());
        }
    }

    /**
     * Consulta los detalles de un supermercado del usuario.
     * @param supermercado El nombre del supermercado a consultar.
     * @return Un ArrayList con el nombre del supermercado, el número de estanterías y el número de productos totales.
     * @throws IllegalArgumentException Si ocurre un error al consultar el supermercado.
     */
    public ArrayList<String> consultaSupermercado(String supermercado) {
        try {
            return Usuario.consultarSupermercado(supermercado);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Error: " + e.getMessage());
        }
    }

    /**
     * Realiza el login del usuario con la contraseña indicada.
     * @param usuario El nombre del usuario.
     * @param password La contraseña del usuario.
     * @return true si las credenciales son correctas, false si no lo son.
     * @throws SizePasswordException Si la contraseña tiene un tamaño incorrecto.
     * @throws IllegalArgumentException Si las credenciales no coinciden.
     */
    public boolean logIn(String usuario, String password) throws SizePasswordException {
        if (persistencia.existsUsuario(usuario)) {
            ArrayList<String> datosUsuario = persistencia.cargarUsuario(usuario);
            for (String dato : datosUsuario) {
                if (dato.equals(password)) {
                    try {
                        this.cargarUsuarioMemoria(usuario);
                    } catch (Exception e) {
                        throw new IllegalArgumentException("Error: " + e.getMessage());
                    }
                    return true;
                }
            }
            throw new IllegalArgumentException("Incorrect password");
        } else {
            throw new IllegalArgumentException("No user with this username");
        }
    }

    /**
     * Cierra la sesión del usuario y guarda su información.
     * @return false, ya que no es necesario un valor de retorno.
     */
    public boolean logOut() {
        this.guardarUsuarioMemoria();
        Usuario = new CtrlUsuario();
        persistencia = new CtrlPersistencia();
        Diccionario = new CtrlDiccionario();
        try {
            Map<Integer, String> diccionario = persistencia.cargarDiccionario("Castellano");
            Diccionario.setIdioma("Castellano", diccionario);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        return false;
    }

    /**
     * Consulta el stock de un supermercado del usuario.
     * @param supermercado El nombre del supermercado a consultar.
     * @return Un ArrayList con los detalles de los productos (nombre, precio, estantería, posición).
     */
    public ArrayList<String> consultaStock(String supermercado) {
        return Usuario.consultaStock(supermercado);
    }

    /**
     * Añade un producto a un supermercado del usuario.
     * @param supermercado El nombre del supermercado.
     * @param producto El nombre del producto.
     * @param precio El precio del producto.
     * @throws IllegalArgumentException Si ocurre un error al añadir el producto.
     */
    public void anadirProducto(String supermercado, String producto, double precio) {
        try {
            Usuario.anadirProducto(supermercado, producto, precio);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Error: " + e.getMessage());
        }
    }

    /**
     * Consulta la distribución de productos en un supermercado del usuario.
     * @param supe El nombre del supermercado.
     * @return Un ArrayList con la distribución de productos.
     * @throws IllegalArgumentException Si ocurre un error al consultar la distribución.
     */
    public ArrayList<String> consultarDistribucion(String supe) {
        try {
            return Usuario.consultarDistribucion(supe);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Error: " + e.getMessage());
        }
    }

    /**
     * Modifica un producto en un supermercado del usuario.
     * @param supermercado El nombre del supermercado.
     * @param producto El nombre del producto a modificar.
     * @param newName El nuevo nombre del producto.
     * @param newPrecio El nuevo precio del producto.
     * @throws IllegalArgumentException Si ocurre un error al modificar el producto.
     */
    public void modificarProducto(String supermercado, String producto, String newName, double newPrecio) {
        try {
            Usuario.modificarProducto(supermercado, producto, newName, newPrecio);
            persistencia.eliminarProd(Usuario.getName(), supermercado, producto);
            } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Error: " + e.getMessage());
        }
    }

    /**
     * Elimina un producto de un supermercado del usuario.
     * @param supermercado El nombre del supermercado.
     * @param producto El nombre del producto a eliminar.
     * @throws IllegalArgumentException Si ocurre un error al eliminar el producto.
     */
    public void eliminarProducto(String supermercado, String producto) {
        try {
            Usuario.eliminarProducto(supermercado, producto);
            persistencia.eliminarProd(Usuario.getName(), supermercado, producto);
            this.guardarUsuarioMemoria();
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Error: " + e.getMessage());
        }
    }

    /**
     * Cambia el algoritmo de ordenación de los productos en un supermercado del usuario.
     * @param supermercado El nombre del supermercado.
     * @param algoritmo El nombre del algoritmo de ordenación.
     * @throws IllegalArgumentException Si ocurre un error al cambiar el algoritmo.
     */
    public void cambiarAlgoritmo(String supermercado, String algoritmo) {
        try {
            Usuario.cambiarAlgoritmo(supermercado, algoritmo);
        } catch (Exception e) {
            throw new IllegalArgumentException("Error: " + e.getMessage());
        }
    }

    /**
     * Intercambia dos productos de un supermercado del usuario.
     * @param supermercado El nombre del supermercado.
     * @param prod1 El nombre del primer producto.
     * @param prod2 El nombre del segundo producto.
     * @throws IllegalArgumentException Si ocurre un error al intercambiar los productos.
     */
    public void intercambiarProductos(String supermercado, String prod1, String prod2) {
        try {
            Usuario.intercambiarProductos(supermercado, prod1, prod2);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Error: " + e.getMessage());
        }
    }

    /**
     * Consulta los detalles de un producto de un supermercado del usuario.
     * @param supermercado El nombre del supermercado.
     * @param producto El nombre del producto.
     * @return Un ArrayList con el nombre, la estantería, la posición y el precio del producto.
     * @throws IllegalArgumentException Si ocurre un error al consultar el producto.
     */
    public ArrayList<String> consultaProducto(String supermercado, String producto) {
        try {
            return Usuario.consultaProducto(supermercado, producto);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Error: " + e.getMessage());
        }
    }

    /**
     * Crea una similitud entre dos productos de un supermercado del usuario.
     * @param supermercado El nombre del supermercado.
     * @param prod1 El nombre del primer producto.
     * @param prod2 El nombre del segundo producto.
     * @param similitud El porcentaje de similitud entre los productos.
     * @throws IllegalArgumentException Si ocurre un error al crear la similitud.
     */
    public void crearSimilitud(String supermercado, String prod1, String prod2, int similitud) {
        try {
            Usuario.crearSimilitud(supermercado, prod1, prod2, similitud);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Error: " + e.getMessage());
        }
    }

    /**
     * Modifica una similitud entre dos productos de un supermercado del usuario.
     * @param supermercado El nombre del supermercado.
     * @param prod1 El nombre del primer producto.
     * @param prod2 El nombre del segundo producto.
     * @param similitud El nuevo porcentaje de similitud.
     * @throws IllegalArgumentException Si ocurre un error al modificar la similitud.
     */
    public void modificarSimilitud(String supermercado, String prod1, String prod2, int similitud) {
        try {
            Usuario.modificarSimilitud(supermercado, prod1, prod2, similitud);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Error: " + e.getMessage());
        }
    }

    /**
     * Elimina una similitud entre dos productos de un supermercado del usuario.
     * @param supermercado El nombre del supermercado.
     * @param prod1 El nombre del primer producto.
     * @param prod2 El nombre del segundo producto.
     * @throws IllegalArgumentException Si ocurre un error al eliminar la similitud.
     */
    public void eliminarSimilitud(String supermercado, String prod1, String prod2) {
        try {
            Usuario.eliminarSimilitud(supermercado, prod1, prod2);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Error: " + e.getMessage());
        }
    }

    /**
     * Consulta todas las similitudes de un producto en un supermercado del usuario.
     * @param supermercado El nombre del supermercado.
     * @param prod1 El nombre del producto.
     * @return Un ArrayList con los nombres de todos los productos similares.
     * @throws IllegalArgumentException Si ocurre un error al consultar las similitudes.
     */
    public ArrayList<String> consultaSimilitudes(String supermercado, String prod1) {
        try {
            return Usuario.consultaSimilitudes(supermercado, prod1);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Error: " + e.getMessage());
        }
    }

    /**
     * Consulta el porcentaje de similitud entre dos productos de un supermercado del usuario.
     * @param supermercado El nombre del supermercado.
     * @param prod1 El nombre del primer producto.
     * @param prod2 El nombre del segundo producto.
     * @return El porcentaje de similitud entre los productos.
     * @throws IllegalArgumentException Si ocurre un error al consultar la similitud.
     */
    public int consultaSimilitud(String supermercado, String prod1, String prod2) {
        try {
            return Usuario.consultaSimilitud(supermercado, prod1, prod2);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Error: " + e.getMessage());
        }
    }

    /**
     * Carga la información del usuario en la memoria.
     * @param usuario El nombre del usuario.
     * @throws SizePasswordException Si la contraseña tiene un tamaño incorrecto.
     * @throws ExcepcionNoAlgoritmo Si el algoritmo no está disponible.
     * @throws NullPointerException Si el usuario es null
     */
    public void cargarUsuarioMemoria(String usuario) throws SizePasswordException, ExcepcionNoAlgoritmo {
        if (usuario != null) {
            if (persistencia.existsUsuario(usuario)) {
                ArrayList<String> datosUsuario = persistencia.cargarUsuario(usuario);
                ArrayList<Map<String, Object>> datosSuper = new ArrayList<>();
                Map<String, Map<Integer, Map<String, Object>>> datosProd = new HashMap<>();
                for (int i = 0; i < datosUsuario.size(); i++) {
                    if (datosUsuario.get(i).equals("Supermercados")) {
                        for (int j = i + 1; j < datosUsuario.size(); j++) {
                            String nameSuper = datosUsuario.get(j);
                            Map<String, Object> datos = persistencia.cargarSupermercado(nameSuper, usuario);
                            datosSuper.add(datos);
                            ArrayList<String> stock = (ArrayList<String>) datos.get("Stock");
                            if(stock.size() != 0) {
                                Map<Integer, Map<String, Object>> datosProductos = persistencia.cargarProducto(usuario, nameSuper);
                                datosProd.put(nameSuper, datosProductos);
                            }
                        }
                        break;
                    }
                }
                try {
                    Usuario.guardarDatos(datosUsuario, datosSuper, datosProd);
                    String Idioma = null;
                    for (int i = 0; i < datosUsuario.size(); ++i) {
                        if (datosUsuario.get(i).equals("Idioma")) {
                            Idioma = datosUsuario.get(i + 1);
                            break;
                        }
                    }
                    Map<Integer, String> diccionario = persistencia.cargarDiccionario(Idioma);
                    Diccionario.setIdioma(Idioma, diccionario);
                } catch (Exception e) {
                    throw new IllegalArgumentException("Error: " + e.getMessage());
                }
            } else throw new NullPointerException("Usuario no existe");
        }
    }

    /**
     * Guarda la información del usuario en la memoria.
     */
    public void guardarUsuarioMemoria() {
        ArrayList<String> infoUser = Usuario.getDatos();
        persistencia.guardarUsuario(infoUser);

        ArrayList<Map<String, Object>> datosSuper = Usuario.getDatosSuper();
        for (int i = 0; i < datosSuper.size(); i++) {
            persistencia.guardarSupermercado(datosSuper.get(i));
        }

        Map<String, ArrayList<Map<String, Object>>> datosProductos = Usuario.getDatosSuperProd();
        if (datosProductos != null) {
            for (Map.Entry<String, ArrayList<Map<String, Object>>> entry : datosProductos.entrySet()) {
                for (int j = 0; j < entry.getValue().size(); j++) {
                    persistencia.guardarProducto(entry.getValue().get(j));
                }
            }
        }
    }

    /**
     * Obtiene los nombres de todos los supermercados del usuario.
     * @return Un ArrayList con los nombres de los supermercados.
     */
    public ArrayList<String> getNombresSupers() {
        return Usuario.getSupers();
    }

    /**
     * Obtiene una frase del diccionario en el idioma seleccionado.
     * @param idioma El idioma seleccionado.
     * @param i El índice de la frase.
     * @return La frase correspondiente al índice.
     */
    public String getFrase(String idioma, int i) {
        if (Usuario == null && idioma != "Castellano") {
            Diccionario = new CtrlDiccionario();
            try {
                Map<Integer, String> diccionario = persistencia.cargarDiccionario("Castellano");
                Diccionario.setIdioma(idioma, diccionario);
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
        return Diccionario.getFrase(idioma, i);
    }

    /**
     * Obtiene el nombre del usuario.
     * @return El nombre del usuario.
     */
    public String getName() {
        return Usuario.getName();
    }

    /**
     * Obtiene la contraseña del usuario.
     * @return La contraseña del usuario.
     */
    public String getPassword() {
        return Usuario.getPassword();
    }

    /**
     * Obtiene el algoritmo de ordenación de un supermercado del usuario.
     * @param supermercado El nombre del supermercado.
     * @return El algoritmo de ordenación del supermercado.
     */
    public String getAlgoritmo(String supermercado) {
        return Usuario.getAlgoritmo(supermercado);
    }
}

