package src.tests;

import src.main.domain.classes.Diccionario;
import org.junit.Test;

import java.util.*;

import static org.junit.Assert.*;

/**
 * @author Andres Lucian Laptes Costan (andres.lucian.laptes@estudiantat.upc.edu)
 * */
public class TestDiccionario {
    /**
     * Objetivo de la prueba: Test de la función getIdiomasDisponibles
     * Archivos de datos necesarios: ninguno, los datos son configurados manualmente
     * Valores estudiados: Estrategia caja gris, se crean los idiomas en un diccionario y se comprueba que todos los idiomas estén disponibles
     * Operativa: creamos un nuevo Diccionario, obtenemos los idiomas disponibles y comprobamos que coincidan con los esperados
     */
    @Test
    public void TestGetIdiomasDisponibles() {
        Diccionario diccionario = new Diccionario();
        Set<String> idiomasEsperados = new HashSet<>(Arrays.asList("Castellano", "Catalan", "Ingles", "Rumano"));
        Set<String> idiomasObtenidos = new HashSet<>(diccionario.getIdiomasDisponibles());

        assertEquals("Los idiomas disponibles no coinciden", idiomasEsperados, idiomasObtenidos);
    }

    /**
     * Objetivo de la prueba: Test de la función getFrases para verificar algunas frases aleatorias en distintos idiomas y comprobar que la constructora
     * tambien fucniona correctamente
     * Archivos de datos necesarios: ninguno, los datos son configurados manualmente
     * Valores estudiados: Estrategia caja gris, se configuran las frases de varios idiomas y se comprueban algunas frases aleatorias para verificar que coincidan con las esperadas
     * Operativa: creamos un nuevo Diccionario, obtenemos frases específicas en varios idiomas y comprobamos que coincidan con las frases esperadas
     */
    @Test
    public void TestGetFrasesAleatorias() {
        Diccionario diccionario = new Diccionario();

        Map<Integer, String> frasesCastellano = diccionario.getFrases();
        assertEquals("Frase incorrecta en Castellano para id 1", "Inserte nombre del Usuario:", frasesCastellano.get(1));
        assertEquals("Frase incorrecta en Castellano para id 4", "Idiomas disponibles:", frasesCastellano.get(4));

        Map<Integer, String> frasesCatalan = diccionario.getFrases();
        assertEquals("Frase incorrecta en Catalan para id 2", "Inseriu contrasenya de l'Usuari:", frasesCatalan.get(2));
        assertEquals("Frase incorrecta en Catalan para id 5", "Seleccioni una llengua de les disponibles:", frasesCatalan.get(5));

        Map<Integer, String> frasesIngles = diccionario.getFrases();
        assertEquals("Frase incorrecta en Ingles para id 1", "Insert User name:", frasesIngles.get(1));
        assertEquals("Frase incorrecta en Ingles para id 3", "Insert User email:", frasesIngles.get(3));

        Map<Integer, String> frasesRumano = diccionario.getFrases();
        assertEquals("Frase incorrecta en Rumano para id 2", "Introduceți parola utilizatorului:", frasesRumano.get(2));
        assertEquals("Frase incorrecta en Rumano para id 4", "Limbi disponibile:", frasesRumano.get(4));
    }

    /**
     * Objetivo de la prueba: Test de la función getFrase para verificar que devuelve las frases correctas en distintos idiomas y para varios identificadores
     * Archivos de datos necesarios: ninguno, los datos son configurados manualmente
     * Valores estudiados: Estrategia caja gris, se configuran las frases de varios idiomas y se comprueba que las frases devueltas coincidan con las esperadas
     * Operativa: creamos un nuevo Diccionario, obtenemos frases específicas usando la función getFrase y verificamos que coincidan con las frases esperadas
     */
    @Test
    public void TestGetFrase() {
        Diccionario diccionario = new Diccionario();

        // Verificar frases en Castellano
        assertEquals("Frase incorrecta en Castellano para id 1", "Inserte nombre del Usuario:", diccionario.getFrase(1));
        assertEquals("Frase incorrecta en Castellano para id 4", "Idiomas disponibles:", diccionario.getFrase(4));

        // Verificar frases en Catalan
        assertEquals("Frase incorrecta en Catalan para id 2", "Inseriu contrasenya de l'Usuari:", diccionario.getFrase( 2));
        assertEquals("Frase incorrecta en Catalan para id 5", "Seleccioni una llengua de les disponibles:", diccionario.getFrase( 5));

        // Verificar frases en Ingles
        assertEquals("Frase incorrecta en Ingles para id 1", "Insert User name:", diccionario.getFrase( 1));
        assertEquals("Frase incorrecta en Ingles para id 3", "Insert User email:", diccionario.getFrase( 3));

        // Verificar frases en Rumano
        assertEquals("Frase incorrecta en Rumano para id 2", "Introduceți parola utilizatorului:", diccionario.getFrase( 2));
        assertEquals("Frase incorrecta en Rumano para id 4", "Limbi disponibile:", diccionario.getFrase( 4));
    }


}
