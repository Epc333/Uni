package src.tests;

import src.main.domain.classes.functions.UnionFind;

import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

/**
 * Clase con tests para UnionFind.
 * @author Asier García Elvira (asier.garcia@estudiantat.upc.edu)
 */
public class TestUnionFind {

    /**
     * Objetivo de la prueba: Verificar que el constructor de la clase UnionFind inicializa correctamente los atributos
     * Ficheros de datos necesarios: Los datos se introducen manualmente.
     * Valores Estudiados: Estratègia caja gris. Se crea una instancia de UnionFInd y comprobamos que sus atributos sean los correctos.
     * Operativa: Creamos un UnionFind con n = 5 y vemos que los nodos son sus propios padres.
     */
    @Test
    public void testConstructor() {
        int n = 5;
        UnionFind uf = new UnionFind(n);

        for (int i = 0; i < n; i++) {
            assertEquals("Cada nodo debe ser su propio padre al inicio", i, uf.encontrar(i));
        }
    }

    /**
     * Objetivo de la prueba: Verificar que la unión se efectúa correctamente.
     * Ficheros de datos necesarios: Los datos se introducen manualmente.
     * Valores Estudiados: Estratègia caja gris. Se crea una instancia de UnionFind, unimos nodos y vemos el resultado.
     * Operativa: Creamos un UnionFind con n = 5, unimos 1 y 0, vemos que se hace y que comparten raíz, volvemos a unirlos y vemos que no se puede.
     */

    @Test
    public void testUnir() {
        UnionFind uf = new UnionFind(5);

        // Unimos 0 y 1
        assertTrue("Unión entre nodos 0 y 1 debe ser exitosa", uf.unir(0, 1));
        assertEquals("0 y 1 deben tener la misma raíz después de la unión", uf.encontrar(0), uf.encontrar(1));

        // Intentamos unir 0 y 1 nuevamente
        assertFalse("Unión redundante no debe ser exitosa", uf.unir(0, 1));
    }

    /**
     * Objetivo de la prueba: Verificar que la unión múltiples veces se efectúa correctamente.
     * Ficheros de datos necesarios: Los datos se introducen manualmente.
     * Valores Estudiados: Estratègia caja gris. Se crea una instancia de UnionFind, unimos nodos varias veces y vemos el resultado.
     * Operativa: Creamos un UnionFind con n = 5, unimos 1 y 0, luego con 2 y nuevamente con 3 y vemos que todos comparten raíz.
     */

    @Test
    public void testEncontrarConCompresion() {
        UnionFind uf = new UnionFind(5);

        // Unimos varios nodos en cadena
        uf.unir(0, 1);
        uf.unir(1, 2);
        uf.unir(2, 3);

        // Verificamos que todos los nodos tienen la misma raíz
        int raiz = uf.encontrar(0);
        for (int i = 1; i <= 3; i++) {
            assertEquals("Todos los nodos deben tener la misma raíz después de unirlos", raiz, uf.encontrar(i));
        }

        // Verificamos que la compresión de ruta funciona
        assertEquals("Padre del nodo 3 debe ser la raíz directamente después de compresión", raiz, uf.encontrar(3));
    }

    /**
     * Objetivo de la prueba: Verificar que la unión se efectúa correctamente.
     * Ficheros de datos necesarios: Los datos se introducen manualmente.
     * Valores Estudiados: Estratègia caja gris. Se crea una instancia de UnionFind, unimos nodos con diferentes conjuntos vemos el resultado.
     * Operativa: Creamos un UnionFind con n = 6, unimos 0 con 1 y 2 con 3 y posteriormente 1 con 3 y vemos que todos comparten raíz.
     */
    @Test
    public void testUnirConRango() {
        UnionFind uf = new UnionFind(6);

        // Unimos 0-1, 2-3 y luego 1-3
        uf.unir(0, 1);
        uf.unir(2, 3);
        uf.unir(1, 3);

        // Verificamos que todos los nodos están conectados
        int raiz = uf.encontrar(0);
        for (int i = 0; i <= 3; i++) {
            assertEquals("Todos los nodos deben tener la misma raíz después de unirlos", raiz, uf.encontrar(i));
        }
    }
}
