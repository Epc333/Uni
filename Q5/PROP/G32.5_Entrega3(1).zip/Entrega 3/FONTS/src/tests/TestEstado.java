package src.tests;

import src.main.domain.classes.Estado;
import org.junit.Test;
import java.util.ArrayList;

import static org.junit.Assert.assertEquals;


/**
 * @author Andres Lucian Laptes Costan (andres.lucian.laptes@estudiantat.upc.edu)
 * */
public class TestEstado {
    /**
     * Objetivo de la prueba: Test de la constructora de Estado pasado por parametros Arrays
     * Archivos de datos necesarios: Datos introducidos manualmente
     * Valores estudiados: Estrategia caja gris, se crea un nuevo objeto Estado y comprobamos que el ID de los productos
     * sean los mismos, y las similitudes entre productos tambien sean los mismos
     * Operativa: Creamos un nuevo estado con ID's puestos a mano (intervalo [0..3]) y con
     * similitudes puestos a mano y comprobamos que sean los mismos.
     */
    @Test
    public void TestConstructoraEstadoParametros() {
        ArrayList<Integer> IDS = new ArrayList<Integer>();
        for (int i = 0; i < 4; i++) IDS.add(i);

        ArrayList<ArrayList<Integer>> Similitudes = new ArrayList<ArrayList<Integer>>();
        int[][] matrix = {
                {-1,2,3,4},
                {2,-1,5,8},
                {3,5,-1,7},
                {4,8,7,-1}
        };

        for (int i = 0; i < 4; ++i) {
            ArrayList<Integer> aux = new ArrayList<>();
            for (int j = 0; j < 4; ++j) {
                aux.add(j, matrix[i][j]);
            }
            Similitudes.add(aux);
        }

        Estado prueba = new Estado(IDS, Similitudes);
        assertEquals("Disitribución diferente de productos",IDS,prueba.getDistribucion());
        assertEquals("Disitribución diferente de similitud",Similitudes,prueba.getSimilitudActual());
    }

    /**
     * Objetivo de la prueba: Test de la constructora de Estado
     * Archivos de datos necesarios: Datos introducidos manualmente
     * Valores estudiados: Estrategia caja gris, se crea un nuevo objeto Estado y comprobamos que el ID de los productos
     * sean los mismos, y las similitudes entre productos tambien sean los mismos
     * Operativa: Creamos un nuevo estado con ID's puestos a mano (intervalo [0..3]) y con
     * similitudes puestos a mano y comprobamos que sean los mismos.
     */
    @Test
    public void TestConstructoraEstado() {
        ArrayList<Integer> IDS = new ArrayList<Integer>();
        for (int i = 0; i < 4; i++) IDS.add(i);

        ArrayList<ArrayList<Integer>> Similitudes = new ArrayList<ArrayList<Integer>>();
        int[][] matrix = {
                {-1,6,3,4},
                {6,-1,7,8},
                {3,7,-1,7},
                {4,8,7,-1}
        };

        for (int i = 0; i < 4; ++i) {
            ArrayList<Integer> aux = new ArrayList<>();
            for (int j = 0; j < 4; ++j) {
                aux.add(j, matrix[i][j]);
            }
            Similitudes.add(aux);
        }

        Estado parametro = new Estado(IDS, Similitudes);
        Estado prueba = new Estado(parametro);

        assertEquals("Disitribución diferente de productos",parametro.getDistribucion(), prueba.getDistribucion());
        assertEquals("Disitribución diferente de similitud",parametro.getSimilitudActual(), prueba.getSimilitudActual());
    }


    /**
     * Objetivo de la prueba: Test de la funcion de getDistribucion
     * Archivos de datos necesarios: Datos introducidos manualmente
     * Valores estudiados: Estrategia caja gris, se crea un nuevo objeto Estado y comprobamos que el ID de los productos
     * sean los mismos. Pasando ID'S y Similitudes como parametro.
     * Operativa: Creamos un nuevo estado con ID's puestos a mano (intervalo [0..3]) y con
     * similitudes puestos a mano y comprobamos que sean los mismos.
     */
    @Test
    public void TestGetDistribucion() {
        ArrayList<Integer> IDS = new ArrayList<Integer>();
        for (int i = 0; i < 4; i++) IDS.add(i);

        ArrayList<ArrayList<Integer>> Similitudes = new ArrayList<ArrayList<Integer>>();
        int[][] matrix = {
                {-1,6,2,4},
                {6,-1,7,1},
                {2,7,-1,7},
                {4,1,7,-1}
        };

        for (int i = 0; i < 4; ++i) {
            ArrayList<Integer> aux = new ArrayList<>();
            for (int j = 0; j < 4; ++j) {
                aux.add(j, matrix[i][j]);
            }
            Similitudes.add(aux);
        }

        Estado prueba = new Estado(IDS, Similitudes);
        assertEquals("ID's diferentes", IDS, prueba.getDistribucion());
    }

    /**
     * Objetivo de la prueba: Test de la funcion de getSimilitudesActual
     * Archivos de datos necesarios: Datos introducidos manualmente
     * Valores estudiados: Estrategia caja gris, se crea un nuevo objeto Estado y comprobamos que Similitudes de los productos
     * sean los mismos. Pasando ID'S y Similitudes como parametro.
     * Operativa: Creamos un nuevo estado con ID's puestos a mano (intervalo [0..3]) y con
     * similitudes puestos a mano y comprobamos que sean los mismos.
     */
    @Test
    public void TestGetSimilitudActual() {
        ArrayList<Integer> IDS = new ArrayList<Integer>();
        for (int i = 0; i < 4; i++) IDS.add(i);

        ArrayList<ArrayList<Integer>> Similitudes = new ArrayList<ArrayList<Integer>>();
        int[][] matrix = {
                {-1,3,2,4},
                {3,-1,4,1},
                {2,4,-1,5},
                {4,1,5,-1}
        };

        for (int i = 0; i < 4; ++i) {
            ArrayList<Integer> aux = new ArrayList<>();
            for (int j = 0; j < 4; ++j) {
                aux.add(j, matrix[i][j]);
            }
            Similitudes.add(aux);
        }

        Estado prueba = new Estado(IDS, Similitudes);
        assertEquals("Similitudes diferentes", Similitudes, prueba.getSimilitudActual());
    }

    /**
     * Objetivo de la prueba: Test de la funcion de Swap
     * Archivos de datos necesarios: Datos introducidos manualmente
     * Valores estudiados: Estrategia caja gris, se crea un nuevo objeto Estado y comprobamos que distribucion de los productos
     * sean los mismos. Pasando ID'S y Similitudes como parametro.
     * Operativa: Creamos 4 nuevos estado con ID's puestos a mano (intervalo [0..3]) y con
     * similitudes puestos a mano y comprobamos, el primero es uno elegido arbitrariamente.
     * El segundo sera intercambiando la posicion [3] con [2] de la primera.
     * El tercero sera intercambiando la posicion [2] con [0] de la segundo.
     * El cuarto sera intercambiando la posicion [0] con [3] de la tercera.
     */
    @Test
    public void TestSwap() {
        ArrayList<Integer> IDS = new ArrayList<Integer>();
        for (int i = 0; i < 4; i++) IDS.add(i);

        ArrayList<ArrayList<Integer>> Similitudes = new ArrayList<ArrayList<Integer>>();
        int[][] matrix = {
                {-1,3,2,4},
                {3,-1,4,1},
                {2,4,-1,5},
                {4,1,5,-1}
        };

        for (int i = 0; i < 4; ++i) {
            ArrayList<Integer> aux = new ArrayList<>();
            for (int j = 0; j < 4; ++j) {
                aux.add(j, matrix[i][j]);
            }
            Similitudes.add(aux);
        }

        Estado prueba = new Estado(IDS, Similitudes);

        prueba.swap(3, 2);
        int[] result1 = {0,1,3,2};
        ArrayList<Integer> result2 = new ArrayList<>();
        for (int i = 0; i < 4; ++i) result2.add(result1[i]);
        assertEquals("No funciona primer swap", result2, prueba.getDistribucion());

        prueba.swap(0, 2);
        int[] result3 = {3,1,0,2};
        ArrayList<Integer> result4 = new ArrayList<>();
        for (int i = 0; i < 4; ++i) result4.add(result3[i]);
        assertEquals("No funciona segundo swap", result4, prueba.getDistribucion());

        prueba.swap(0,3);
        int[] result5 = {2,1,0,3};
        ArrayList<Integer> result6 = new ArrayList<>();
        for (int i = 0; i < 4; ++i) result6.add(result5[i]);
        assertEquals("No funciona tercer swap", result6, prueba.getDistribucion());
    }

    /**
     * Objetivo de la prueba: Test de la funcion de getIDProducto
     * Archivos de datos necesarios: Datos introducidos manualmente
     * Valores estudiados: Estrategia caja gris, se crea un nuevo objeto Estado y comprobamos que la ID del producto
     * sea el mismos. Pasando ID'S y Similitudes como parametro.
     * Operativa: Creamos un nuevo estado con ID's puestos a mano (intervalo [0..3]) y con
     * similitudes puestos a mano y comprobamos que el producto de la posición [3] y [4] sean el mismo que el introducido.
     */
    @Test
    public void TestGetIdProducto() {
        ArrayList<Integer> IDS = new ArrayList<Integer>();
        for (int i = 0; i < 4; i++) IDS.add(i);

        ArrayList<ArrayList<Integer>> Similitudes = new ArrayList<ArrayList<Integer>>();
        int[][] matrix = {
                {-1,3,2,4},
                {3,-1,4,1},
                {2,4,-1,5},
                {4,1,5,-1}
        };

        for (int i = 0; i < 4; ++i) {
            ArrayList<Integer> aux = new ArrayList<>();
            for (int j = 0; j < 4; ++j) {
                aux.add(j, matrix[i][j]);
            }
            Similitudes.add(aux);
        }

        Estado prueba = new Estado(IDS, Similitudes);
        assertEquals("ID's diferentes", 2, prueba.getIDProducto(2));
        assertEquals("ID's diferentes", 3, prueba.getIDProducto(3));
    }

    /**
     * Objetivo de la prueba: Test de la funcion de getNumeroDeProducto
     * Archivos de datos necesarios: Datos introducidos manualmente
     * Valores estudiados: Estrategia caja gris, se crea un nuevo objeto Estado y comprobamos que hay la misma cantidad de productos
     * pasando ID'S y Similitudes como parametro.
     * Operativa: Creamos un nuevo estado con ID's puestos a mano (intervalo [0..3]) y con
     * similitudes puestos a mano y comprobamos haya 5 ID's.
     */
    @Test
    public void TestGetNumeroDeProductos() {
        ArrayList<Integer> IDS = new ArrayList<Integer>();
        for (int i = 0; i < 4; i++) IDS.add(i);

        ArrayList<ArrayList<Integer>> Similitudes = new ArrayList<ArrayList<Integer>>();
        int[][] matrix = {
                {-1,3,2,4},
                {3,-1,4,1},
                {2,4,-1,5},
                {4,1,5,-1}
        };

        for (int i = 0; i < 4; ++i) {
            ArrayList<Integer> aux = new ArrayList<>();
            for (int j = 0; j < 4; ++j) {
                aux.add(j, matrix[i][j]);
            }
            Similitudes.add(aux);
        }

        Estado prueba = new Estado(IDS, Similitudes);
        assertEquals("Diferente numero de Productos", 4, prueba.getNumeroProductos());
    }

    /**
     * Objetivo de la prueba: Test de la funcion de getSimilitudProductos
     * Archivos de datos necesarios: Datos introducidos manualmente
     * Valores estudiados: Estrategia caja gris, se crea un nuevo objeto Estado y comprobamos que hay la misma similitud
     * pasando ID'S y Similitudes como parametro.
     * Operativa: Creamos un nuevo estado con ID's puestos a mano (intervalo [0..3]) y con
     * similitudes puestos a mano y comprobamos que la similitud de la posicion [1][2] y [2][1] sean la misma ademas que [i][j] sea -1.
     */
    @Test
    public  void TestGetSimilitudProductos() {
        ArrayList<Integer> IDS = new ArrayList<Integer>();
        for (int i = 0; i <4; i++) IDS.add(i);

        ArrayList<ArrayList<Integer>> Similitudes = new ArrayList<ArrayList<Integer>>();
        int[][] matrix = {
                {-1,3,2,4},
                {3,-1,4,1},
                {2,4,-1,5},
                {4,1,5,-1}
        };

        for (int i = 0; i < 4; ++i) {
            ArrayList<Integer> aux = new ArrayList<>();
            for (int j = 0; j < 4; ++j) {
                aux.add(j, matrix[i][j]);
            }
            Similitudes.add(aux);
        }

        Estado prueba = new Estado(IDS, Similitudes);
        assertEquals("Diferente Similitud entre Productos", 4, prueba.getSimilitudProductos(1,2));
        assertEquals("Diferente Similitud entre Productos", 4, prueba.getSimilitudProductos(2,1));
        for (int i = 0; i < 4; ++i) {
            for (int j = 0; j < 4; ++j) {
                if (i == j) assertEquals("Diferente Similitud entre Productos", -1, prueba.getSimilitudProductos(i,j));
            }
        }
    }
}
