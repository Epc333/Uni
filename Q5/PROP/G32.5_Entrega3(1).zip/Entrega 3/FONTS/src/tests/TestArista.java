package src.tests;

import src.main.domain.classes.functions.Arista;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

/**
 * Clase con tests para Arista.
 * @author Asier García Elvira (asier.garcia@estudiantat.upc.edu)
 */
public class TestArista {

    /**
     * Objetivo de la prueba: Verificar que el constructor de la calse Arista incializa correctamente los atributos
     * Ficheros de datos necesarios: Los datos se introducen manualmente.
     * Valores Estudiados: Estratègia caja gris. Se crea una instancia de Arista y comprobamos que sus atributos sean los correctos.
     * Operativa: Creamos una Arista con desde = 1, hasta = 2 y peso = 10 y vemos que los getters devuelvan esos valores.
     */

    @Test
    public void testConstructor() {
        int desde = 1;
        int hasta = 2;
        int peso = 10;

        // Crear la arista
        Arista arista = new Arista(desde, hasta, peso);

        // Verificar valores inicializados
        assertEquals("El atributo 'desde' no se inicializó correctamente", desde, arista.getDesde());
        assertEquals("El atributo 'hasta' no se inicializó correctamente", hasta, arista.getHasta());
        assertEquals("El atributo 'peso' no se inicializó correctamente", peso, arista.getPeso());
    }

    /**
     * Objetivo de la prueba: Verificar que el constructor de la calse Producto incializa correctamente los atributos con valores negativos
     * Ficheros de datos necesarios: Los datos se introducen manualmente.
     * Valores Estudiados: Estratègia caja gris. Se crea una instancia de Arista y comprobamos que sus atributos sean los correctos.
     * Operativa: Creamos una Arista con desde = -1, hasta = -5 y peso = -10 y vemos que los getters devuelvan esos valores.
     */
    @Test
    public void testValoresNegativos() {
        int desde = -1;
        int hasta = -5;
        int peso = -10;

        // Crear la arista
        Arista arista = new Arista(desde, hasta, peso);

        // Verificar valores inicializados
        assertEquals("El atributo 'desde' no se inicializó correctamente con un valor negativo", desde, arista.getDesde());
        assertEquals("El atributo 'hasta' no se inicializó correctamente con un valor negativo", hasta, arista.getHasta());
        assertEquals("El atributo 'peso' no se inicializó correctamente con un valor negativo", peso, arista.getPeso());
    }

    /**
     * Objetivo de la prueba: Verificar que el constructor de la calse Producto incializa correctamente los atributos con valores límite.
     * Ficheros de datos necesarios: Los datos se introducen manualmente.
     * Valores Estudiados: Estratègia caja gris. Se crea una instancia de producto y comprobamos que sus atributos sean los correctos.
     * Operativa: Creamos una Arista con desde = MIN_VALUE, desde = MAX_VALUE y peso = 0 y vemos que los getters lo devuelvan.
     */
    @Test
    public void testValoresExtremos() {
        int desde = Integer.MIN_VALUE;
        int hasta = Integer.MAX_VALUE;
        int peso = 0;

        // Crear la arista
        Arista arista = new Arista(desde, hasta, peso);

        // Verificar valores inicializados
        assertEquals("El atributo 'desde' no se inicializó correctamente con un valor extremo", desde, arista.getDesde());
        assertEquals("El atributo 'hasta' no se inicializó correctamente con un valor extremo", hasta, arista.getHasta());
        assertEquals("El atributo 'peso' no se inicializó correctamente con un valor extremo", peso, arista.getPeso());
    }
}