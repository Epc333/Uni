package src.tests;

import src.main.domain.classes.Similitud;
import src.main.domain.classes.Producto;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class TestSimilitud {

    @Test
    public void testDefaultConstructor() {
        Similitud similitud = new Similitud();
        assertNull(similitud.getProcentaje_similitud());
        assertNull(similitud.getProducto());
    }

    @Test
    public void testParameterizedConstructor() {
        Producto product = new Producto(1,"Naranja", 2.5);
        Similitud similitud = new Similitud(product, 80);
        assertEquals(80, similitud.getProcentaje_similitud());
        assertEquals(product, similitud.getProducto());
    }

    @Test
    public void testCopyConstructor() {
        Producto product = new Producto(1,"Naranja", 2.5);
        Similitud original = new Similitud(product, 80);
        Similitud copy = new Similitud(original);
        assertEquals(original.getProcentaje_similitud(), copy.getProcentaje_similitud());
        assertEquals(original.getProducto(), copy.getProducto());
    }

    @Test
    public void testModificarSimilitud() {
        Similitud similitud = new Similitud();
        similitud.modificarSimilitud(90);
        assertEquals(90, similitud.getProcentaje_similitud());
    }

    @Test
    public void testEliminarSimilitud() {
        Producto product = new Producto(1,"Naranja", 2.5);
        Similitud similitud = new Similitud(product, 80);
        similitud.eliminarSimilitud();
        assertNull(similitud.getProcentaje_similitud());
        assertNull(similitud.getProducto());
    }
}