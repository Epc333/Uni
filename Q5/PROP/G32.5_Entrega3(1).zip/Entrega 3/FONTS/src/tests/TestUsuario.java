package src.tests;

import org.junit.Test;
import src.main.domain.classes.Usuario;

import static org.junit.Assert.assertEquals;


/**
 * @author Andres Lucian Laptes Costan (andres.lucian.laptes@estudiantat.upc.edu)
 * */
public class TestUsuario {
    /**
     * Objetivo de la prueba: Test de la constructora de Usuario pasado por parametros los datos necesarios
     * Archivos de datos necesarios: niguno los datos son enviados a mano
     * Valores estudiados: Estrategia caja gris, se crea un nuevo objeto Usuario y comprobamos que el nombre, contraseña,
     * mail y idioma son correctos
     * Operativa: creamos el nuevo Usuario y comprovamos que los datos almacenados sean los mismos que los pasados
     */
    @Test
    public void TestContructora() {
        String nombre = "Raul";
        String contrasena = "RaulElMasGuay122??";
        String correo = "raul.rodigrez.estudiantat.upc.edu";
        String Idioma = "Castellano";
        Usuario prueba = new Usuario(nombre, contrasena, correo, Idioma);
        assertEquals("Nombre incorrecto", nombre, prueba.getName());
        assertEquals("Contraseña incorrecta", contrasena, prueba.getContraseña());
        assertEquals("CorreoIncorrecto", correo, prueba.getEmail());
        assertEquals("Idioma incorrecto", Idioma, prueba.getIdiomaActual());
    }

    /**
     * Objetivo de la prueba: Test de la constructora de Usuario pasado por parametros otro usuario, es decir, hacer una copia profunda
     * Archivos de datos necesarios: niguno los datos son enviados a mano
     * Valores estudiados: Estrategia caja gris, se crea dos nuevo objeto Usuario y comprobamos que el nombre, contraseña,
     * mail y idioma son correctos al de la copia
     * Operativa: creamos el nuevo Usuario y el segundo lo creamos pasando
     * por parametro el primero y comprovamos que los datos almacenados sean los mismos para los dos
     */
    @Test
    public void TestContructora2() {
        String nombre = "Raul";
        String contrasena = "RaulElMasGuay122??";
        String correo = "raul.rodigrez.upc.edu";
        String Idioma = "Castellano";

        Usuario a = new Usuario(nombre, contrasena, correo, Idioma);
        Usuario b = new Usuario(a);
        assertEquals("Nombre incorrecto", a.getName(), b.getName());
        assertEquals("Contraseña incorrecta", a.getContraseña(), b.getContraseña());
        assertEquals("CorreoIncorrecto", a.getEmail(), b.getEmail());
        assertEquals("Idioma incorrecto", a.getIdiomaActual(), b.getIdiomaActual());
    }

    /**
     * Objetivo de la prueba: Test de la funcion getContraseña
     * Archivos de datos necesarios: niguno los datos son enviados a mano
     * Valores estudiados: Estrategia caja gris, se crea un nuevo objeto Usuario y comprobamos que la contraseña son iguales
     * Operativa: creamos el nuevo Usuario y el segundo lo creamos pasando por parametro los datos
     * y comprovamos que la contraseña sea la misma
     */
    @Test
    public void TestGetContraseña() {
        String nombre = "Raul";
        String contrasena = "RaulElMasGuay122??";
        String correo = "raul.rodigrez.upc.edu";
        String Idioma = "Castellano";

        Usuario a = new Usuario(nombre, contrasena, correo, Idioma);
        assertEquals("Contraseña incorrecta", contrasena, a.getContraseña());
    }

    /**
     * Objetivo de la prueba: Test de la funcion getNombre
     * Archivos de datos necesarios: ninguno, los datos son enviados a mano
     * Valores estudiados: Estrategia caja gris, se crea un nuevo objeto Usuario y comprobamos que el nombre es igual
     * Operativa: creamos un nuevo Usuario y comprobamos que el nombre sea el mismo que el pasado como parámetro
     */
    @Test
    public void TestGetNombre() {
        String nombre = "Raul";
        String contrasena = "RaulElMasGuay122??";
        String correo = "raul.rodigrez.upc.edu";
        String idioma = "Castellano";

        Usuario a = new Usuario(nombre, contrasena, correo, idioma);
        assertEquals("Nombre incorrecto", nombre, a.getName());
    }

    /**
     * Objetivo de la prueba: Test de la funcion getEmail
     * Archivos de datos necesarios: ninguno, los datos son enviados a mano
     * Valores estudiados: Estrategia caja gris, se crea un nuevo objeto Usuario y comprobamos que el correo es igual
     * Operativa: creamos un nuevo Usuario y comprobamos que el correo sea el mismo que el pasado como parámetro
     */
    @Test
    public void TestGetEmail() {
        String nombre = "Raul";
        String contrasena = "RaulElMasGuay122??";
        String correo = "raul.rodigrez.upc.edu";
        String idioma = "Castellano";

        Usuario a = new Usuario(nombre, contrasena, correo, idioma);
        assertEquals("Email incorrecto", correo, a.getEmail());
    }

    /**
     * Objetivo de la prueba: Test de la funcion getIdiomaActual
     * Archivos de datos necesarios: ninguno, los datos son enviados a mano
     * Valores estudiados: Estrategia caja gris, se crea un nuevo objeto Usuario y comprobamos que el idioma es igual
     * Operativa: creamos un nuevo Usuario y comprobamos que el idioma sea el mismo que el pasado como parámetro
     */
    @Test
    public void TestGetIdiomaActual() {
        String nombre = "Raul";
        String contrasena = "RaulElMasGuay122??";
        String correo = "raul.rodigrez.upc.edu";
        String idioma = "Castellano";

        Usuario a = new Usuario(nombre, contrasena, correo, idioma);
        assertEquals("Idioma incorrecto", idioma, a.getIdiomaActual());
    }

    /**
     * Objetivo de la prueba: Test de la funcion modificarNombre
     * Archivos de datos necesarios: ninguno, los datos son enviados a mano
     * Valores estudiados: Estrategia caja gris, se modifica el nombre de un objeto Usuario y comprobamos que el cambio sea efectivo
     * Operativa: creamos un Usuario, modificamos el nombre y comprobamos que el nuevo nombre se haya aplicado
     */
    @Test
    public void TestModificarNombre() {
        String nombreInicial = "Raul";
        String nuevoNombre = "Carlos";
        String contrasena = "RaulElMasGuay122??";
        String correo = "raul.rodigrez.upc.edu";
        String idioma = "Castellano";

        Usuario a = new Usuario(nombreInicial, contrasena, correo, idioma);
        a.modificarNombre(nuevoNombre);
        assertEquals("El nombre no se ha modificado correctamente", nuevoNombre, a.getName());
    }

    /**
     * Objetivo de la prueba: Test de la funcion modificarContraseña
     * Archivos de datos necesarios: ninguno, los datos son enviados a mano
     * Valores estudiados: Estrategia caja gris, se modifica la contraseña de un objeto Usuario y comprobamos que el cambio sea efectivo
     * Operativa: creamos un Usuario, modificamos la contraseña y comprobamos que la nueva contraseña se haya aplicado
     */
    @Test
    public void TestModificarContraseña() {
        String nombre = "Raul";
        String contrasenaInicial = "RaulElMasGuay122??";
        String nuevaContrasena = "NuevaContraseña987!!";
        String correo = "raul.rodigrez.upc.edu";
        String idioma = "Castellano";

        Usuario a = new Usuario(nombre, contrasenaInicial, correo, idioma);
        a.modificarContraseña(nuevaContrasena);
        assertEquals("La contraseña no se ha modificado correctamente", nuevaContrasena, a.getContraseña());
    }

    /**
     * Objetivo de la prueba: Test de la funcion modificarEmail
     * Archivos de datos necesarios: ninguno, los datos son enviados a mano
     * Valores estudiados: Estrategia caja gris, se modifica el email de un objeto Usuario y comprobamos que el cambio sea efectivo
     * Operativa: creamos un Usuario, modificamos el email y comprobamos que el nuevo email se haya aplicado
     */
    @Test
    public void TestModificarEmail() {
        String nombre = "Raul";
        String contrasena = "RaulElMasGuay122??";
        String correoInicial = "raul.rodigrez.upc.edu";
        String nuevoCorreo = "carlos.romero@upc.edu";
        String idioma = "Castellano";

        Usuario a = new Usuario(nombre, contrasena, correoInicial, idioma);
        a.modificarEmail(nuevoCorreo);
        assertEquals("El correo no se ha modificado correctamente", nuevoCorreo, a.getEmail());
    }

    /**
     * Objetivo de la prueba: Test de la funcion modificarIdioma
     * Archivos de datos necesarios: ninguno, los datos son enviados a mano
     * Valores estudiados: Estrategia caja gris, se modifica el idioma de un objeto Usuario y comprobamos que el cambio sea efectivo
     * Operativa: creamos un Usuario, modificamos el idioma y comprobamos que el nuevo idioma se haya aplicado
     */
    @Test
    public void TestModificarIdioma() {
        String nombre = "Raul";
        String contrasena = "RaulElMasGuay122??";
        String correo = "raul.rodigrez.upc.edu";
        String idiomaInicial = "Castellano";
        String nuevoIdioma = "Ingles";

        Usuario a = new Usuario(nombre, contrasena, correo, idiomaInicial);
        a.modificarIdioma(nuevoIdioma);
        assertEquals("El idioma no se ha modificado correctamente", nuevoIdioma, a.getIdiomaActual());
    }
}
