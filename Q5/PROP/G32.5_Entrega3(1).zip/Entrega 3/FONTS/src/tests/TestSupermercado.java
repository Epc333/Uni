package src.tests;

import src.main.domain.classes.Supermercado;
import src.main.domain.classes.Producto;

import java.util.*;
import java.util.ArrayList;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * @author Vinyet Granda Planas (vinyet.granda@estudiantat.upc.edu)
 */

public class TestSupermercado {

    private Supermercado s;
    private ArrayList<Producto> productos;

    @Before
    public void setUp() {
        s = new Supermercado("central", 3);
    }

    /**
     * Objetivo de la prueba: Verificar que el constructor de la calse Supermercado incializa correctamente los atributos
     * Ficheros de datos necesarios: Los datos se introducen manualmente.
     * Valores Estudiados: Estratègia caja gris. Tenemos una instancia de supermeercado y comprobamos que sus atributos sean los correctos.
     * Operativa: Creamos un producto "Naranja" con un precio de 1.5, cambiamos el nombre y comporbamos que el getter debuelve el cambio.
     */
    @Test
    public void TestConstructoraGetters() {
        assertEquals("central", s.getNombre());
        assertEquals(3, s.getN_estanterias());
        assertNotNull(s.getFecha());
        assertTrue(new Date().getTime() - s.getFecha().getTime() < 1000);
    }

    /**
     * Objetivo de la prueba: Verificar que se agrega el producto
     * Ficheros de datos necesarios: Los datos se introducen manualmente.
     * Valores Estudiados: Estratègia caja gris. Creamos dos instancias de producto y las añadimos al supermercado
     * Operativa: Creamos dos productos y comprobamos que se han añadido correctamente
     */
    @Test
    public void testAgregaProducto() {
        s.agregarProducto(new Producto(1, "Naranja", 1.5));
        s.agregarProducto(new Producto(2, "Manzana", 2.5));
        assertEquals(3, s.getN_estanterias());
        assertTrue(s.getIdentificadores().contains(2));
    }

    /**
     * Objetivo de la prueba: Verificar que se han eliminado los Productos
     * Ficheros de datos necesarios: Los datos se introducen manualmente.
     * Valores Estudiados: Estratègia caja gris. Creamos dos instancias de producto, las añadimos y los eliminamos del supermercado
     * Operativa: Creamos dos productos, eliminamos uno y comprobamos que el otro sigue en el supermercado
     */
    @Test
    public void testEliminarProducto() {
        s.agregarProducto(new Producto(1, "Naranja", 1.5));
        s.agregarProducto(new Producto(2, "Manzana", 2.5));
        s.eliminarProducto("Naranja");
        assertFalse(s.getIdentificadores().contains(2));
    }

    /**
     * Objetivo de la prueba: Verificar que se debuleve la estanteria correcta
     * Ficheros de datos necesarios: Los datos se introducen manualmente.
     * Valores Estudiados: Estratègia caja gris. Creamos dos instancias de producto y las añadimos al supermercado
     * Operativa: Creamos dos productos, buscamos la estanteria del segundo y comporbamos que es la correcta
     */
    @Test
    public void testGetEstanteria() {
        s.agregarProducto(new Producto(1, "Naranja", 1.5));
        s.agregarProducto(new Producto(2, "Manzana", 2.5));
        assertNotNull(s.getEstanteria("Manzana"));
    }

    /**
     * Objetivo de la prueba: Verificar que la posicion dentro de la estanteria es la correcta
     * Ficheros de datos necesarios: Los datos se introducen manualmente.
     * Valores Estudiados: Estratègia caja gris. Creamos dos instancias de producto y las añadimos al supermercado
     * Operativa: Creamos productos, buscamos la posicion y comporbamos que es la correcta
     */
    @Test
    public void testGetPosicionEstanteria(){
        s.agregarProducto(new Producto(1, "Naranja", 1.5));
        s.agregarProducto(new Producto(2, "Manzana", 2.5));
        assertEquals(Optional.of(1), s.getPosicionEstanteria("Manzana"));
    }

    /**
     * Objetivo de la prueba: Verificar que se eliminan todos los datos
     * Ficheros de datos necesarios: Los datos se introducen manualmente.
     * Valores Estudiados: Estratègia caja gris. Creamos un producto y lo añadimos al supermercado
     * Operativa: Creamos un producto, limpiamos todos los datos del supermercado y lo comprobamos
     */
    @Test
    public void testLimpiarDatos() {
        s.agregarProducto(new Producto(1, "Naranja", 1.5));
        s.limpiarDatos();
        assertTrue(s.getDistribucionActual().isEmpty());
        assertTrue(s.getIdentificadores().isEmpty());
    }

    /**
     * Objetivo de la prueba: Verificar que se determina correctamente si el valor de la estanteria es correcto
     * Ficheros de datos necesarios: Los datos se introducen manualmente.
     * Valores Estudiados: Estratègia caja gris.
     * Operativa: Comprobamos que nos debuelve los valores correctos
     */
    @Test
    public void testValidEstanteria() {
        assertTrue(s.validEstanteria(0));
        assertFalse(s.validEstanteria(5));
    }

    /**
     * Objetivo de la prueba: Verificar que cambia el nombre correctamente
     * Ficheros de datos necesarios: Los datos se introducen manualmente.
     * Valores Estudiados: Estratègia caja gris.
     * Operativa: Modificamos el nombre del supermercado y comprobamos que se ha modificado
     */
    @Test
    public void testModificarNombre() {
        s.modificarNombre("Sucursal");
        assertEquals("Sucursal", s.getNombre());
    }
}