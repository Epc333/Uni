package src.tests;

import src.main.domain.classes.Producto;

import static org.junit.Assert.*;
import org.junit.Test;

import java.util.Optional;

/**
 * @author Vinyet Granda Planas (vinyet.granda@estudiantat.upc.edu)
 */
public class TestProducto {

    /**
     * Objetivo de la prueba: Verificar que el constructor de la calse Producto incializa correctamente los atributos
     * Ficheros de datos necesarios: Los datos se introducen manualmente.
     * Valores Estudiados: Estratègia caja gris. Se crea una instancia de producto y comprobamos que sus atributos sean los correctos.
     * Operativa: Creamos un producto "Naranja" con un precio de 1.5 y comporbamos que los getter debuelven lo mismo
     */
    @Test
    public void TestConstructoraGetters() {
        Producto p = new Producto(1,"Naranja", 1.50);
        assertEquals("Naranja", p.getNombre());
        assertEquals( 1.50, p.getPrecio(), 0);
        assertTrue(p.getSimilitudes().isEmpty());
    }

    /**
     * Objetivo de la prueba: Verificar que la fucnion cambia correctamente el nombre del producto.
     * Ficheros de datos necesarios: Los datos se introducen manualmente.
     * Valores Estudiados: Estratègia caja gris. Se crea una instancia de producto, la modificamos y comprobamos que sus atributos sean los correctos.
     * Operativa: Creamos un producto "Naranja" con un precio de 1.5, cambiamos el nombre y comporbamos que el getter debuelve el cambio.
     */
    @Test
    public void TestModificarNombre() {
        Producto p = new Producto(1,"Naranja", 1.50);
        p.modificarNombre("Manzana");
        assertEquals("Manzana", p.getNombre());
    }


    /**
     * Objetivo de la prueba: Verificar que la fucnion cambia correctamente el precio del producto
     * Ficheros de datos necesarios: Los datos se introducen manualmente.
     * Valores Estudiados: Estratègia caja gris. Se crea una instancia de producto, modificamos y comprobamos que sus atributos sean los correctos.
     * Operativa: Creamos un producto "Naranja" con un precio de 1.5 cambiamos el precio y comporbamos que el getter debuelve el cambio.
     */
    @Test
    public void TestModificarPrecio() {
        Producto p = new Producto(1,"Naranja", 1.50);
        p.modificarPrecio(2.50);
        assertEquals( 2.50, p.getPrecio(), 0);
    }

    /**
     * Objetivo de la prueba: Verificar que se añade correctamente una similitud entre dos productos y se guarda en la lista de similitudes
     * Ficheros de datos necesarios: Los datos se introducen manualmente.
     * Valores Estudiados: Estratègia caja gris. Se crean dos instancias de producto y una de similitud
     * Operativa: Creamos los productos y la similitud y comprobamos que se ha creado correctamente
     */
    @Test
    public void testAnadirSimilitud(){
        Producto p = new Producto(1,"Naranja", 1.50);
        Producto p2 = new Producto(2,"Manzana", 2.50);
        p.anadirSimilitud(p2, 75);
        assertEquals(1, p.getSimilitudes().size());
        assertEquals(Optional.of(75), p.getSimilitudes().get(0).getProcentaje_similitud());
        assertEquals(p2, p.getSimilitudes().get(0).getProducto());
    }

    /**
     * Objetivo de la prueba: Verificar que se elimina correctamente una similitud entre dos productos y que esta se actualiza la lista de similitudes.
     * Ficheros de datos necesarios: Los datos se introducen manualmente.
     * Valores Estudiados: Estratègia caja gris. Se crean dos instancias de producto y una de similitud
     * Operativa: Creamos los productos y la similitud, la eliminamos y comprobamos que ya no existe en la lista
     */
    @Test
    public void testEliminarSimilitud(){
        Producto p = new Producto(1,"Naranja", 1.50);
        Producto p2 = new Producto(2,"Manzana", 2.50);
        p.anadirSimilitud(p2, 75);
        p.eliminaSimilitud(p2);
        assertTrue(p.getSimilitudes().isEmpty());
    }

    /**
     * Objetivo de la prueba: Verificar que se modifica correctamente una similitud entre dos productos y que esta se actualiza la lista de similitudes.
     * Ficheros de datos necesarios: Los datos se introducen manualmente.
     * Valores Estudiados: Estratègia caja gris. Se crean dos instancias de producto y una de similitud
     * Operativa: Creamos los productos y la similitud, la modificamos y comprobamos que es correcto
     */
    @Test
    public void testModificarSimilitud(){
        Producto p = new Producto(1,"Naranja", 1.50);
        Producto p2 = new Producto(2,"Manzana", 2.50);
        p.anadirSimilitud(p2, 75);
        p.modificarSimilitud(p2, 90);
        assertEquals(Optional.of(90), p.getSimilitudes().get(0).getProcentaje_similitud());
    }
}