package src.tests;

import src.main.domain.classes.Estanteria;
import src.main.domain.classes.Producto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;


public class TestEstanteria {
    private Estanteria estanteria;
    private Producto producto1;
    private Producto producto2;

    @BeforeEach
    public void setUp() {
        estanteria = new Estanteria();
        producto1 = new Producto(1,"Producto1", 10.0);
        producto2 = new Producto(2,"Producto2", 20.0);
    }

    @Test
    public void testConstructor() {
        assertNotNull(estanteria);
        assertEquals(0, estanteria.getNumeroDeProductos());
    }

    @Test
    public void testAgregarProducto() {
        estanteria.agregarProducto(producto1);
        assertEquals(1, estanteria.getNumeroDeProductos());
        assertEquals(producto1, estanteria.getProducto(0));
    }

    @Test
    public void testInsertProducto() {
        estanteria.agregarProducto(producto1);
        estanteria.insertProducto(0, producto2);
        assertEquals(2, estanteria.getNumeroDeProductos());
        assertEquals(producto2, estanteria.getProducto(0));
    }

    @Test
    public void testReplace() {
        estanteria.agregarProducto(producto1);
        estanteria.replace(0, producto2);
        assertEquals(1, estanteria.getNumeroDeProductos());
        assertEquals(producto2, estanteria.getProducto(0));
    }

    @Test
    public void testRemoveProducteByObject() {
        estanteria.agregarProducto(producto1);
        estanteria.removeProducte(producto1);
        assertEquals(0, estanteria.getNumeroDeProductos());
    }

    @Test
    public void testRemoveProducteByIndex() {
        estanteria.agregarProducto(producto1);
        estanteria.removeProducte(0);
        assertEquals(0, estanteria.getNumeroDeProductos());
    }

    @Test
    public void testGetProductos() {
        estanteria.agregarProducto(producto1);
        estanteria.agregarProducto(producto2);
        ArrayList<Producto> productos = estanteria.getProductos();
        assertEquals(2, productos.size());
        assertTrue(productos.contains(producto1));
        assertTrue(productos.contains(producto2));
    }

    @Test
    public void testLimpiarDatos() {
        estanteria.agregarProducto(producto1);
        estanteria.limpiarDatos();
        assertEquals(0, estanteria.getNumeroDeProductos());
    }
}