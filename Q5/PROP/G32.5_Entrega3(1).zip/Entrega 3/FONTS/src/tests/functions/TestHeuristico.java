package src.tests.functions;

import src.main.domain.classes.Estado;

import src.main.domain.classes.functions.Heuristico;
import org.junit.Test;
import java.util.ArrayList;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;


/**
 * @author Andres Lucian Laptes Costan (andres.lucian.laptes@estudiantat.upc.edu)
 * */
public class TestHeuristico {
    /**
     * Objetivo de la prueba: Test de la constructora de la clase
     * Archivos de datos necesarios: Datos introducidos manualmente
     * Valores estudiados: Estrategia caja gris, se crea un nuevo objeto Estado y Heuristico que pasaremos por
     * parametro el objeto Estado
     * Operativa: Creamos un nuevo estado con ID's puestos a mano (intervalo [0..4]) y con
     * similitudes puestos a mano y comprobamos que el calculo del Heuristico de ese estado es el
     * esperado.
     */
    @Test
    public void TestConstructoraHeuristico() {
        ArrayList<Integer> IDS = new ArrayList<Integer>();
        for (int i = 0; i < 4; i++) IDS.add(i);

        ArrayList<ArrayList<Integer>> Similitudes = new ArrayList<ArrayList<Integer>>();
        int[][] matrix = {
                {-1,3,2,4},
                {3,-1,4,1},
                {2,4,-1,5},
                {4,1,5,-1}
        };

        for (int i = 0; i < 4; ++i) {
            ArrayList<Integer> aux = new ArrayList<>();
            for (int j = 0; j < 4; ++j) {
                aux.add(j, matrix[i][j]);
            }
            Similitudes.add(aux);
        }

        Estado act = new Estado(IDS, Similitudes);
        Heuristico prueba = new Heuristico(act);
        assertEquals("El calculo del Heuristico no es el esperado", 32, prueba.getValue());
    }


    /**
     * Objetivo de la prueba: Test de la funcion getValue
     * Archivos de datos necesarios: Datos introducidos manualmente
     * Valores estudiados: Estrategia caja gris, se crea un nuevo objeto Estado y Heuristico que pasaremos por
     * parametro el objeto Estado al Heuristico
     * Operativa: Creamos un nuevo estado con ID's puestos a mano (intervalo [0..4]) y con
     * similitudes puestos a mano y comprobamos que el calculo del Heuristico de ese estado es el
     * esperado utilizando la funcion getValue.
     */
    @Test
    public void TestGetValue() {
        ArrayList<Integer> IDS = new ArrayList<Integer>();
        for (int i = 3; i >= 0; --i) IDS.add(i);

        ArrayList<ArrayList<Integer>> Similitudes = new ArrayList<ArrayList<Integer>>();
        int[][] matrix = {
                {-1,3,2,4},
                {3,-1,4,1},
                {2,4,-1,5},
                {4,1,5,-1}
        };

        for (int i = 0; i < 4; ++i) {
            ArrayList<Integer> aux = new ArrayList<>();
            for (int j = 0; j < 4; ++j) {
                aux.add(j, matrix[i][j]);
            }
            Similitudes.add(aux);
        }

        Estado act = new Estado(IDS, Similitudes);
        Heuristico prueba = new Heuristico(act);
        assertEquals("El calculo del Heuristico no es el esperado utilizando getValue", 32, prueba.getValue());
    }


    /**
     * Objetivo de la prueba: Test de la funcion isLower
     * Archivos de datos necesarios: Datos introducidos manualmente
     * Valores estudiados: Estrategia caja gris, se crea un dos objetos Estado y dos Heuristico que pasaremos donde
     * parametro los objeto Estado al los Heuristicos
     * Operativa: Creamos un dos estados con ID's puestos a mano (intervalo [0..4] y mismas distribuciones en cada Estado) y con
     * similitudes puestos a mano (para cada Estado diferente) y comprobamos que el calculo del Heuristico de ese estado es el
     * que el Heuristico 1 que tendra valor 32 sea mayor que el Heuristico 2 que tendra valor 46 que tiene que devolver true.
     */
    @Test
    public void TestisLower() {
        ArrayList<Integer> IDS = new ArrayList<Integer>();
        for (int i = 0; i < 4; i++) IDS.add(i);

        ArrayList<ArrayList<Integer>> Similitudes1 = new ArrayList<ArrayList<Integer>>();
        int[][] matrix1 = {
                {-1,3,2,4},
                {3,-1,4,1},
                {2,4,-1,5},
                {4,1,5,-1}
        };

        for (int i = 0; i < 4; ++i) {
            ArrayList<Integer> aux = new ArrayList<>();
            for (int j = 0; j < 4; ++j) {
                aux.add(j, matrix1[i][j]);
            }
            Similitudes1.add(aux);
        }

        Estado act1 = new Estado(IDS, Similitudes1);
        Heuristico prueba1 = new Heuristico(act1);

        ArrayList<ArrayList<Integer>> Similitudes2 = new ArrayList<ArrayList<Integer>>();
        int[][] matrix2 = {
                {-1,4,2,4},
                {4,-1,10,1},
                {2,10,-1,5},
                {4,1,5,-1}
        };

        for (int i = 0; i < 4; ++i) {
            ArrayList<Integer> aux = new ArrayList<>();
            for (int j = 0; j < 4; ++j) {
                aux.add(j, matrix2[i][j]);
            }
            Similitudes2.add(aux);
        }

        Estado act2 = new Estado(IDS, Similitudes2);
        Heuristico prueba2 = new Heuristico(act2);

        assertTrue("El Heuristico 2 no es mas grande que el primero", prueba1.isLower(prueba2));
    }

    /**
     * Objetivo de la prueba: Test de la funcion isUpper
     * Archivos de datos necesarios: Datos introducidos manualmente
     * Valores estudiados: Estrategia caja gris, se crea un dos objetos Estado y dos Heuristico que pasaremos donde
     * parametro los objeto Estado al los Heuristicos
     * Operativa: Creamos un dos estados con ID's puestos a mano (intervalo [0..4] y mismas distribuciones en cada Estado) y con
     * similitudes puestos a mano (para cada Estado diferente) y comprobamos que el calculo del Heuristico de ese estado es el
     * que el Heuristico 1 que tendra valor 32 sea mayor que el Heuristico 2 que tendra valor 46 que tiene que devolver false.
     */
    @Test
    public void TestisUpper() {
        ArrayList<Integer> IDS = new ArrayList<Integer>();
        for (int i = 0; i < 4; i++) IDS.add(i);

        ArrayList<ArrayList<Integer>> Similitudes1 = new ArrayList<ArrayList<Integer>>();
        int[][] matrix1 = {
                {-1,3,2,4},
                {3,-1,4,1},
                {2,4,-1,5},
                {4,1,5,-1}
        };

        for (int i = 0; i < 4; ++i) {
            ArrayList<Integer> aux = new ArrayList<>();
            for (int j = 0; j < 4; ++j) {
                aux.add(j, matrix1[i][j]);
            }
            Similitudes1.add(aux);
        }

        Estado act1 = new Estado(IDS, Similitudes1);
        Heuristico prueba1 = new Heuristico(act1);

        ArrayList<ArrayList<Integer>> Similitudes2 = new ArrayList<ArrayList<Integer>>();
        int[][] matrix2 = {
                {-1,4,2,4},
                {4,-1,10,1},
                {2,10,-1,5},
                {4,1,5,-1}
        };

        for (int i = 0; i < 4; ++i) {
            ArrayList<Integer> aux = new ArrayList<>();
            for (int j = 0; j < 4; ++j) {
                aux.add(j, matrix2[i][j]);
            }
            Similitudes2.add(aux);
        }

        Estado act2 = new Estado(IDS, Similitudes2);
        Heuristico prueba2 = new Heuristico(act2);

        assertFalse("El primer Heuristico es mas grande que el segundo", prueba1.isUpper(prueba2));
    }
}
