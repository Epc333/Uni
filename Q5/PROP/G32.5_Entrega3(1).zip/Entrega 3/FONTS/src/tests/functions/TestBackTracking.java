package src.tests.functions;

import org.junit.Test;

import src.main.domain.classes.functions.BackTracking;

import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.Assert.assertEquals;

import static org.junit.Assert.assertTrue;


public class TestBackTracking {

    @Test
    public void testGetSolucion() {
        // Crear similitudes (matriz de adyacencia)
        ArrayList<ArrayList<Integer>> similitudes = new ArrayList<>();
        similitudes.add(new ArrayList<>(Arrays.asList(0, 10, 15, 20)));
        similitudes.add(new ArrayList<>(Arrays.asList(10, 0, 35, 25)));
        similitudes.add(new ArrayList<>(Arrays.asList(15, 35, 0, 30)));
        similitudes.add(new ArrayList<>(Arrays.asList(20, 25, 30, 0)));

        // Crear identificadores
        ArrayList<Integer> identificadores = new ArrayList<>(Arrays.asList(1, 2, 3, 4));

        // Crear instancia de BackTracking
        BackTracking backTracking = new BackTracking();

        // Obtener solución
        ArrayList<Integer> solucion = backTracking.buscarSolucion(similitudes, identificadores);

        // Verificar que la solución es válida (orden de nodos que minimiza los pesos)
        // Aquí asumimos que el resultado mínimo es conocido de antemano
        ArrayList<Integer> esperado = new ArrayList<>(Arrays.asList(1, 2, 3, 4)); // Ajusta según tu caso

        assertEquals("El valor mínimo no es el esperado.", 305, (int) backTracking.getValorMinimo());
        assertEquals("La solución obtenida no es la esperada." ,esperado, solucion);
    }

    @Test
    public void testGetSolucion2(){
        ArrayList<ArrayList<Integer>> similitudes = new ArrayList<>();
        similitudes.add(new ArrayList<>(Arrays.asList(0, 29, 82, 46, 68, 52, 72, 42, 51)));
        similitudes.add(new ArrayList<>(Arrays.asList(29, 0, 55, 46, 42, 43, 43, 23, 23)));
        similitudes.add(new ArrayList<>(Arrays.asList(82, 55, 0, 68, 46, 55, 23, 43, 41)));
        similitudes.add(new ArrayList<>(Arrays.asList(46, 46, 68, 0, 82, 15, 72, 31, 62)));
        similitudes.add(new ArrayList<>(Arrays.asList(68, 42, 46, 82, 0, 74, 23, 52, 21)));
        similitudes.add(new ArrayList<>(Arrays.asList(52, 43, 55, 15, 74, 0, 61, 23, 55)));
        similitudes.add(new ArrayList<>(Arrays.asList(72, 43, 23, 72, 23, 61, 0, 42, 23)));
        similitudes.add(new ArrayList<>(Arrays.asList(42, 23, 43, 31, 52, 23, 42, 0, 33)));
        similitudes.add(new ArrayList<>(Arrays.asList(51, 23, 41, 62, 21, 55, 23, 33, 0)));

        ArrayList<Integer> identificadores = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9));

        BackTracking backTracking = new BackTracking();

        // Obtener solución
        ArrayList<Integer> solucion = backTracking.buscarSolucion(similitudes, identificadores);

        // Verificar que la solución es válida (orden de nodos que minimiza los pesos)
        // Aquí asumimos que el resultado mínimo es conocido de antemano
        ArrayList<Integer> esperado = new ArrayList<>(Arrays.asList(1, 3, 2, 8, 9, 6, 5, 4, 7)); // Ajusta según tu caso

        assertEquals("El valor mínimo no es el esperado.", 352, (int) backTracking.getValorMinimo());
        assertEquals("La solución obtenida no es la esperada." ,esperado, solucion);
    }

    @Test
    public void testGetSolucion3() {
        ArrayList<ArrayList<Integer>> similitudes = new ArrayList<>();
        similitudes.add(new ArrayList<>(Arrays.asList(0, 45, 67, 23, 89, 12, 34, 56, 78, 90)));
        similitudes.add(new ArrayList<>(Arrays.asList(45, 0, 34, 78, 23, 56, 89, 12, 45, 67)));
        similitudes.add(new ArrayList<>(Arrays.asList(67, 34, 0, 45, 67, 89, 23, 45, 12, 34)));
        similitudes.add(new ArrayList<>(Arrays.asList(23, 78, 45, 0, 34, 67, 12, 89, 56, 23)));
        similitudes.add(new ArrayList<>(Arrays.asList(89, 23, 67, 34, 0, 45, 78, 23, 89, 12)));
        similitudes.add(new ArrayList<>(Arrays.asList(12, 56, 89, 67, 45, 0, 56, 34, 23, 78)));
        similitudes.add(new ArrayList<>(Arrays.asList(34, 89, 23, 12, 78, 56, 0, 67, 34, 45)));
        similitudes.add(new ArrayList<>(Arrays.asList(56, 12, 45, 89, 23, 34, 67, 0, 78, 89)));
        similitudes.add(new ArrayList<>(Arrays.asList(78, 45, 12, 56, 89, 23, 34, 78, 0, 56)));
        similitudes.add(new ArrayList<>(Arrays.asList(90, 67, 34, 23, 12, 78, 45, 89, 56, 0)));

        ArrayList<Integer> identificadores = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10));

        BackTracking backTracking = new BackTracking();

        ArrayList<Integer> solucion = backTracking.buscarSolucion(similitudes, identificadores);

        ArrayList<Integer> esperado = new ArrayList<>(Arrays.asList(1, 3, 6, 10, 8, 4, 2, 7, 5, 9));

        assertEquals("El valor mínimo no es el esperado.", 176, (int) backTracking.getValorMinimo());
        assertEquals("La solución obtenida no es la esperada.", esperado, solucion);
    }

    @Test
    public void testGetSolucion4() {
        ArrayList<ArrayList<Integer>> similitudes = new ArrayList<>();
        similitudes.add(new ArrayList<>(Arrays.asList(0, 45, 23, 67, 89, 12, 34, 56, 78, 90, 43, 21, 65, 87, 32)));
        similitudes.add(new ArrayList<>(Arrays.asList(45, 0, 78, 34, 23, 56, 89, 12, 45, 67, 90, 43, 21, 54, 76)));
        similitudes.add(new ArrayList<>(Arrays.asList(23, 78, 0, 45, 67, 89, 23, 45, 12, 34, 65, 87, 32, 90, 43)));
        similitudes.add(new ArrayList<>(Arrays.asList(67, 34, 45, 0, 34, 67, 12, 89, 56, 23, 21, 54, 76, 45, 89)));
        similitudes.add(new ArrayList<>(Arrays.asList(89, 23, 67, 34, 0, 45, 78, 23, 89, 12, 32, 90, 43, 21, 65)));
        similitudes.add(new ArrayList<>(Arrays.asList(12, 56, 89, 67, 45, 0, 56, 34, 23, 78, 76, 45, 89, 32, 90)));
        similitudes.add(new ArrayList<>(Arrays.asList(34, 89, 23, 12, 78, 56, 0, 67, 34, 45, 43, 21, 65, 76, 45)));
        similitudes.add(new ArrayList<>(Arrays.asList(56, 12, 45, 89, 23, 34, 67, 0, 78, 89, 89, 32, 90, 43, 21)));
        similitudes.add(new ArrayList<>(Arrays.asList(78, 45, 12, 56, 89, 23, 34, 78, 0, 56, 65, 76, 45, 89, 32)));
        similitudes.add(new ArrayList<>(Arrays.asList(90, 67, 34, 23, 12, 78, 45, 89, 56, 0, 90, 43, 21, 65, 76)));
        similitudes.add(new ArrayList<>(Arrays.asList(43, 90, 65, 21, 32, 76, 43, 89, 65, 90, 0, 89, 32, 90, 43)));
        similitudes.add(new ArrayList<>(Arrays.asList(21, 43, 87, 54, 90, 45, 21, 32, 76, 43, 89, 0, 76, 45, 89)));
        similitudes.add(new ArrayList<>(Arrays.asList(65, 21, 32, 76, 43, 89, 65, 90, 45, 21, 32, 76, 0, 21, 65)));
        similitudes.add(new ArrayList<>(Arrays.asList(87, 54, 90, 45, 21, 32, 76, 43, 89, 65, 90, 45, 21, 0, 76)));
        similitudes.add(new ArrayList<>(Arrays.asList(32, 76, 43, 89, 65, 90, 45, 21, 32, 76, 43, 89, 65, 76, 0)));

        ArrayList<Integer> identificadores = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15));

        BackTracking backTracking = new BackTracking();

        ArrayList<Integer> solucion = backTracking.buscarSolucion(similitudes, identificadores);

        ArrayList<Integer> esperado = new ArrayList<>(Arrays.asList(1, 9, 14, 3, 6, 13, 8, 4, 15, 12, 5, 7, 2, 11, 10));

        assertEquals("El valor mínimo no es el esperado.", 181, (int) backTracking.getValorMinimo());
        assertEquals("La solución obtenida no es la esperada.", esperado, solucion);
    }

    @Test
    public void testEmptySimilitudes() {
        ArrayList<ArrayList<Integer>> similitudes = new ArrayList<>();
        ArrayList<Integer> identificadores = new ArrayList<>();

        BackTracking backTracking = new BackTracking();
        ArrayList<Integer> solucion = backTracking.buscarSolucion(similitudes, identificadores);

        assertTrue("La solución debe estar vacía.", solucion.isEmpty());
        assertEquals("El valor mínimo debe ser 0.", 0, (int) backTracking.getValorMinimo());
    }

    @Test
    public void testSingleElement() {
        ArrayList<ArrayList<Integer>> similitudes = new ArrayList<>();
        similitudes.add(new ArrayList<>(Arrays.asList(0)));

        ArrayList<Integer> identificadores = new ArrayList<>(Arrays.asList(1));

        BackTracking backTracking = new BackTracking();
        ArrayList<Integer> solucion = backTracking.buscarSolucion(similitudes, identificadores);

        assertEquals("La solución debe contener un solo elemento.", 1, solucion.size());
        assertEquals("El identificador debe ser 1.", (Integer) 1, solucion.get(0));
        assertEquals("El valor mínimo debe ser 0.", 100, (int) backTracking.getValorMinimo());
    }

    @Test
    public void testTwoElements() {
        ArrayList<ArrayList<Integer>> similitudes = new ArrayList<>();
        similitudes.add(new ArrayList<>(Arrays.asList(0, 10)));
        similitudes.add(new ArrayList<>(Arrays.asList(10, 0)));

        ArrayList<Integer> identificadores = new ArrayList<>(Arrays.asList(1, 2));

        BackTracking backTracking = new BackTracking();
        ArrayList<Integer> solucion = backTracking.buscarSolucion(similitudes, identificadores);

        ArrayList<Integer> esperado = new ArrayList<>(Arrays.asList(1, 2));

        assertEquals("La solución obtenida no es la esperada.", esperado, solucion);
        assertEquals("El valor mínimo no es el esperado.", 180, (int) backTracking.getValorMinimo());
    }

    @Test
    public void testThreeElements() {
        ArrayList<ArrayList<Integer>> similitudes = new ArrayList<>();
        similitudes.add(new ArrayList<>(Arrays.asList(0, 10, 15)));
        similitudes.add(new ArrayList<>(Arrays.asList(10, 0, 35)));
        similitudes.add(new ArrayList<>(Arrays.asList(15, 35, 0)));

        ArrayList<Integer> identificadores = new ArrayList<>(Arrays.asList(1, 2, 3));

        BackTracking backTracking = new BackTracking();
        ArrayList<Integer> solucion = backTracking.buscarSolucion(similitudes, identificadores);

        ArrayList<Integer> esperado = new ArrayList<>(Arrays.asList(1, 2, 3));

        assertEquals("La solución obtenida no es la esperada.", esperado, solucion);
        assertEquals("El valor mínimo no es el esperado.", 240, (int) backTracking.getValorMinimo());
    }

    @Test
    public void testFourElements() {
        ArrayList<ArrayList<Integer>> similitudes = new ArrayList<>();
        similitudes.add(new ArrayList<>(Arrays.asList(0, 10, 15, 20)));
        similitudes.add(new ArrayList<>(Arrays.asList(10, 0, 35, 25)));
        similitudes.add(new ArrayList<>(Arrays.asList(15, 35, 0, 30)));
        similitudes.add(new ArrayList<>(Arrays.asList(20, 25, 30, 0)));

        ArrayList<Integer> identificadores = new ArrayList<>(Arrays.asList(1, 2, 3, 4));

        BackTracking backTracking = new BackTracking();
        ArrayList<Integer> solucion = backTracking.buscarSolucion(similitudes, identificadores);

        ArrayList<Integer> esperado = new ArrayList<>(Arrays.asList(1, 2, 3, 4));

        assertEquals("La solución obtenida no es la esperada.", esperado, solucion);
        assertEquals("El valor mínimo no es el esperado.", 305, (int) backTracking.getValorMinimo());
    }

    @Test
    public void allSame(){
        ArrayList<ArrayList<Integer>> similitudes = new ArrayList<>();
        similitudes.add(new ArrayList<>(Arrays.asList(0, 0, 0, 0)));
        similitudes.add(new ArrayList<>(Arrays.asList(0, 0, 0, 0)));
        similitudes.add(new ArrayList<>(Arrays.asList(0, 0, 0, 0)));
        similitudes.add(new ArrayList<>(Arrays.asList(0, 0, 0, 0)));

        ArrayList<Integer> identificadores = new ArrayList<>(Arrays.asList(1, 2, 3, 4));

        BackTracking backTracking = new BackTracking();

        ArrayList<Integer> solucion = backTracking.buscarSolucion(similitudes, identificadores);

        assertEquals("El valor mínimo no es el esperado.", 400, (int) backTracking.getValorMinimo());
    }
    
}