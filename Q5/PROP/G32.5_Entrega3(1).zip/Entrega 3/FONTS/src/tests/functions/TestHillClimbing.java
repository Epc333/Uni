package src.tests.functions;

import src.main.domain.classes.functions.HillClimbing;

import org.junit.Test;
import java.util.ArrayList;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertNotNull;


/**
 * @author Andres Lucian Laptes Costan (andres.lucian.laptes@estudiantat.upc.edu)
 * */
public class TestHillClimbing {

    /**
     * Objetivo de la prueba: Test de la constructora de la clase HillClimbing
     * Archivos de datos necesarios: Datos introducidos manualmente
     * Valores estudiados: Estrategia caja gris, se crea un nuevo objeto HillClimbing
     * Operativa: Creamos un nuevo HillClimbing con ID's puestos a mano (intervalo [0..4]) y con
     * similitudes puestos a mano y comprobamos los atributos del HillClimbing sea el mismo
     */
    @Test
    public void TestConstructoraHillClimbing(){
        ArrayList<Integer> IDS = new ArrayList<Integer>();
        for (int i = 3; i >= 0; --i) IDS.add(i);

        ArrayList<ArrayList<Integer>> Similitudes = new ArrayList<ArrayList<Integer>>();
        int[][] matrix = {
                {-1,3,2,4},
                {3,-1,4,1},
                {2,4,-1,5},
                {4,1,5,-1}
        };

        for (int i = 0; i < 4; ++i) {
            ArrayList<Integer> aux = new ArrayList<>();
            for (int j = 0; j < 4; ++j) {
                aux.add(j, matrix[i][j]);
            }
            Similitudes.add(aux);
        }

        HillClimbing hcl = new HillClimbing();
        assertNotNull(hcl);
        hcl.BuscarSolucion(IDS, Similitudes);
        assertEquals("El estado incial no es igual", IDS, hcl.getEstadoInicial());
        assertEquals("El heuristico no es el esperado", 31, hcl.getMejorHeurisitico());
    }

    /**
     * Objetivo de la prueba: Test de la funcion getMejorInicial
     * Archivos de datos necesarios: Datos introducidos manualmente
     * Valores estudiados: Estrategia caja gris, se crea un nuevo objeto HillClimbing
     * Operativa: Creamos un nuevo HillClimbing con ID's puestos a mano (intervalo [0..4]) y con
     * similitudes puestos a mano y comprobamos que el resultado de getEstadoInicial
     */
    @Test
    public void TestGetEstadoInicial() {
        ArrayList<Integer> IDS = new ArrayList<Integer>();
        for (int i = 3; i >= 0; --i) IDS.add(i);

        ArrayList<ArrayList<Integer>> Similitudes = new ArrayList<ArrayList<Integer>>();
        int[][] matrix = {
                {-1,3,2,4},
                {3,-1,4,1},
                {2,4,-1,5},
                {4,1,5,-1}
        };

        for (int i = 0; i < 4; ++i) {
            ArrayList<Integer> aux = new ArrayList<>();
            for (int j = 0; j < 4; ++j) {
                aux.add(j, matrix[i][j]);
            }
            Similitudes.add(aux);
        }

        HillClimbing hcl = new HillClimbing();
        hcl.BuscarSolucion(IDS, Similitudes);
        assertEquals("Estado inicial no es correcto", IDS, hcl.getEstadoInicial());
    }

    /**
     * Objetivo de la prueba: Test de la funcion getMejorHeuristico
     * Archivos de datos necesarios: Datos introducidos manualmente
     * Valores estudiados: Estrategia caja gris, se crea un nuevo objeto HillClimbing
     * Operativa: Creamos un nuevo HillClimbing con ID's puestos a mano (intervalo [0..4]) y con
     * similitudes puestos a mano y comprobamos que el resultado de getMejorHeuristico
     */
    @Test
    public void TestGetMejorHeurisitico() {
        ArrayList<Integer> IDS = new ArrayList<Integer>();
        for (int i = 3; i >= 0; --i) IDS.add(i);

        ArrayList<ArrayList<Integer>> Similitudes = new ArrayList<ArrayList<Integer>>();
        int[][] matrix = {
                {-1,3,2,4},
                {3,-1,4,1},
                {2,4,-1,5},
                {4,1,5,-1}
        };

        for (int i = 0; i < 4; ++i) {
            ArrayList<Integer> aux = new ArrayList<>();
            for (int j = 0; j < 4; ++j) {
                aux.add(j, matrix[i][j]);
            }
            Similitudes.add(aux);
        }

        HillClimbing hcl = new HillClimbing();
        hcl.BuscarSolucion(IDS, Similitudes);
        assertEquals("El valor del Heuristico no es el esperado", 31, hcl.getMejorHeurisitico());
    }

    /**
     * Objetivo de la prueba: Test de la funcion Calcular
     * Archivos de datos necesarios: Datos introducidos manualmente
     * Valores estudiados: Estrategia caja gris, se crea un nuevo objeto HillClimbing y utilizamos
     * la funcion calcular para encontrar la mejor distribución desde el estado inicial,
     * por la naturaleza del algoritmo pueden haber mejores soluciones dado que depende de la distribucion
     * inicial de los productos y se puede quedar encallado en un minimio local, aunque estemos recorriendo
     * el espacio de soluciones y el operador swap nos permite recorrer todo el espacio de busqueda.
     * Ademas, pueden darnos una distribucción que es equivalente a otra de manera que las dos son igual de validas
     * dependidiendo si hay muchas similitudes casi iguales o iguales.
     * Operativa: Creamos un nuevo HillClimbing con ID's puestos a mano (intervalo [0..9]) y con
     * similitudes puestos a mano y comprobamos que el resultado es una de las mejores para comprobar si nuestro
     * resultado es una de las mejores comprobamos el valor del heuristico maximo que podemos llegar a conseguir con nuestra
     * distribucion (calculada a mano es 217) y el resultado si la diferencia no es muy notoria pasara el test notoria me refiero
     * a que desde el mejor resultado posible no empeore mas de un 5%, en este test tengo encuenta para evitar el maximo de minimos locales
     * poner las similitudes a 1 menos las que me interesan que esten juntas.
     */
    @Test
    public void TestCalcular() {
        ArrayList<Integer> IDS = new ArrayList<Integer>();
        for (int i = 0; i < 10; ++i) IDS.add(i);

        ArrayList<ArrayList<Integer>> Similitudes = new ArrayList<ArrayList<Integer>>();
        int[][] matrix = {
                {-1,1,1,1,8,6,1,1,1,1},
                {1,-1,10,1,1,1,1,8,7,1},
                {1,10,-1,5,1,1,1,6,7,40},
                {1,1,5,-1,1,1,1,1,20,5},
                {8,1,1,1,-1,1,5,1,1,1},
                {5,1,1,1,1,-1,5,1,10,1},
                {1,1,1,1,5,5,-1,5,1,1},
                {8,1,6,1,1,1,5,-1,1,1},
                {1,7,7,20,1,10,1,1,-1,1},
                {1,1,40,5,1,1,1,1,1,-1}
        };

        for (int i = 0; i < 10; ++i) {
            ArrayList<Integer> aux = new ArrayList<>();
            for (int j = 0; j < 10; ++j) {
                aux.add(j, matrix[i][j]);
            }
            Similitudes.add(aux);
        }

        HillClimbing hcl = new HillClimbing();
        hcl.BuscarSolucion(IDS, Similitudes);

        hcl.getMejorHeurisitico();
        assertTrue("La diferencia no es muy sustancial",((230 - hcl.getMejorHeurisitico())/230) * 100 < 5);
    }


    /**
     * Objetivo de la prueba: Test de la funcion getMejorEstado
     * Archivos de datos necesarios: Datos introducidos manualmente
     * Valores estudiados: Estrategia caja gris, se crea un nuevo objeto HillClimbing
     * Operativa: Creamos un nuevo HillClimbing con ID's puestos a mano (intervalo [0..4]) y con
     * similitudes puestos a mano y comprobamos que el resultado sea no nulo indicanod que se a consguido un mejorEstado
     */
    @Test
    public void TestGetMejorEstado() {
        ArrayList<Integer> IDS = new ArrayList<Integer>();
        for (int i = 3; i >= 0; --i) IDS.add(i);

        ArrayList<ArrayList<Integer>> Similitudes = new ArrayList<ArrayList<Integer>>();
        int[][] matrix = {
                {-1,3,2,4},
                {3,-1,4,1},
                {2,4,-1,5},
                {4,1,5,-1}
        };

        for (int i = 0; i < 4; ++i) {
            ArrayList<Integer> aux = new ArrayList<>();
            for (int j = 0; j < 4; ++j) {
                aux.add(j, matrix[i][j]);
            }
            Similitudes.add(aux);
        }

        HillClimbing hcl = new HillClimbing();
        hcl.BuscarSolucion(IDS, Similitudes);
        assertNotNull("Es un valor valor invalido",hcl.getMejorEstado());
    }
}
