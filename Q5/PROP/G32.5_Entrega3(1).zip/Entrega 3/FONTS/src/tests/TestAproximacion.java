package src.tests;

import java.util.ArrayList;
import java.util.Arrays;
import src.main.domain.classes.functions.Aproximacion;

import org.junit.Test;
import static org.junit.Assert.assertTrue;

/**
 * Clase con tests para Aproximacion.
 * @author Asier García Elvira (asier.garcia@estudiantat.upc.edu)
 */
public class TestAproximacion {

    /**
     * Objetivo de la prueba: Verificar que la ordenacion cumple con la condición de 2-aproximación con similitudes altas
     * Ficheros de datos necesarios: Los datos se introducen manualmente.
     * Valores Estudiados: Estratègia caja gris. Tomamos un caso con similitudes altas.
     * Operativa: Creamos la matriz y la lista y comprobamos que el resultado de buscarSolucion sea válido.
     */
    @Test
    public void testAproximacionCaso1() {
        // Preparar datos de entrada
        ArrayList<ArrayList<Integer>> similitudes = new ArrayList<>(Arrays.asList(
                new ArrayList<>(Arrays.asList(0, 8, 3, 1)),
                new ArrayList<>(Arrays.asList(8, 0, 6, 2)),
                new ArrayList<>(Arrays.asList(3, 6, 0, 5)),
                new ArrayList<>(Arrays.asList(1, 2, 5, 0))
        ));
        ArrayList<Integer> posiciones = new ArrayList<>(Arrays.asList(101, 102, 103, 104));

        Aproximacion aproximacion = new Aproximacion();

        // Ejecutar el algoritmo de aproximación
        ArrayList<Integer> solucionAprox = aproximacion.buscarSolucion(similitudes, posiciones);
        int valorAprox = calcularValor(similitudes, posiciones, solucionAprox);

        // Valor óptimo calculado manualmente
        int valorOptimo = 8 + 6 + 5; // El valor óptimo es la secuencia con las similitudes 8, 6, 5

        // Verificar que la aproximación cumple con la 2-aproximación
        assertTrue("El valor aproximado no cumple con la garantía de 2-aproximación", valorAprox >= valorOptimo / 2);
    }

    /**
     * Objetivo de la prueba: Verificar que la ordenacion cumple con la condición de 2-aproximación con similitudes variadas
     * Ficheros de datos necesarios: Los datos se introducen manualmente.
     * Valores Estudiados: Estratègia caja gris. Tomamos un caso con similitudes variadas.
     * Operativa: Creamos la matriz y la lista y comprobamos que el resultado de buscarSolucion sea válido.
     */
    @Test
    public void testAproximacionCaso2() {
        // Preparar datos de entrada
        ArrayList<ArrayList<Integer>> similitudes = new ArrayList<>(Arrays.asList(
                new ArrayList<>(Arrays.asList(0, 3, 1, 9)),
                new ArrayList<>(Arrays.asList(3, 0, 5, 2)),
                new ArrayList<>(Arrays.asList(1, 5, 0, 4)),
                new ArrayList<>(Arrays.asList(9, 2, 4, 0))
        ));
        ArrayList<Integer> posiciones = new ArrayList<>(Arrays.asList(101, 102, 103, 104));

        Aproximacion aproximacion = new Aproximacion();

        // Ejecutar el algoritmo de aproximación
        ArrayList<Integer> solucionAprox = aproximacion.buscarSolucion(similitudes, posiciones);
        int valorAprox = calcularValor(similitudes, posiciones, solucionAprox);

        // Valor óptimo calculado manualmente
        int valorOptimo = 9 + 5 + 4; // El valor óptimo es la secuencia con las similitudes 9, 5, 4

        // Verificar que la aproximación cumple con la 2-aproximación
        assertTrue("El valor aproximado no cumple con la garantía de 2-aproximación", valorAprox >= valorOptimo / 2);
    }

    /**
     * Objetivo de la prueba: Verificar que la ordenacion cumple con la condición de 2-aproximación con similitudes bajas
     * Ficheros de datos necesarios: Los datos se introducen manualmente.
     * Valores Estudiados: Estratègia caja gris. Tomamos un caso con similitudes bajas.
     * Operativa: Creamos la matriz y la lista y comprobamos que el resultado de buscarSolucion sea válido.
     */
    @Test
    public void testAproximacionCaso3() {
        // Preparar datos de entrada
        ArrayList<ArrayList<Integer>> similitudes = new ArrayList<>(Arrays.asList(
                new ArrayList<>(Arrays.asList(0, 2, 1, 1)),
                new ArrayList<>(Arrays.asList(2, 0, 3, 2)),
                new ArrayList<>(Arrays.asList(1, 3, 0, 2)),
                new ArrayList<>(Arrays.asList(1, 2, 2, 0))
        ));
        ArrayList<Integer> posiciones = new ArrayList<>(Arrays.asList(101, 102, 103, 104));

        Aproximacion aproximacion = new Aproximacion();

        // Ejecutar el algoritmo de aproximación
        ArrayList<Integer> solucionAprox = aproximacion.buscarSolucion(similitudes, posiciones);
        int valorAprox = calcularValor(similitudes, posiciones, solucionAprox);

        // Valor óptimo calculado manualmente
        int valorOptimo = 3 + 2 + 2; // El valor óptimo es la secuencia con las similitudes 3, 2, 2

        // Verificar que la aproximación cumple con la 2-aproximación
        assertTrue("El valor aproximado no cumple con la garantía de 2-aproximación", valorAprox >= valorOptimo / 2);
    }

    /**
     * Objetivo de la prueba: Verificar que la ordenacion cumple con la condición de 2-aproximación con similitudes muy distintas
     * Ficheros de datos necesarios: Los datos se introducen manualmente.
     * Valores Estudiados: Estratègia caja gris. Tomamos un caso con similitudes muy distintas.
     * Operativa: Creamos la matriz y la lista y comprobamos que el resultado de buscarSolucion sea válido.
     */
    @Test
    public void testAproximacionCaso4() {
        // Preparar datos de entrada
        ArrayList<ArrayList<Integer>> similitudes = new ArrayList<>(Arrays.asList(
                new ArrayList<>(Arrays.asList(0, 1, 1, 1)),
                new ArrayList<>(Arrays.asList(1, 0, 10, 2)),
                new ArrayList<>(Arrays.asList(1, 10, 0, 1)),
                new ArrayList<>(Arrays.asList(1, 2, 1, 0))
        ));
        ArrayList<Integer> posiciones = new ArrayList<>(Arrays.asList(101, 102, 103, 104));

        Aproximacion aproximacion = new Aproximacion();

        // Ejecutar el algoritmo de aproximación
        ArrayList<Integer> solucionAprox = aproximacion.buscarSolucion(similitudes, posiciones);
        int valorAprox = calcularValor(similitudes, posiciones, solucionAprox);

        // Valor óptimo calculado manualmente
        int valorOptimo = 10 + 2 + 1; // El valor óptimo es la secuencia con las similitudes 10, 2, 1

        // Verificar que la aproximación cumple con la 2-aproximación
        assertTrue("El valor aproximado no cumple con la garantía de 2-aproximación", valorAprox >= valorOptimo / 2);
    }

    /* Método que implementa ordenar de Algoritmo con un algoritmo de 2-aproximación
     * @parametros Matriz de similitudes con índice igual a posición del producto, lista de posiciones, con indice igual a posicion y contenido igual a id producto y lista con una solución al ordenamiento de productos
     * @return Similitud total del orden
     */
    public int calcularValor(ArrayList<ArrayList<Integer>> similitudes, ArrayList<Integer> posiciones, ArrayList<Integer> solucionAprox) {
        int valorTotal = 0;
    
        for (int i = 0; i < solucionAprox.size() - 1; i++) {
            int idProducto1 = solucionAprox.get(i);
            int idProducto2 = solucionAprox.get(i + 1);
    
            // Convertir los identificadores a posiciones
            int posProducto1 = posiciones.indexOf(idProducto1);
            int posProducto2 = posiciones.indexOf(idProducto2);
    
            // Sumar la similitud entre los productos adyacentes
            valorTotal += similitudes.get(posProducto1).get(posProducto2);
        }
    
        return valorTotal;
    }
}
