# PROP Grupo 32.5
Proyecto de Programación, Grupo 32, subgrupo 5. <br>Profesor: Carles Arnal ([carles.arnal@upc.edu]()).

## Miembros del grupo


- Garcia Elvira, Asier ([asier.garcia@estudiantat.upc.edu]())
- Granda Planas, Vinyet ([vinyet.granda@estudiantat.upc.edu]())
- Laptes Costan, Andres Lucian ([andres.lucian.laptes@estudiantat.upc.edu]())
- Pizarro Cami, Eudald ([eudald.pizarro@estudiantat.upc.edu]())


## Elementos del directorio

### DOCS:
Contiene la documentación del proyecto: el diagrama de casos de uso con su descripción, el modelo conceptual de diseño con una descripción de los atributos y métodos de las clases, además de una descripción de cada clase. La distribución de las clases implementadas por cada integrante del equipo y, por último una descripción de las estructuras de datos y algoritmos usados para implementar la distribución del supermercado.

### EXE:
Contiene los archivos ejecutables de las clases para probar las funcionalidades implementadas.

### FONTS:
Contiene los códigos de las clases de dominio de las funcionalidades implementadas, más los tests JUnit. Todos los archivos están dentro de los subdirectorios. También incluye el archivo *Makefile* para compilar el proyecto.

### lib:
Aquí tenemos las librerías que hemos utilizado para los test.

## Probar el programa

Para ejecutar el programa hay dos opciones:
 - Ir al directorio `/FONTS/src`, que es donde se encuentra el *Makefile* del programa, i ejecutar make run para correr el programa.
 - En terminal des de este directorio, ejecutar el siguiente comando:
    - Si es en Windows: java -jar .\EXE\PROP.jar
    - Si es en Unix o MacOS:  java -jar EXE/PROP.jar 

