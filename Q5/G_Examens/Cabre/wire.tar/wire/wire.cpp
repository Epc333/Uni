#include "wire.h"
#include "glwidget.h"

const int IMAGE_WIDTH = 512;
const int IMAGE_HEIGHT = IMAGE_WIDTH;

void Wire::onPluginLoad()
{
    GLWidget & g = *glwidget();

	// Carregar shader, compile & link 
    QString vs_src =
      "#version 330 core\n"
      "layout (location = 0) in vec3 vertex;"
      "layout (location = 1) in vec3 normal;"
      "layout (location = 2) in vec3 color;"
      "out vec4 col;"
      "uniform mat4 modelViewProjectionMatrix;"
      "uniform mat3 normalMatrix;"
      "void main() {"
      "  vec3 N = normalize(normalMatrix * normal);"
      "  col=vec4(vec3(N.z),1.0);"
      "  gl_Position = modelViewProjectionMatrix * vec4(vertex,1.0);"
      "}";
    vs = new QOpenGLShader(QOpenGLShader::Vertex, this);
    vs->compileSourceCode(vs_src);
    cout << "VS log:" << vs->log().toStdString() << endl;

    QString fs_src =
      "#version 330 core\n"
      "out vec4 fragColor;"
      "in vec4 col;"
      "uniform int isBlack;"
      "void main() {"
      "if (isBlack == 1) fragColor = vec4(vec3(0.0), 1.0);"
      "else fragColor=col;"
      "}";
    fs = new QOpenGLShader(QOpenGLShader::Fragment, this);
    fs->compileSourceCode(fs_src);
    cout << "FS log:" << fs->log().toStdString() << endl;

    program = new QOpenGLShaderProgram(this);
    program->addShader(vs);
    program->addShader(fs);
    program->link();
    cout << "Link log:" << program->log().toStdString() << endl;
}

void Wire::preFrame()
{
	// bind shader and define uniforms
    program->bind();
    QMatrix4x4 MVP = camera()->projectionMatrix() * camera()->viewMatrix();
    program->setUniformValue("modelViewProjectionMatrix", MVP); 
    QMatrix4x4 MV = camera()->viewMatrix();
    QMatrix3x3 normalMatrix = MV.normalMatrix();
    program->setUniformValue("normalMatrix", normalMatrix); 
}

bool Wire::paintGL()
{
    glEnable(GL_POLYGON_OFFSET_LINE);

    // Primer paso: Dibujar polígonos rellenados
    glPolygonOffset(0.0f, 0.0f);
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    program->setUniformValue("isBlack", 0);

    if (drawPlugin()) drawPlugin()->drawScene();

    // Segundo paso: Dibujar contornos
    glPolygonOffset(-1.0f, -1.0f);
    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
    program->setUniformValue("isBlack", 1);

    if (drawPlugin()) drawPlugin()->drawScene();

    glDisable(GL_POLYGON_OFFSET_LINE); // Deshabilitar desplazamiento

    return true; // return true only if implemented
}

